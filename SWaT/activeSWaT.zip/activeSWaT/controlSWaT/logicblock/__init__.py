__all__ = ["logicblock"]
#In this package we define some usefule functions that flotech uses.
