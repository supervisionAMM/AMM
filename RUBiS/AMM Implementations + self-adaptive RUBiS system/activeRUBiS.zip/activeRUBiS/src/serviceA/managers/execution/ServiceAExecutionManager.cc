/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <sstream>
#include <cstdlib>
#include <boost/tokenizer.hpp>
#include "PassiveQueue.h"
#include "modules/ServiceAMTBrownoutServer.h"
#include "managers/util/ServiceAUtils.h"
#include "ServiceAExecutionManager.h"

Define_Module(ServiceAExecutionManager);

#define RNG 1

const char* ROUTERA_MODULE_NAME = "routerA";
const char* INTERNAL_QUEUEA_MODULE_NAME = "queueA";
const char* SERVERA_MODULE_NAME = "serverA";
const char* SERVERA_MODULE_TYPE = "rubis.serviceA.modules.ServiceAServer";
const char* INTERNAL_SERVERA_MODULE_NAME = "serverA";
const char* CLASSIFIERA_MODULE_NAME = "classifierA";

void ServiceAExecutionManager::initialize() {

    serverARemovedSignal = registerSignal("serverARemoved");

    serverABusySignal = registerSignal("serverABusy");
    getSimulation()->getSystemModule()->subscribe(serverABusySignal, this);

    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");

    pModel = check_and_cast<ServiceAModel*> (getParentModule()->getSubmodule("modelA"));
}

void ServiceAExecutionManager::handleMessage(cMessage* msg) {

    ServiceABootComplete* bootComplete = check_and_cast<ServiceABootComplete*>(msg);

    if (strcmp(bootComplete->getExpectedChange(),"removeServerADelay") == 0) {

        doRemoveServer(bootComplete);
        delete bootComplete;

    } else if (strcmp(bootComplete->getExpectedChange(),"removeServerA") == 0) {

        cModule* module = getSimulation()->getModule(bootComplete->getModuleId());

        stringstream serverId;
        serverId << module->getId();

        // remove from model
        notifyRemoveServerCompleted(serverId.str().c_str());

        if(cmdenvLogging) {
            std::cout << "t=" << simTime() << " [ServiceAExecutionManager] reomveServer(id=" << bootComplete->getModuleId() << ") complete" << endl;
        }

        // disconnect gates and delete module
        module->gate("out")->disconnect();
        module->deleteModule();
        cancelAndDelete(msg);

    } else if (strcmp(bootComplete->getExpectedChange(),"addServerA") == 0) {

        // update server name and connect server to router, classifier
        doAddServerBootComplete(bootComplete);

        // notify add complete to model
        pModel->serverBecameActive();

        if(cmdenvLogging) {
            std::cout << "t=" << simTime() << " [ServiceAExecutionManager] addServer(id=" << bootComplete->getModuleId() << ") complete" << endl;
        }

        delete bootComplete;
    }
}

void ServiceAExecutionManager::setBrownout(double factor) {
    Enter_Method("setBrownout()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAExecutionManager] executing setBrownout factor=" << factor << endl;
    }

    pModel->setBrownoutFactor(factor);
    doSetBrownout(factor);
}

void ServiceAExecutionManager::doSetBrownout(double factor) {

    serverAModuleIds = pModel->getServerPool();
    for(unsigned int i=0; i<serverAModuleIds.size(); i++) {
        cModule* module = getSimulation()->getModule(serverAModuleIds[i]);

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceAExecutionManager] doSetBrownout serverAModuleIds[" << i << "]=" << serverAModuleIds[i]
                                      << " moduleName="<< module->getName()
                                      << " factor="<< factor << endl;
        }

        module->getSubmodule("serverA")->par("brownoutFactor").setDoubleValue(factor);
    }
}

void ServiceAExecutionManager::addServer() {
    Enter_Method("addServer()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAExecutionManager] executing addServer()" << endl;
    }

    addServerLatencyOptional(); // add a server with bootDelay
}

void ServiceAExecutionManager::addServerLatencyOptional(bool instantaneous) {

    // new or copy a server module and new bootComplete
    ServiceABootComplete* bootComplete = doAddServer();

    double bootDelay = 0;
    if (!instantaneous) {
        bootDelay = getParentModule()->par("bootDelay").doubleValue();

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceAExecutionManager] adding server(id="<< bootComplete->getModuleId() <<") with latency=" << bootDelay << endl;
        }
    }

    // add expected SERVER_ONLINE changes
    pModel->addServer(bootDelay);

    // push to server pool
    pModel->pushServerPool(simTime().dbl() + bootDelay, bootComplete->getModuleId());

    if (bootDelay == 0) {
        handleMessage(bootComplete);
    } else {
        scheduleAt(simTime() + bootDelay, bootComplete);
    }
}

ServiceABootComplete* ServiceAExecutionManager::doAddServer() {

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAExecutionManager] server="<< pModel->getServers() <<" ativeServer=" << pModel->getActiveServers() << endl;
    }

    // find factory object
    cModuleType *moduleType = cModuleType::get(SERVERA_MODULE_TYPE);
    int serverCount = pModel->getServers();
    stringstream name;
    name << SERVERA_MODULE_NAME;
    name << "-T"; // temp server name, different from update name
    name << serverCount + 1;
    cModule *module = moduleType->create(name.str().c_str(), getParentModule());

    // setup parameters
    module->finalizeParameters();
    module->buildInside();

    // copy all params of the server inside the server module from the template
    cModule* pNewSubmodule = module->getSubmodule(INTERNAL_SERVERA_MODULE_NAME);
    if (serverCount > 1) {
        // copy from an existing server
        stringstream templateName;
        templateName << SERVERA_MODULE_NAME;
        templateName << "-";
        templateName << 1;

        cModule* pTemplateSubmodule = getParentModule()->getSubmodule(templateName.str().c_str())->getSubmodule(INTERNAL_SERVERA_MODULE_NAME);

        for (int i = 0; i < pTemplateSubmodule->getNumParams(); i++) {
            pNewSubmodule->par(i) = pTemplateSubmodule->par(i);
        }

    } else {
        // if it's the first server, we need to set the parameters common to all servers in the model
        pModel->setServerThreads(pNewSubmodule->par("threads"));
        double variance = 0.0;
        double mean = ServiceAUtils::getMeanAndVarianceFromParameter(pNewSubmodule->par("serviceTime"), &variance);
        pModel->setServiceTime(mean, variance);
        mean = ServiceAUtils::getMeanAndVarianceFromParameter(pNewSubmodule->par("lowFidelityServiceTime"), &variance);
        pModel->setLowFidelityServiceTime(mean, variance);
    }

    // create activation message
    module->scheduleStart(simTime());
    module->callInitialize();

    if(cmdenvLogging) {
        cout << "t=" << simTime()<< " [ServiceAExecutionManager] executing doAddServer(id="<< module->getId() << ")" << endl;
    }

    ServiceABootComplete* bootComplete = new ServiceABootComplete;
    bootComplete->setModuleId(module->getId());
    bootComplete->setExpectedChange("addServerA");

    return bootComplete;
}

void ServiceAExecutionManager::doAddServerBootComplete(ServiceABootComplete* bootComplete) {

    cModule *server = getSimulation()->getModule(bootComplete->getModuleId());
    cModule *router = getParentModule()->getSubmodule(ROUTERA_MODULE_NAME);
    cModule *classifier = getParentModule()->getSubmodule(CLASSIFIERA_MODULE_NAME);

    // update booted server name
    int activeServerCount = pModel->getActiveServers();
    stringstream name;
    name << SERVERA_MODULE_NAME;
    name << "-";
    name << activeServerCount + 1;
    server->setName(name.str().c_str());

    // connect gates
    router->getOrCreateFirstUnconnectedGate("out", 0, false, true)->connectTo(server->gate("in"));
    server->gate("out")->connectTo(classifier->getOrCreateFirstUnconnectedGate("in", 0, false, true));

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAExecutionManager] executing doAddServerBootComplete(id=" << bootComplete->getModuleId()
                                  << "): update booted server name=" << server->getName() << " and connect gates"<< endl;
    }
}

void ServiceAExecutionManager::removeServer() {
    Enter_Method("removeServer()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAExecutionManager] executing removeServer()" << endl;
    }

    removeServerLatencyOptional(); // remove a server with offDelay
}

void ServiceAExecutionManager::removeServerLatencyOptional(bool instantaneous) {

    int moduleId = pModel->popServerPool();

    ServiceABootComplete* bootComplete = new ServiceABootComplete;
    bootComplete->setModuleId(moduleId);
    bootComplete->setExpectedChange("removeServerADelay");

    double offDelay = 0;
    if (!instantaneous) {
        offDelay = getParentModule()->par("offDelay").doubleValue();

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceAExecutionManager] removing server(id="<< bootComplete->getModuleId() <<") with latency=" << offDelay << endl;
        }
    }

    // add offDelay
    std::string serverName = getSimulation()->getModule(moduleId)->getName();
    int serverId = atoi(serverName.substr(8).c_str());
    cout << "t=" << simTime() << " [ServiceAExecutionManager] serverName="<< serverName <<" serverId=" << serverId << endl;

    ServerRemovalEvent event;
    event.moduleId = moduleId;
    event.serverId = serverId;
    event.offDelay = offDelay;
    serverRemovalEvents.insert(event);

    // add expected SERVER_OFFLINE changes
    pModel->removeServer(offDelay);

    if (offDelay == 0) {
        handleMessage(bootComplete);
    } else {
        scheduleAt(simTime() + offDelay, bootComplete);
    }
}

void ServiceAExecutionManager::doRemoveServer(ServiceABootComplete* bootComplete) {

    int moduleId = bootComplete->getModuleId();

    // pop moduleId of smallest serverId
    double offDelay = 0.0;
    if (!serverRemovalEvents.empty()) {
        ServerRemovalEvents::iterator it = serverRemovalEvents.end();
        it--;
        moduleId = it->moduleId;
        offDelay = it->offDelay;
        serverRemovalEvents.erase(it);

        cout << "t=" << simTime() << " [ServiceAExecutionManager] doRemoveServer new moduleId=" << moduleId << " offDelay=" << offDelay << endl;
    }

    // disconnect module
    cModule *module = getSimulation()->getModule(moduleId);
    cGate* pInGate = module->gate("in");
    if (pInGate->isConnected()) {
        cGate *otherEnd = pInGate->getPathStartGate();
        otherEnd->disconnect();
        ASSERT(otherEnd->getIndex() == otherEnd->getVectorSize()-1);

        // reduce the size of the out gate in the queue module
        otherEnd->getOwnerModule()->setGateSize(otherEnd->getName(), otherEnd->getVectorSize()-1);
        // this is probably leaking memory because the gate may not be being deleted
    }

    if(cmdenvLogging) {
         std::cout << "t=" << simTime() << " [ServiceAExecutionManager] doRemoveServer(id=" << moduleId << "): moduleName=" << module->getName() << endl;
    }

    // check to see if we can delete the server immediately (or if it's busy)
    if (isServerBeingRemoveEmpty(moduleId)) {
        completeServerRemoval(moduleId);
    } else {
        serverABeingRemovedModuleIds.push_back(moduleId);
    }
}

void ServiceAExecutionManager::completeServerRemoval(int moduleId) {
    Enter_Method("sendMe()");

    // clear cache for server, so that the next time it is instantiated it is fresh
    cModule* module = getSimulation()->getModule(moduleId);
    check_and_cast<ServiceAMTBrownoutServer*>(module->getSubmodule(INTERNAL_SERVERA_MODULE_NAME))->clearServerCache();

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAExecutionManager] completeServerRemoval(id="<< moduleId <<"): clearServerCache" << endl;
    }

    ServiceABootComplete* pBootComplete = new ServiceABootComplete;
    pBootComplete->setModuleId(moduleId);
    pBootComplete->setExpectedChange("removeServerA");

    scheduleAt(simTime(), pBootComplete);
}

bool ServiceAExecutionManager::isServerBeingRemoveEmpty(int moduleId) {

    bool isEmpty = false;
    cModule* module = getSimulation()->getModule(moduleId);
    ServiceAMTBrownoutServer* internalServer = check_and_cast<ServiceAMTBrownoutServer*> (module->getSubmodule(INTERNAL_SERVERA_MODULE_NAME));
    if (internalServer->isEmpty()) {
        queueing::PassiveQueue* queue = check_and_cast<queueing::PassiveQueue*> (module->getSubmodule(INTERNAL_QUEUEA_MODULE_NAME));
        if (queue->length() == 0) {
            isEmpty = true;
        }
    }

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAExecutionManager] isServerBeingRemoveEmpty=" << isEmpty << endl;
    }

    return isEmpty;
}

void ServiceAExecutionManager::notifyRemoveServerCompleted(const char* serverId) {

    // update model for notify remove server completed
    pModel->serverBecameShutDown();

    // emit signal to notify others (notably simProbe)
    emit(serverARemovedSignal, serverId);
}

void ServiceAExecutionManager::receiveSignal(cComponent *source, simsignal_t signalID, bool value, cObject *details) {

    if (signalID == serverABusySignal && value == false) {
        std::vector<int>::iterator it = std::find(serverABeingRemovedModuleIds.begin(), serverABeingRemovedModuleIds.end(), source->getParentModule()->getId());

        if (it != serverABeingRemovedModuleIds.end()) {

            int serverABeingRemovedModuleId = it[0];
            serverABeingRemovedModuleIds.erase(it);

            if(cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceAExecutionManager] serverABeingRemovedModuleId=" << serverABeingRemovedModuleId << endl;
            }

            if (isServerBeingRemoveEmpty(serverABeingRemovedModuleId)) {
                completeServerRemoval(serverABeingRemovedModuleId);
            }
        }
    }
}
