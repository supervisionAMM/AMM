/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <cmath>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include "managers/model/ServiceAUtilityScorer.h"
#include "ServiceASimMonitor.h"

Define_Module(ServiceASimMonitor);

void ServiceASimMonitor::initialize(int stage) {
    if (stage == 1) {

        pModel = check_and_cast<ServiceAModel*>(getParentModule()->getSubmodule("modelA"));
        pSimProbe = check_and_cast<ServiceASimProbe*>(getParentModule()->getSubmodule("simProbeA"));

        // logging
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

        // identification
        cXMLElement *identTriggerNode = getSimulation()->getSystemModule()->par("identTriggerXML").xmlValue();
        identTrigger = string(identTriggerNode->getNodeValue())=="true" ? 1 : 0;

        cXMLElement *identServiceModuleNode = getSimulation()->getSystemModule()->par("identServiceModuleXML").xmlValue();
        identServiceModule = string(identServiceModuleNode->getNodeValue());

        // control
        cXMLElement *controlTriggerNode = getParentModule()->par("controlTriggerXML").xmlValue();
        controlTrigger = string(controlTriggerNode->getNodeValue())=="true" ? 1 : 0;

        controlPeriod = getParentModule()->par("controlPeriod").doubleValue();
        warmUpPeriod = getParentModule()->par("warmUpPeriod").doubleValue();

        // supervision
        cXMLElement *supervisionTriggerNode = getParentModule()->par("supervisionTriggerXML").xmlValue();
        supervisionTrigger = string(supervisionTriggerNode->getNodeValue())=="true" ? 1 : 0;

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceASimMonitor] initialize"
                                      << " identTrigger="       << identTrigger
                                      << " identServiceModule=" << identServiceModule
                                      << " controlTrigger="     << controlTrigger
                                      << " controlPeriod="      << controlPeriod
                                      << " warmUpPeriod="       << warmUpPeriod
                                      << " supervisionTrigger=" << supervisionTrigger << endl;
        }

        // create the event objects we'll use for timing
        periodEvent = new cMessage("periodEvent");
        scheduleAt(controlPeriod, periodEvent);
    }
}

void ServiceASimMonitor::handleMessage(cMessage *msg) {
    /*
     * the monitoring is divided into two parts:
     * One updates environment, observations and utility
     * One triggers adaptation and supervision
     */
    if (msg == periodEvent) {
        periodicHandler();
        scheduleAt(simTime() + controlPeriod, periodEvent);

        if (simTime() > warmUpPeriod) {

            // measurements
            measuredArrivalRate = pModel->getEnvironment().getArrivalRate();

            double sensorNoise = par("sensorNoise");
            while(pModel->getObservations().avgResponseTime + sensorNoise<0.0){
                sensorNoise = par("sensorNoise");
            }
            measuredAvgRespTime = pModel->getObservations().avgResponseTime + sensorNoise;

            // identification or control
            if (identTrigger && identServiceModule=="serviceA") {
                // ident
                cModule *identModule = getParentModule()->getSubmodule("dataCollectionA");
                sendDirect(new cMessage("identEvent"), identModule, "in");

            } else if (!identTrigger) {
                // utility
                double serviceAUtility = ServiceAUtilityScorer::getAccruedUtility(pModel, measuredArrivalRate, measuredAvgRespTime);
                pModel->setUtility(serviceAUtility);

                // control with/without supervision
                if (controlTrigger && supervisionTrigger) {
                    cMessage *supervisionEvent = new cMessage("supervisionEvent");
                    send(supervisionEvent, "sv");

                } else if (controlTrigger) {
                    cMessage *controlEvent = new cMessage("controlEvent");
                    send(controlEvent, "ctrl");
                }
            }
        }
    }
}

void ServiceASimMonitor::periodicHandler() {
    environment = pSimProbe->getUpdatedEnvironment();
    pModel->setEnvironment(environment);

    observations = pSimProbe->getUpdatedObservations();
    pModel->setObservations(observations);
}

double ServiceASimMonitor::getMeasuredArrivalRate() {
    return measuredArrivalRate;
}

double ServiceASimMonitor::getMeasuredAvgRespTime() {
    return measuredAvgRespTime;
}
