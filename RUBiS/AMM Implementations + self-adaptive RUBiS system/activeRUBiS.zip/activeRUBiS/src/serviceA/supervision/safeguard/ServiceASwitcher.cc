/*******************************************************************************
 * Controller Switcher.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "ServiceASwitcher.h"

Define_Module(ServiceASwitcher);

void ServiceASwitcher::initialize() {}

void ServiceASwitcher::handleMessage(cMessage *msg)
{
    if (triggerMandatoryCtrl) {
        send(msg, "manCtrl");
    }
    else {
        send(msg, "piCtrl");
    }
}

bool ServiceASwitcher::getSwitcherMode() {
    return triggerMandatoryCtrl;
}

void ServiceASwitcher::setSwitcherMode(bool MCtrl) {
    triggerMandatoryCtrl = MCtrl;
}
