import numpy as np
from scipy import stats


def degradation_detector(delta):
    # alarm if derived probability of occurring delta value of
    # the managed system's output does not exceed the probability threshold

    # degradation parameters
    loc = 0.0
    scale = 0.1443
    prob_6sigma = 0.999999981 # 6sigma

    if delta <= loc:
        cdf = stats.norm.cdf(delta, loc, scale)
    else:
        cdf = 1.0 - stats.norm.cdf(delta, loc, scale)

    alarm = 0
    if cdf < (1.0 - prob_6sigma) / 2.0:
        alarm = 1

    return alarm


class MoD2:
    # model-guided deviation detector

    def __init__(self):
        # nominal model parameters
        ## x(k) = A*x(k-1) + B*u(k-1)
        ## y(k) = C*x(k)
        ## subject to: x(k) = [x'(k); I], u(k-1) = [u'(k-1); 0]
        ##             A = [A', 0; 0, I], B = [B', 0; 0, 0], C = [C', beta]
        ## -->
        ## x'(k) = A'*x'(k-1) + B'*u'(k-1)
        ## y(k) = C'*x'(k) + beta
        ## subject to: x'(k) = [x''(k); x''(k-1)], u'(k-1) = [u''(k-1); 0]
        ##             A' = [0, 0; A'', 0], B' = [B''; 0], C' = [0, C'']
        self.A_prime = np.array([[0.0, 0.0],
                                 [1.0, 0.0]])

        self.B_prime = np.array([[-0.1042],
                                 [0.0]])

        self.C_prime = np.array([[0.0, 1.0]])

        # deviated model parameter
        self.B_k_prior = np.copy(self.B_prime)  # using copy to avoid change together
        self.P_k_prior = np.array([[1e-06, 0.0],
                                   [0.0, 0.0]])
        self.B_k_posterior = np.copy(self.B_prime)
        self.P_k_posterior = np.copy(self.P_k_prior)
        # system state
        self.delta_state_prior = np.zeros((2, 1))
        self.delta_state_var_prior = np.zeros((2, 2))
        self.delta_state_posterior = np.zeros((2, 1))
        self.delta_state_var_posterior = np.zeros((2, 2))

        # uncertainty of model parameter value
        ## process noise
        self.Q_prime = np.array([[1e-06, 0.0],
                                 [0.0, 0.0]])

        # uncertainty compensation terms
        ## delta_x(k) = A*delta_x(k-1) + B*delta_u(k-1) + gamma*delta_a(k) + w(k)
        ## delta_y(k) = C*delta_x(k) + v(k)
        ## subject to: delta_x(k) = [delta_x'(k); 0], delta_u(k-1) = [delta_u'(k-1); 0], delta_a(k) = [delta_a'(k); 0]
        ##             A = [A', 0; 0, I], B = [B', 0; 0, 0], gamma = [gamma', alpha; 0, 0], C = [C', beta]
        ##             w(k) = [w'(k); 0]
        ## -->
        ## delta_x'(k) = A'*delta_x'(k-1) + B'*delta_u'(k-1) + gamma'*delta_a'(k)  + w'(k)
        ## delta_y(k) = C'*delta_x'(k) + v(k)
        ## subject to: x'(k) = [x''(k); x''(k-1)], u'(k-1) = [u''(k-1); 0], a'(k) = [0; a''(k)],
        ##             A' = [0, 0; A'', 0], B' = [B''; 0], gamma' = [0; gamma''], C' = [0, C'']
        ##             w'(k) = [0; w''(k)]

        ## environment model
        self.gamma_prime = np.array([[0.0],
                                     [0.0050]])
        self.W_prime = np.array([[0.0, 0.0],
                                 [0.0, 0.0003]])

        ## sensor noise
        self.V = np.array([[2.0e-06]])

        # safe region
        self.pole = 0.9
        self.safe_region = [1.0 / (4.0 * (1 - self.pole)) * self.B_prime[0][0], 0.0]  # [2.5*B, 0.0]

        # probability threshold
        self.prob_threshold = 0.9973  # 3sigma

        # alarm signal
        self.alarm = 0

        # historical measurements
        self.list_u = []  # historical controller output
        self.list_a = []  # historical environmental input
        self.list_y = []  # historical managed system output

    def deviation_detector(self, u_1, a, y):

        if len(self.list_u) < 4:
            self.list_u.append(u_1)
            self.list_a.append(a)
            self.list_y.append(y)
        else:
            self.list_u.append(u_1)
            self.list_a.append(a)
            self.list_y.append(y)

            # state estimation
            ## input: time series observation
            ##  [0]     [1]     [2]     [3]     [4]
            ## u(k-5), u(k-4), u(k-3), u(k-2), u(k-1)
            ## a(k-4), a(k-3), a(k-2), a(k-1), a(k)
            ## y(k-4), y(k-3), y(k-2), y(k-1), y(k)
            delta_y_3 = self.list_y[1] - self.list_y[0]
            delta_u_3 = self.list_u[2] - self.list_u[1]
            delta_a_2 = self.list_a[2] - self.list_a[1]

            ## output: delta_state_prior, delta_state_var_prior
            self.delta_state_posterior, \
            self.delta_state_var_posterior, \
            self.delta_state_prior, \
            self.delta_state_var_prior = self.observer(self.B_k_posterior,
                                                       self.delta_state_prior,
                                                       self.delta_state_var_prior,
                                                       delta_y_3, delta_u_3, delta_a_2)

            # model parameter estimation and deviation detection
            delta_u_2 = self.list_u[3] - self.list_u[2]
            if abs(delta_u_2) > 0:
                ## input: time series observation
                delta_a_1 = self.list_a[3] - self.list_a[2]
                delta_a_0 = self.list_a[4] - self.list_a[3]
                delta_y_0 = self.list_y[4] - self.list_y[3]

                ## output: B_k_posterior, P_k_posterior
                self.B_k_prior, \
                self.P_k_prior, \
                self.B_k_posterior, \
                self.P_k_posterior = self.estimator(self.delta_state_prior,
                                                    self.delta_state_var_prior,
                                                    self.B_k_posterior,
                                                    self.P_k_posterior,
                                                    delta_u_2, delta_a_1, delta_a_0, delta_y_0)

                # alarmer
                self.alarm = self.deviation_alarmer(self.B_k_posterior, self.P_k_posterior)

                # print("\n********** passive decision **********")
                # print("delta_u_2: {}".format(delta_u_2))
                # print("delta_y_0: {}".format(delta_y_0))
                # print("B0_k_prior: {}".format(self.B_k_prior[0][0]))
                # print("P0_k_prior: {}".format(self.P_k_prior[0][0]))
                # print("B0_k_posterior: {}".format(self.B_k_posterior[0][0]))
                # print("P0_k_posterior: {}\n".format(self.P_k_posterior[0][0]))
                # print("alarm:{}\n".format(self.alarm))

            else:
                setpoint = 0.3
                delta = self.list_y[4] - setpoint
                self.alarm = degradation_detector(delta)

                # print("\n********** degradation decision **********")
                # print("delta: {}".format(delta))
                # print("alarm:{}\n".format(self.alarm))

            # update historical measurements
            self.list_u.remove(self.list_u[0])
            self.list_a.remove(self.list_a[0])
            self.list_y.remove(self.list_y[0])

        return self.B_k_posterior[0][0], self.P_k_posterior[0][0], self.alarm

    def observer(self, B_k_posterior, delta_state_prior, delta_state_var_prior, delta_y_3, delta_u_3, delta_a_2):
        # refined nominal model
        ## delta_y(k-3) = C'*delta_x'(k-3) + v(k-3)
        ## delta_x'(k-2) = A'*delta_x'(k-3) + B'*delta_u'(k-3) + gamma'*delta_a'(k-2) + w'(k-2)

        # update process
        ## observation model which maps the true state space into the observed space
        H = self.C_prime

        ## measurement pre-fit residual
        R_k = delta_y_3 - np.dot(H, delta_state_prior)

        ## pre-fit residual variance
        S_k = np.dot(np.dot(H, delta_state_var_prior), H.T) + self.V

        ## updated Kalman gain
        K = np.dot(np.dot(delta_state_var_prior, H.T), np.linalg.inv(S_k))

        ## updated (a posteriori) state estimate
        delta_state_posterior = delta_state_prior + np.dot(K, R_k)

        ## updated (a posteriori) state estimate variance
        delta_state_var_posterior = np.dot((np.eye(len(delta_state_var_prior)) - np.dot(K, H)), delta_state_var_prior)

        # prediction process
        ## predicted (a priori) state estimate
        delta_state_prior = np.dot(self.A_prime, delta_state_posterior) + np.dot(B_k_posterior, delta_u_3) + \
                            np.dot(self.gamma_prime, delta_a_2)

        ## predicted (a priori) state estimate variance
        delta_state_var_prior = np.dot(np.dot(self.A_prime, delta_state_var_posterior), self.A_prime.T) + self.W_prime

        return delta_state_posterior, delta_state_var_posterior, delta_state_prior, delta_state_var_prior

    def estimator(self, delta_state_prior, delta_state_var_prior, B_k_posterior, P_k_posterior,
                  delta_u_2, delta_a_1, delta_a_0, delta_y_0):
        # refined nominal model
        ## B'(k) = B'(k-1) + q(k)
        ## delta_y(k) = C'*A'*A'*delta_x'(k-2) + C'*A'*B'*delta_u'(k-2) + C'*A'*gamma'*delta_a'(k-1) +
        ##              C'*gamma'*delta_a'(k) + C'*A'*w'(k) + C'*w'(k) + v(k)

        # prediction process
        ## predicted (a priori) model parameter estimate
        B_k_prior = np.copy(B_k_posterior)

        ## predicted (a priori) model parameter estimate variance
        P_k_prior = P_k_posterior + self.Q_prime

        # update process
        ## observation model which maps the true model parameter space into the observed space
        H = np.dot(np.dot(self.C_prime, self.A_prime), delta_u_2)

        ## measurement pre-fit residual
        S1 = np.dot(np.dot(np.dot(self.C_prime, self.A_prime), self.A_prime), delta_state_prior)
        # print("S1: {}".format(S1))

        S2 = np.dot(H, B_k_prior)
        # print("S2: {}".format(S2))

        S3 = np.dot(np.dot(np.dot(self.C_prime, self.A_prime), self.gamma_prime), delta_a_1)
        # print("S3: {}".format(S3))

        S4 = np.dot(np.dot(self.C_prime, self.gamma_prime), delta_a_0)
        # print("S4: {}".format(S4))

        # print("delta_y_0: {}".format(delta_y_0))
        R_k = delta_y_0 - (S1 + S2 + S3 + S4)

        Matrix = np.dot(self.C_prime, np.dot(self.A_prime, self.A_prime))
        S_k = np.dot(np.dot(Matrix, delta_state_var_prior), Matrix.T) + \
              np.dot(np.dot(H, P_k_prior), H.T) + \
              np.dot(np.dot(np.dot(self.C_prime, self.A_prime), self.W_prime), np.dot(self.C_prime, self.A_prime).T) + \
              np.dot(np.dot(self.C_prime, self.W_prime), self.C_prime.T) + self.V

        ## updated Kalman gain
        K = np.dot(np.dot(P_k_prior, H.T), np.linalg.inv(S_k))

        ## updated (a posteriori) model parameter estimate
        B_k_posterior = B_k_prior + np.dot(K, R_k)

        ## updated (a posteriori) model parameter estimate variance
        P_k_posterior = np.dot((np.eye(len(P_k_prior)) - np.dot(K, H)), P_k_prior)

        return B_k_prior, P_k_prior, B_k_posterior, P_k_posterior

    def deviation_alarmer(self, B_k_posterior, P_k_posterior):
        # alarm if the derived probability that model parameter value
        # falls into safe region does not exceed the probability threshold

        loc = B_k_posterior[0][0]
        scale = np.sqrt(P_k_posterior[0][0])
        self.cdf = stats.norm.cdf(self.safe_region[1], loc, scale) - stats.norm.cdf(self.safe_region[0], loc, scale)

        alarm = 0
        if self.cdf < self.prob_threshold:
            alarm = 1

        return alarm

    def get_delta_state_prior(self):
        return self.delta_state_prior

    def get_delta_state_var_prior(self):
        return self.delta_state_var_prior

    def get_B0_k_prior(self):
        return self.B_k_prior[0][0]

    def get_P0_k_prior(self):
        return self.P_k_prior[0][0]