/*******************************************************************************
 * Model Deviation Detector.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <boost/tokenizer.hpp>
#include "ServiceADetector.h"

Define_Module(ServiceADetector);

ServiceADetector::ServiceADetector() {
}

ServiceADetector::~ServiceADetector() {
    if (supervisionTrigger) {
        // finish Python interpreter
        Py_Finalize();
    }
}

void ServiceADetector::initialize() {

    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

    // supervision
    cXMLElement *supervisionTriggerNode = getParentModule()->par("supervisionTriggerXML").xmlValue();
    supervisionTrigger = string(supervisionTriggerNode->getNodeValue())=="true" ? 1 : 0;

    if (supervisionTrigger) {

        cXMLElement *supervisionTypeNode = getParentModule()->par("supervisionTypeXML").xmlValue();
        supervisionType = string(supervisionTypeNode->getNodeValue());

        cXMLElement *switchTriggerXMLNode = getParentModule()->par("switchTriggerXML").xmlValue();
        switchTrigger = string(switchTriggerXMLNode->getNodeValue())=="true" ? 1 : 0;

        // initializes python interpreter
        Py_Initialize();

        // import python script and construct the instance
        PyRun_SimpleString("import sys");
        PyRun_SimpleString("sys.path.append('../../src/serviceA/supervision/detectors')");

        if (supervisionType == "SWDetectorPlus") {

            stable_loop = 28;
            timer = 28;

            PyObject *pModule = PyImport_ImportModule("serviceASWDetectorPlus");
            if (pModule == nullptr){
                   cout <<"[Error] Import module error" << endl;
            }

            PyObject *pClass = PyObject_GetAttrString(pModule, "SWDetector_Plus");
            if (pClass == nullptr){
                cout << "[Error] Import class error" << endl;
            }

            PyObject *initArgs = Py_BuildValue("(i)", logging);
            pInstance = PyObject_Call(pClass, initArgs, nullptr);
            if (pInstance == nullptr){
                cout << "[Error] Initialize instance error" << endl;
            }

            // sliding window size
            cXMLElement *slidingWindowSizeNode = getParentModule()->par("slidingWindowSizeXML").xmlValue();
            slidingWindowSize = atoi(slidingWindowSizeNode->getNodeValue());

            // sliding window size
            cXMLElement *errorThresholdNode = getParentModule()->par("errorThresholdXML").xmlValue();
            errorThreshold = atof(errorThresholdNode->getNodeValue());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceADetector] slidingWindowSize=" << slidingWindowSize << " errorThreshold=" << errorThreshold << endl;
            }

            PyObject *args1 = Py_BuildValue("(i)", slidingWindowSize);
            PyObject *pRet1 = PyObject_CallMethod(pInstance, "set_sliding_window_size", "O", args1);
            if (pRet1 == nullptr){
                cout << "[Error] No pRet returned" << endl;
            }

            PyObject *args2 = Py_BuildValue("(d)", errorThreshold);
            PyObject *pRet2 = PyObject_CallMethod(pInstance, "set_error_threshold", "O", args2);
            if (pRet2 == nullptr){
                cout << "[Error] No pRet returned" << endl;
            }

        } else if (supervisionType == "ARMAPlus") {

           stable_loop = 3;
           timer = 3;

           PyObject *pModule = PyImport_ImportModule("serviceAARMAPlus");
           if (pModule == nullptr){
                  cout <<"[Error] Import module error" << endl;
           }

           PyObject *pClass = PyObject_GetAttrString(pModule, "ARMA_Plus");
           if (pClass == nullptr){
               cout << "[Error] Import class error" << endl;
           }

           PyObject *initArgs = Py_BuildValue("(i)", logging);
           pInstance = PyObject_Call(pClass, initArgs, nullptr);
           if (pInstance == nullptr){
               cout << "[Error] Initialize instance error" << endl;
           }

           // sliding window size
           cXMLElement *slidingWindowSizeNode = getParentModule()->par("slidingWindowSizeXML").xmlValue();
           slidingWindowSize = atoi(slidingWindowSizeNode->getNodeValue());

           if (cmdenvLogging) {
               cout << "t=" << simTime() << " [ServiceADetector] slidingWindowSize=" << slidingWindowSize << endl;
           }

           PyObject *args = Py_BuildValue("(i)", slidingWindowSize);
           PyObject *pRet = PyObject_CallMethod(pInstance, "set_sliding_window_size", "O", args);
           if (pRet == nullptr){
               cout << "[Error] No pRet returned" << endl;
           }

        } else if (supervisionType == "MoD2Plus") {

            stable_loop = 3;
            timer = 3;

            cXMLElement *auxiliarySignalTriggerModeNode = getParentModule()->par("auxiliarySignalTriggerModeXML").xmlValue();
            auxiliarySignalTriggerMode = string(auxiliarySignalTriggerModeNode->getNodeValue());

            cXMLElement *auxiliarySignalDesignModeNode = getParentModule()->par("auxiliarySignalDesignModeXML").xmlValue();
            auxiliarySignalDesignMode = string(auxiliarySignalDesignModeNode->getNodeValue());

            PyObject *pModule = PyImport_ImportModule("serviceAMoD2Plus");
            if (pModule == nullptr){
                   cout <<"[Error] Import module error" << endl;
            }

            PyObject *pClass = PyObject_GetAttrString(pModule, "MoD2_Plus");
            if (pClass == nullptr){
                cout << "[Error] Import class error" << endl;
            }

            PyObject *initArgs = Py_BuildValue("(iss)", logging, auxiliarySignalTriggerMode.c_str(), auxiliarySignalDesignMode.c_str());
            pInstance = PyObject_Call(pClass, initArgs, nullptr);
            if (pInstance == nullptr){
                cout << "[Error] Initialize instance error" << endl;
            }

            // timing_trigger
            if (auxiliarySignalTriggerMode == "timing_trigger") {
                cXMLElement *timingIntervalNode = getParentModule()->par("timingIntervalXML").xmlValue();
                timingInterval = atoi(timingIntervalNode->getNodeValue());

                if (cmdenvLogging) {
                    cout << "t=" << simTime() << " [ServiceADetector] timingInterval=" << timingInterval << endl;
                }

                PyObject *args = Py_BuildValue("(i)", timingInterval);
                PyObject *pRet = PyObject_CallMethod(pInstance, "set_timing_interval", "O", args);
                if (pRet == nullptr){
                    cout << "[Error] No pRet returned" << endl;
                }
            }

            // random_design
            if (auxiliarySignalDesignMode == "random_design") {
                cXMLElement *rndSeedNode = getParentModule()->par("rndSeedXML").xmlValue();
                rndSeed = atoi(rndSeedNode->getNodeValue());

                if (cmdenvLogging) {
                    cout << "t=" << simTime() << " [ServiceADetector] rndSeed=" << rndSeed << endl;
                }

                PyObject *args = Py_BuildValue("(i)", rndSeed);
                PyObject *pRet = PyObject_CallMethod(pInstance, "set_rnd_seed", "O", args);
                if (pRet == nullptr){
                    cout << "[Error] No pRet returned" << endl;
                }
            }
        }

        // tracing
        supervisionFilePath = "../results/serviceA" + supervisionType + "Trace.txt";

        // delete old supervision trace file
        ifstream cpFin(supervisionFilePath.c_str());
        if (!cpFin) {
            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceADetector] " << supervisionFilePath << " does not exist" << endl;
            }
        } else {
            remove(supervisionFilePath.c_str());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceADetector] Delete " << supervisionFilePath << endl;
            }
        }

        // first line of supervision trace file
        ofstream out;
        out.open(supervisionFilePath.c_str(), ios::app);
        if (out.is_open()) {
            if (supervisionType == "SWDetectorPlus") {
                out << "controlServers_{k-1},";
                out << "measuredArrivalRate_{k},";
                out << "measuredAvgRespTime_{k},";
                out << "B_k_prior,";
                out << "P_k_prior," ;
                out << "avgErrorDist,";
                out << "alarm,";
                out << "activeFlag,";
                out << "optAS\n";
                out.close();

            } else if (supervisionType == "ARMAPlus") {
                out << "controlServers_{k-1},";
                out << "measuredArrivalRate_{k},";
                out << "measuredAvgRespTime_{k},";
                out << "B_k_prior,";
                out << "P_k_prior," ;
                out << "predictionError,";
                out << "alarm,";
                out << "activeFlag,";
                out << "optAS\n";
                out.close();

            } else if (supervisionType == "MoD2Plus") {
                out << "controlServers_{k-1},";
                out << "measuredArrivalRate_{k},";
                out << "measuredAvgRespTime_{k},";
                out << "B_k_posterior,";
                out << "P_k_posterior,";
                out << "B_k_predict,";
                out << "P_k_predict,";
                out << "alarm,";
                out << "activeFlag,";
                out << "optAS\n";
                out.close();
            }
        }

        pMonitor = check_and_cast<ServiceASimMonitor*>(getParentModule()->getSubmodule("simMonitorA"));
        pCtrl = check_and_cast<ServiceAPIController*>(getParentModule()->getSubmodule("PIControllerA"));
        pSwitcher = check_and_cast<ServiceASwitcher*>(getParentModule()->getSubmodule("switcherA"));
    }
}

void ServiceADetector::handleMessage(cMessage *msg) {

    controlServers = pCtrl->getControlServers();
    measuredArrivalRate =  pMonitor->getMeasuredArrivalRate();
    measuredAvgRespTime = pMonitor->getMeasuredAvgRespTime();

    cout << "t=" << simTime() << " [ServiceADetector] controlServers[" << num << "]=" << controlServers
                                            << " measuredArrivalRate[" << num << "]=" << measuredArrivalRate
                                            << " measuredAvgRespTime[" << num << "]=" << measuredAvgRespTime << endl;

    bool triggerMandatoryCtrl = pSwitcher->getSwitcherMode();
    if (not triggerMandatoryCtrl) {
        deviationDetector(controlServers, measuredArrivalRate, measuredAvgRespTime);
    }

    send(msg, "out");

    num = num + 1;
}

void ServiceADetector::deviationDetector(int controlServers, double measuredArrivalRate, double measuredAvgRespTime){

    if (supervisionType == "SWDetectorPlus") {
        PyObject *mainArgs = Py_BuildValue("(id)", controlServers, measuredAvgRespTime);
        PyObject *mainPRet = PyObject_CallMethod(pInstance, "deviation_detector", "O", mainArgs);
        if (mainPRet == nullptr){
            cout << "[Error] No pRet returned" << endl;
        }

        //returned alarm signal
        PyArg_ParseTuple(mainPRet, "d|d|d|i|i|i", &B_k_prior, &P_k_prior, &avgErrorDist, &alarm, &activeFlag, &optAS);
        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceADetector] supervisionType[" << num << "]=" << supervisionType
                                                               << " B_k_prior[" << num << "]=" << B_k_prior
                                                               << " P_k_prior[" << num << "]=" << P_k_prior
                                                            << " avgErrorDist[" << num << "]=" << avgErrorDist
                                                                   << " alarm[" << num << "]=" << alarm
                                                              << " activeFlag[" << num << "]=" << activeFlag
                                                                   << " optAS[" << num << "]=" << optAS << endl;
        }

    } else if (supervisionType == "ARMAPlus") {
               PyObject *mainArgs = Py_BuildValue("(id)", controlServers, measuredAvgRespTime);
               PyObject *mainPRet = PyObject_CallMethod(pInstance, "deviation_detector", "O", mainArgs);
               if (mainPRet == nullptr){
                   cout << "[Error] No pRet returned" << endl;
               }

               //returned alarm signal
               PyArg_ParseTuple(mainPRet, "d|d|d|i|i|i", &B_k_prior, &P_k_prior, &predictionError, &alarm, &activeFlag, &optAS);
               if (cmdenvLogging) {
                   cout << "t=" << simTime() << " [ServiceADetector] supervisionType[" << num << "]=" << supervisionType
                                                                      << " B_k_prior[" << num << "]=" << B_k_prior
                                                                      << " P_k_prior[" << num << "]=" << P_k_prior
                                                                << " predictionError[" << num << "]=" << predictionError
                                                                          << " alarm[" << num << "]=" << alarm
                                                                     << " activeFlag[" << num << "]=" << activeFlag
                                                                          << " optAS[" << num << "]=" << optAS << endl;
               }

    } else if (supervisionType == "MoD2Plus") {
        PyObject *mainArgs = Py_BuildValue("(idd)", controlServers, measuredArrivalRate, measuredAvgRespTime);
        PyObject *mainPRet = PyObject_CallMethod(pInstance, "deviation_detector", "O", mainArgs);
        if (mainPRet == nullptr){
            cout << "[Error] No pRet returned" << endl;
        }

        //returned alarm signal
        PyArg_ParseTuple(mainPRet, "d|d|d|d|i|i|i", &B_k_posterior, &P_k_posterior, &B_k_predict, &P_k_predict, &alarm, &activeFlag, &optAS);
        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceADetector] supervisionType[" << num << "]=" << supervisionType
                                                           << " B_k_posterior[" << num << "]=" << B_k_posterior
                                                           << " P_k_posterior[" << num << "]=" << P_k_posterior
                                                             << " B_k_predict[" << num << "]=" << B_k_predict
                                                             << " P_k_predict[" << num << "]=" << P_k_predict
                                                                   << " alarm[" << num << "]=" << alarm
                                                              << " activeFlag[" << num << "]=" << activeFlag
                                                                   << " optAS[" << num << "]=" << optAS << endl;
        }
    }

    // stop simulation if alarm
    if (alarm == 1) {
        getSimulation()->setSimulationTimeLimit(simTime() + 5.0);
    }

    // active part
    if (activeFlag == 1 and timer > 0) {

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceADetector] activeFlag[" << num << "]=" << activeFlag
                                                              << " optAS[" << num << "]=" << optAS
                                                              << " stable_loop[" << num << "]=" << stable_loop
                                                              << " timer[" << num << "]=" << timer << endl;
        }

        // set auxiliary signal
        if (timer >= stable_loop) {
            // save historic info
            controlServersOld = controlServers;
            measuredArrivalRateOld = measuredArrivalRate;
            historicOptAS = optAS;

            pCtrl->setActiveFlag(activeFlag);
            pCtrl->setOptAS(optAS);

        } else {
            // reset
            optAS = 0;
        }

        //timing
        timer = timer - 1;

    } else if (abs(historicOptAS) > 0) {

       if (timer >= 1) {
           //timing
           timer = timer - 1;

       } else {
            // recovery condition
            int deltaCS = controlServers - controlServersOld;
            double deltaArr = measuredArrivalRate - measuredArrivalRateOld;

            if (abs(deltaArr) < MAX_SERVICE_RATE and deltaCS == historicOptAS){
                recoveryFlag = 1;
                recoveryAS = 0 - historicOptAS;

                // reset
                optAS = 0;
                historicOptAS = 0;
            }

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceADetector] recoveryFlag[" << num << "]=" << recoveryFlag << " timer[" << num << "]=" << timer << " recoveryAS[" << num << "]=" << recoveryAS << endl;
            }

            // recovery action
            if (recoveryFlag == 1){
                pCtrl->setRecoveryFlag(recoveryFlag);
                pCtrl->setRecoveryAS(recoveryAS);

                // reset
                recoveryAS = 0;
                timer = stable_loop;
            }
        }
    }

    // switch
    if (switchTrigger) {
        // set switcher
        if (alarm == 1) {
            pSwitcher->setSwitcherMode(true);
        }
    }

    // tracing
    writeTrace();
}

void ServiceADetector::writeTrace() {
    ofstream out;
    out.open(supervisionFilePath.c_str(), ios::app);
    if (out.is_open()) {
        if (supervisionType == "SWDetectorPlus") {
            out << controlServers;
            out << ",";
            out << measuredArrivalRate;
            out << ",";
            out << measuredAvgRespTime;
            out << ",";
            out << B_k_prior;
            out << ",";
            out << P_k_prior;
            out << ",";
            out << avgErrorDist;
            out << ",";
            out << alarm;
            out << ",";
            out << activeFlag;
            out << ",";
            out << optAS;
            out << "\n";
            out.close();

        } else if (supervisionType == "ARMAPlus") {
            out << controlServers;
            out << ",";
            out << measuredArrivalRate;
            out << ",";
            out << measuredAvgRespTime;
            out << ",";
            out << B_k_prior;
            out << ",";
            out << P_k_prior;
            out << ",";
            out << predictionError;
            out << ",";
            out << alarm;
            out << ",";
            out << activeFlag;
            out << ",";
            out << optAS;
            out << "\n";
            out.close();

        } else if (supervisionType == "MoD2Plus") {
            out << controlServers;
            out << ",";
            out << measuredArrivalRate;
            out << ",";
            out << measuredAvgRespTime;
            out << ",";
            out << B_k_posterior;
            out << ",";
            out << P_k_posterior;
            out << ",";
            out << B_k_predict;
            out << ",";
            out << P_k_predict;
            out << ",";
            out << alarm;
            out << ",";
            out << activeFlag;
            out << ",";
            out << optAS;
            out << "\n";
            out.close();
        }
    }
}
