/*******************************************************************************
 * Data Collection for System Identification.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEADATACOLLECTION_H_
#define SERVICEADATACOLLECTION_H_

#include <omnetpp.h>
#include "managers/model/ServiceAModel.h"
#include "managers/monitor/ServiceASimMonitor.h"
#include "managers/execution/ServiceAExecutionManager.h"

using namespace omnetpp;
using namespace std;

class ServiceADataCollection : public cSimpleModule {

  public:
    struct MeasuredOutputsEvent {
        double measuredDimmer;
        int measuredServers;
        int measuredActiveServers;
        double measuredArrivalRate;
        double measuredAvgRespTime;
    };

    MeasuredOutputsEvent measuredOutputs;

    // logging
    bool cmdenvLogging;

    // identification
    bool identTrigger;
    string identServiceModule;
    string identFilePath;

    std::vector<double> identDimmerVec;
    std::vector<double> identServersVec;
    int identServers;

    // count
    int num = 0;

    ServiceAModel *pModel;
    ServiceASimMonitor *pMonitor;
    ServiceAExecutionManager* pExecMgr;

    MeasuredOutputsEvent getMeasuredOutputs();
    void setIdentControlParameters();
    void writeIdentTrace(MeasuredOutputsEvent measuredOutputs);
    std::vector<double> split(std::string str); /* split string(xml) to double vector */

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
