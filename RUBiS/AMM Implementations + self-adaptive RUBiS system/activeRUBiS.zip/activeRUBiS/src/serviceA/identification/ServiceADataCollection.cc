/*******************************************************************************
 * Data Collection for System Identification.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <boost/tokenizer.hpp>
#include "ServiceADataCollection.h"

Define_Module(ServiceADataCollection);

#define RNG 3

void ServiceADataCollection::initialize() {

    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

    // identification
    cXMLElement *identTriggerNode = getSimulation()->getSystemModule()->par("identTriggerXML").xmlValue();
    identTrigger = string(identTriggerNode->getNodeValue())=="true" ? 1 : 0;
    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceADataCollection] identTrigger " << identTrigger << endl;
    }

    cXMLElement *identServiceModuleNode = getSimulation()->getSystemModule()->par("identServiceModuleXML").xmlValue();
    identServiceModule = string(identServiceModuleNode->getNodeValue());

    if (identTrigger && identServiceModule=="serviceA") {

        cXMLElement *identDimmerVecNode = getSimulation()->getSystemModule()->par("identDimmerVecXML").xmlValue();
        identDimmerVec = split(identDimmerVecNode->getNodeValue());

        cXMLElement *identServersVecNode = getSimulation()->getSystemModule()->par("identServersVecXML").xmlValue();
        identServersVec = split(identServersVecNode->getNodeValue());

        cXMLElement *initialServersNode = getParentModule()->par("initialServersXML").xmlValue();
        identServers = atoi(initialServersNode->getNodeValue());

        pModel = check_and_cast<ServiceAModel*> (getParentModule()->getSubmodule("modelA"));
        pMonitor = check_and_cast<ServiceASimMonitor*> (getParentModule()->getSubmodule("simMonitorA"));
        pExecMgr = check_and_cast<ServiceAExecutionManager*> (getParentModule()->getSubmodule("executionManagerA"));

        // tracing
        identFilePath = "../ident/serviceAIdentTrace.txt";

        // delete old control trace file
        ifstream cpFin(identFilePath.c_str());
        if (!cpFin) {
            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceADataCollection] " << identFilePath << " does not exist" << endl;
            }
        } else {
            remove(identFilePath.c_str());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceADataCollection] Delete " << identFilePath << endl;
            }
        }

        // first line of control trace file
        ofstream out;
        out.open(identFilePath.c_str(), ios::app);
        if (out.is_open()) {
            out << "identServers_{k-1},";
            out << "measuredServers_{k},";
            out << "measuredActiveServers_{k},";
            out << "measuredArrivalRate_{k},";
            out << "measuredAvgRespTime_{k}\n";
            out.close();
        }
    }
}

void ServiceADataCollection::handleMessage(cMessage *msg) {
    measuredOutputs = getMeasuredOutputs();
    writeIdentTrace(measuredOutputs);
    setIdentControlParameters();

    // finished
    delete msg;
}

ServiceADataCollection::MeasuredOutputsEvent ServiceADataCollection::getMeasuredOutputs() {

    // update measurements
    measuredOutputs.measuredDimmer = (1.0 - pModel->getBrownoutFactor());
    measuredOutputs.measuredServers = pModel->getServers();
    measuredOutputs.measuredActiveServers = pModel->getActiveServers();
    measuredOutputs.measuredArrivalRate = pMonitor->getMeasuredArrivalRate();
    measuredOutputs.measuredAvgRespTime = pMonitor->getMeasuredAvgRespTime();

    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceADataCollection] measuredOutputs"
                                  << " measuredDimmer[" << num << "]="        << measuredOutputs.measuredDimmer
                                  << " measuredServers[" << num << "]="       << measuredOutputs.measuredServers
                                  << " measuredActiveServers[" << num << "]=" << measuredOutputs.measuredActiveServers
                                  << " measuredArrivalRate[" << num << "]="   << measuredOutputs.measuredArrivalRate
                                  << " measuredAvgRespTime[" << num << "]="   << measuredOutputs.measuredAvgRespTime << endl;
    }

    return measuredOutputs;
}

void ServiceADataCollection::setIdentControlParameters() {

    // set dimmer
    double dimmer = identDimmerVec[num];

    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceADataCollection] dimmer=" << dimmer << endl;
    }

    pExecMgr->setBrownout(1.0-dimmer);

    // set servers
    identServers = identServersVec[num];

    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceADataCollection] identServers=" << identServers << " servers=" << pModel->getServers() << " ativeServers=" << pModel->getActiveServers()<< endl;
    }

    if(identServers > pModel->getServers()) {
        int additionalServers = identServers - pModel->getServers();
        for(int i = 0; i < additionalServers; i++) {
            pExecMgr->addServer();
        }
    }
    else {
        int removalServers = pModel->getServers() - identServers;
        for(int i = 0; i < removalServers; i++) {
            pExecMgr->removeServer();
        }
    }

    num = num + 1;
}

void ServiceADataCollection::writeIdentTrace(MeasuredOutputsEvent measuredOutputs) {
    ofstream out;
    out.open(identFilePath.c_str(), ios::app);
    if (out.is_open()) {
        out << identServers;
        out << ",";
        out << measuredOutputs.measuredServers;
        out << ",";
        out << measuredOutputs.measuredActiveServers;
        out << ",";
        out << measuredOutputs.measuredArrivalRate;
        out << ",";
        out << measuredOutputs.measuredAvgRespTime;
        out << "\n";
        out.close();
    }
}

std::vector<double> ServiceADataCollection::split(std::string identStr) {
    std::vector<double> results;
    typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
    tokenizer tokens(identStr, boost::char_separator<char>(","));
    tokenizer::iterator it = tokens.begin();

    int splitNum = 0;
    cout << "t=" << simTime() << " [ServiceADataCollection] ";
    if (it != tokens.end()) {
        while (it != tokens.end()) {
            results.push_back(atof((*it).c_str()));
            splitNum++;
            std::cout << atof((*it).c_str()) << ",";
            it++;
        }
    }
    cout << endl;
    cout << "t=" << simTime() << " [ServiceADataCollection] splitNum=" << splitNum << endl;

    return results;
}
