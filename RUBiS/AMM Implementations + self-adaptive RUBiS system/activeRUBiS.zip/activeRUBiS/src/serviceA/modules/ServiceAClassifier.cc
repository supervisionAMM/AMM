/*******************************************************************************
 * Job Classifier.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "Job.h"
#include "ServiceAClassifier.h"

Define_Module(ServiceAClassifier);

void ServiceAClassifier::initialize()
{
    dispatchField = par("dispatchField");
}

void ServiceAClassifier::handleMessage(cMessage *msg)
{
    queueing::Job *job = check_and_cast<Job*>(msg);

    int outGateIndex = -1;
    if (strcmp(dispatchField, "type") == 0){
        outGateIndex = job->getKind();
    }

    if (outGateIndex < 0 || outGateIndex >= gateSize("out")) {
        send(job, "rest");
    }
    else {
        send(job, "out", outGateIndex);
    }
}
