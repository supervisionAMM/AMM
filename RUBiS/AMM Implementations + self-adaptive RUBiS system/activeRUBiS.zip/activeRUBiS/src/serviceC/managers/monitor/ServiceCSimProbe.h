/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICECSIMPROBE_H_
#define SERVICECSIMPROBE_H_

#include "managers/util/ServiceCTimeWindowStats.h"
#include "managers/model/ServiceCModel.h"

using namespace omnetpp;
using namespace std;

/**
 * This class collects statistics from the simulated system
 */
class ServiceCSimProbe : public omnetpp::cSimpleModule, omnetpp::cListener {

  public:
    //logging
    bool cmdenvLogging;

    //control
    double controlPeriod;

    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, const omnetpp::SimTime& t, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, double value, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, bool value, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, const char* value, cObject *details) override;

    double getUtilization(const std::string& serverName);

    ServiceCObservations getUpdatedObservations();
    ServiceCEnvironment getUpdatedEnvironment();

  protected:
    /* subscribed arrivalMonitor signals */
    simsignal_t serviceCInterArrivalSignal;

    /* subscribed server signals */
    simsignal_t serverCServiceTimeSignal;

    /* subscribed sink signals */
    simsignal_t serviceCLifeTimeSignal;

    /* subscribed server state signals */
    simsignal_t serverCBusySignal;
    simsignal_t serverCRemovedSignal;

    double window; /* time window in seconds for statistics */
    ServiceCTimeWindowStats arrival;
    ServiceCTimeWindowStats basicServiceTime;
    ServiceCTimeWindowStats optServiceTime;
    ServiceCTimeWindowStats basicResponseTime;
    ServiceCTimeWindowStats optResponseTime;
    ServiceCTimeWindowStats responseTime;

    std::map<std::string, ServiceCTimeWindowStats> utilization;

    ServiceCModel* pModel;

    virtual int numInitStages() const override {return 2;}
    virtual void initialize(int stage) override;
    virtual void handleMessage(omnetpp::cMessage *msg) override;
};

#endif
