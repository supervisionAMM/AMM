/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <sstream>
#include <cstdlib>
#include <boost/tokenizer.hpp>
#include "PassiveQueue.h"
#include "modules/ServiceCMTBrownoutServer.h"
#include "managers/util/ServiceCUtils.h"
#include "ServiceCExecutionManager.h"

Define_Module(ServiceCExecutionManager);

#define RNG 1

const char* ROUTERC_MODULE_NAME = "routerC";
const char* INTERNAL_QUEUEC_MODULE_NAME = "queueC";
const char* SERVERC_MODULE_NAME = "serverC";
const char* SERVERC_MODULE_TYPE = "rubis.serviceC.modules.ServiceCServer";
const char* INTERNAL_SERVERC_MODULE_NAME = "serverC";
const char* CLASSIFIERC_MODULE_NAME = "classifierC";

void ServiceCExecutionManager::initialize() {

    serverCRemovedSignal = registerSignal("serverCRemoved");

    serverCBusySignalId = registerSignal("serverCBusy");
    getSimulation()->getSystemModule()->subscribe(serverCBusySignalId, this);

    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");
    pModel = check_and_cast<ServiceCModel*> (getParentModule()->getSubmodule("modelC"));
}

void ServiceCExecutionManager::handleMessage(cMessage* msg) {

    ServiceCBootComplete* bootComplete = check_and_cast<ServiceCBootComplete*>(msg);

    if (strcmp(bootComplete->getExpectedChange(),"removeServerCDelay") == 0) {

        doRemoveServer(bootComplete);
        delete bootComplete;

    } else if (strcmp(bootComplete->getExpectedChange(),"removeServerC") == 0) {

        cModule* module = getSimulation()->getModule(bootComplete->getModuleId());

        stringstream serverId;
        serverId << module->getId();

        // remove from model
        notifyRemoveServerCompleted(serverId.str().c_str());

        if(cmdenvLogging) {
            std::cout << "t=" << simTime() << " [ServiceCExecutionManager] reomveServer(id=" << bootComplete->getModuleId() << ") complete" << endl;
        }

        // disconnect gates and delete module
        module->gate("out")->disconnect();
        module->deleteModule();
        cancelAndDelete(msg);

    } else if (strcmp(bootComplete->getExpectedChange(),"addServerC") == 0) {

        // update server name and connect server to router, classifier
        doAddServerBootComplete(bootComplete);

        // notify add complete to model
        pModel->serverBecameActive();

        if(cmdenvLogging) {
            std::cout << "t=" << simTime() << " [ServiceCExecutionManager] addServer(id=" << bootComplete->getModuleId() << ") complete" << endl;
        }

        delete bootComplete;
    }
}

void ServiceCExecutionManager::setBrownout(double factor) {
    Enter_Method("setBrownout()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCExecutionManager] executing setBrownout factor=" << factor << endl;
    }

    pModel->setBrownoutFactor(factor);
    doSetBrownout(factor);
}

void ServiceCExecutionManager::doSetBrownout(double factor) {

    serverCModuleIds = pModel->getServerPool();
    for(unsigned int i=0; i<serverCModuleIds.size(); i++) {
        cModule* module = getSimulation()->getModule(serverCModuleIds[i]);
        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceCExecutionManager] doSetBrownout serverCModuleIds[" << i << "]=" << serverCModuleIds[i]
                                      << " moduleName="<< module->getName()
                                      << " factor="<< factor << endl;
        }
        module->getSubmodule("serverC")->par("brownoutFactor").setDoubleValue(factor);
    }
}

void ServiceCExecutionManager::addServer() {
    Enter_Method("addServer()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCExecutionManager] executing addServer()" << endl;
    }

    addServerLatencyOptional(); // add a server with bootDelay
}

void ServiceCExecutionManager::addServerLatencyOptional(bool instantaneous) {

    // new or copy a server module and new bootComplete
    ServiceCBootComplete* bootComplete = doAddServer();

    double bootDelay = 0;
    if (!instantaneous) {
        bootDelay = getParentModule()->par("bootDelay").doubleValue();

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceCExecutionManager] adding server(id="<< bootComplete->getModuleId() <<") with latency=" << bootDelay << endl;
        }
    }

    // add expected SERVER_ONLINE changes
    pModel->addServer(bootDelay);

    // push to server pool
    pModel->pushServerPool(simTime().dbl() + bootDelay, bootComplete->getModuleId());

    if (bootDelay == 0) {
        handleMessage(bootComplete);
    } else {
        scheduleAt(simTime() + bootDelay, bootComplete);
    }
}

ServiceCBootComplete* ServiceCExecutionManager::doAddServer() {

    // find factory object
    cModuleType *moduleType = cModuleType::get(SERVERC_MODULE_TYPE);
    int serverCount = pModel->getServers();
    stringstream name;
    name << SERVERC_MODULE_NAME;
    name << "-T"; // temp server name, different from update name
    name << serverCount + 1;
    cModule *module = moduleType->create(name.str().c_str(), getParentModule());

    // setup parameters
    module->finalizeParameters();
    module->buildInside();

    // copy all params of the server inside the appServer module from the template
    cModule* pNewSubmodule = module->getSubmodule(INTERNAL_SERVERC_MODULE_NAME);
    if (serverCount > 1) {
        // copy from an existing server
        stringstream templateName;
        templateName << SERVERC_MODULE_NAME;
        templateName << "-";
        templateName << 1;
        cModule* pTemplateSubmodule = getParentModule()->getSubmodule(templateName.str().c_str())->getSubmodule(INTERNAL_SERVERC_MODULE_NAME);

        for (int i = 0; i < pTemplateSubmodule->getNumParams(); i++) {
            pNewSubmodule->par(i) = pTemplateSubmodule->par(i);
        }

    } else {
        // if it's the first server, we need to set the parameters common to all servers in the model
        pModel->setServerThreads(pNewSubmodule->par("threads"));
        double variance = 0.0;
        double mean = ServiceCUtils::getMeanAndVarianceFromParameter(pNewSubmodule->par("serviceTime"), &variance);
        pModel->setServiceTime(mean, variance);
        mean = ServiceCUtils::getMeanAndVarianceFromParameter(pNewSubmodule->par("lowFidelityServiceTime"), &variance);
        pModel->setLowFidelityServiceTime(mean, variance);
    }

    // create activation message
    module->scheduleStart(simTime());
    module->callInitialize();

    if(cmdenvLogging) {
        cout << "t=" << simTime()<< " [ServiceCExecutionManager] executing doAddServer(id="<< module->getId() << ")" << endl;
    }

    ServiceCBootComplete* bootComplete = new ServiceCBootComplete;
    bootComplete->setModuleId(module->getId());
    bootComplete->setExpectedChange("addServerC");

    return bootComplete;
}

void ServiceCExecutionManager::doAddServerBootComplete(ServiceCBootComplete* bootComplete) {

    cModule *server = getSimulation()->getModule(bootComplete->getModuleId());
    cModule *router = getParentModule()->getSubmodule(ROUTERC_MODULE_NAME);
    cModule *classifier = getParentModule()->getSubmodule(CLASSIFIERC_MODULE_NAME);

    // update booted server name
    int activeServerCount = pModel->getActiveServers();
    stringstream name;
    name << SERVERC_MODULE_NAME;
    name << "-";
    name << activeServerCount + 1;
    server->setName(name.str().c_str());

    // connect gates
    router->getOrCreateFirstUnconnectedGate("out", 0, false, true)->connectTo(server->gate("in"));
    server->gate("out")->connectTo(classifier->getOrCreateFirstUnconnectedGate("in", 0, false, true));

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCExecutionManager] executing doAddServerBootComplete(id=" << bootComplete->getModuleId()
                                  << "): update booted server name=" << server->getName() << " and connect gates"<< endl;
    }
}

void ServiceCExecutionManager::removeServer() {
    Enter_Method("removeServer()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCExecutionManager] executing removeServer()" << endl;
    }

    removeServerLatencyOptional(); // remove a server with offDelay
}

void ServiceCExecutionManager::removeServerLatencyOptional(bool instantaneous) {

    int moduleId = pModel->popServerPool();

    ServiceCBootComplete* bootComplete = new ServiceCBootComplete;
    bootComplete->setModuleId(moduleId);
    bootComplete->setExpectedChange("removeServerCDelay");

    double offDelay = 0;
    if (!instantaneous) {
        offDelay = getParentModule()->par("offDelay").doubleValue();

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceCExecutionManager] removing server(id="<< bootComplete->getModuleId() <<") with latency=" << offDelay << endl;
        }
    }

    // add offDelay
    std::string serverName = getSimulation()->getModule(moduleId)->getName();
    int serverId = atoi(serverName.substr(8).c_str());
    cout << "t=" << simTime() << " [ServiceCExecutionManager] serverName="<< serverName <<" serverId=" << serverId << endl;

    ServerRemovalEvent event;
    event.moduleId = moduleId;
    event.serverId = serverId;
    event.offDelay = offDelay;
    serverRemovalEvents.insert(event);

    // add expected SERVER_OFFLINE changes
    pModel->removeServer(offDelay);

    if (offDelay == 0) {
        handleMessage(bootComplete);
    } else {
        scheduleAt(simTime() + offDelay, bootComplete);
    }
}

void ServiceCExecutionManager::doRemoveServer(ServiceCBootComplete* bootComplete) {

    int moduleId = bootComplete->getModuleId();

    // pop moduleId of smallest serverId
    double offDelay = 0.0;
    if (!serverRemovalEvents.empty()) {
        ServerRemovalEvents::iterator it = serverRemovalEvents.end();
        it--;
        moduleId = it->moduleId;
        offDelay = it->offDelay;
        serverRemovalEvents.erase(it);

        cout << "t=" << simTime() << " [ServiceCExecutionManager] doRemoveServer new moduleId=" << moduleId << " offDelay=" << offDelay << endl;
    }

    // disconnect module
    cModule *module = getSimulation()->getModule(moduleId);
    cGate* pInGate = module->gate("in");
    if (pInGate->isConnected()) {
        cGate *otherEnd = pInGate->getPathStartGate();
        otherEnd->disconnect();
        ASSERT(otherEnd->getIndex() == otherEnd->getVectorSize()-1);

        // reduce the size of the out gate in the queue module
        otherEnd->getOwnerModule()->setGateSize(otherEnd->getName(), otherEnd->getVectorSize()-1);
        // this is probably leaking memory because the gate may not be being deleted
    }

    if(cmdenvLogging) {
         std::cout << "t=" << simTime() << " [ServiceCExecutionManager] doRemoveServer(id=" << moduleId << "): moduleName=" << module->getName() << endl;
    }

    // check to see if we can delete the server immediately (or if it's busy)
    if (isServerBeingRemoveEmpty(moduleId)) {
        completeServerRemoval(moduleId);
    } else {
        serverCBeingRemovedModuleIds.push_back(moduleId);
    }
}

void ServiceCExecutionManager::completeServerRemoval(int moduleId) {
    Enter_Method("sendMe()");

    // clear cache for server, so that the next time it is instantiated it is fresh
    cModule* module = getSimulation()->getModule(moduleId);
    check_and_cast<ServiceCMTBrownoutServer*>(module->getSubmodule(INTERNAL_SERVERC_MODULE_NAME))->clearServerCache();

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCExecutionManager] completeServerRemoval(id="<< moduleId <<"): clearServerCache" << endl;
    }

    ServiceCBootComplete* pBootComplete = new ServiceCBootComplete;
    pBootComplete->setModuleId(moduleId);
    pBootComplete->setExpectedChange("removeServerC");

    scheduleAt(simTime(), pBootComplete);
}

bool ServiceCExecutionManager::isServerBeingRemoveEmpty(int moduleId) {

    bool isEmpty = false;
    cModule* module = getSimulation()->getModule(moduleId);
    ServiceCMTBrownoutServer* internalServer = check_and_cast<ServiceCMTBrownoutServer*> (module->getSubmodule(INTERNAL_SERVERC_MODULE_NAME));
    if (internalServer->isEmpty()) {
        queueing::PassiveQueue* queue = check_and_cast<queueing::PassiveQueue*> (module->getSubmodule(INTERNAL_QUEUEC_MODULE_NAME));
        if (queue->length() == 0) {
            isEmpty = true;
        }
    }

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCExecutionManager] isServerBeingRemoveEmpty=" << isEmpty << endl;
    }

    return isEmpty;
}

void ServiceCExecutionManager::notifyRemoveServerCompleted(const char* serverId) {

    // update model for notify remove server completed
    pModel->serverBecameShutDown();

    // emit signal to notify others (notably simProbe)
    emit(serverCRemovedSignal, serverId);
}

void ServiceCExecutionManager::receiveSignal(cComponent *source, simsignal_t signalID, bool value, cObject *details) {

    if (signalID == serverCBusySignalId && value == false) {
        std::vector<int>::iterator it = std::find(serverCBeingRemovedModuleIds.begin(), serverCBeingRemovedModuleIds.end(), source->getParentModule()->getId());

        if (it != serverCBeingRemovedModuleIds.end()) {

            int serverCBeingRemovedModuleId = it[0];
            serverCBeingRemovedModuleIds.erase(it);

            if(cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceCExecutionManager] serverCBeingRemovedModuleId=" << serverCBeingRemovedModuleId << endl;
            }

            if (isServerBeingRemoveEmpty(serverCBeingRemovedModuleId)) {
                completeServerRemoval(serverCBeingRemovedModuleId);
            }
        }
    }
}
