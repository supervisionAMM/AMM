/*******************************************************************************
 * PI Controller for Servers.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/
#ifndef SERVICECPICONTROLLER_H_
#define SERVICECPICONTROLLER_H_

#include <omnetpp.h>
#include "managers/model/ServiceCModel.h"
#include "managers/monitor/ServiceCSimMonitor.h"
#include "managers/execution/ServiceCExecutionManager.h"

using namespace omnetpp;
using namespace std;

class ServiceCPIController : public cSimpleModule
{
  public:
    // logging
    bool cmdenvLogging;

    // control
    bool controlTrigger;
    string controlFilePath;

    // control parameter and measurements
    double controlServersDouble;
    int controlServers;
    double measuredArrivalRate;
    double measuredAvgRespTime;

    // auxiliary_signal
    int activeFlag = 0;
    int optAS = 0;
    int recoveryFlag = 0;
    int recoveryAS = 0;

    void getMeasurements();
    void writeControlTrace();
    void computeControlParameter();
    void setControlParameter();

    int getControlServers();
    void setActiveFlag(int activeFlag);
    void setOptAS(int optAS);
    void setRecoveryFlag (int recoveryFlag);
    void setRecoveryAS(int recoveryAS);

    ServiceCModel *pModel;
    ServiceCSimMonitor *pMonitor;
    ServiceCExecutionManager* pExecMgr;

  protected:
    int minServers;
    int maxServers;

    // setpoint
    double setpoint = 0.3;

    // nominal model
    double beta = -0.1042;

    // PI control parameter: pole
    double pole = 0.9;

    // control constraints
    int deltaSerMin = -1;
    int deltaSerMax = 1;

    // handle delay
    int delay_loop = 1;
    int timer = 0;

    // counting
    int num = 0;

    // mode deviation
    bool deviationTrigger;
    std::string deviationServiceModule;
    double deviationStartTime;

    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
