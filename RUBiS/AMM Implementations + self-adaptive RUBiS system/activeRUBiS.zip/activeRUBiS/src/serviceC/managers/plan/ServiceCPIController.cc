/*******************************************************************************
 * PI Controller for Servers.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/
#include <fstream>
#include <iostream>
#include <algorithm>
#include "ServiceCPIController.h"

Define_Module(ServiceCPIController);

void ServiceCPIController::initialize() {
    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

    // control
    cXMLElement *controlTriggerNode = getParentModule()->par("controlTriggerXML").xmlValue();
    controlTrigger = string(controlTriggerNode->getNodeValue())=="true" ? 1 : 0;

    if (controlTrigger) {
        pModel = check_and_cast<ServiceCModel*> (getParentModule()->getSubmodule("modelC"));
        pMonitor = check_and_cast<ServiceCSimMonitor*> (getParentModule()->getSubmodule("simMonitorC"));
        pExecMgr = check_and_cast<ServiceCExecutionManager*> (getParentModule()->getSubmodule("executionManagerC"));

        cXMLElement *minServersNode = getParentModule()->par("minServersXML").xmlValue();
        minServers = atoi(minServersNode->getNodeValue());

        cXMLElement *maxServersNode = getParentModule()->par("maxServersXML").xmlValue();
        maxServers = atoi(maxServersNode->getNodeValue());

        cXMLElement *initialServersNode = getParentModule()->par("initialServersXML").xmlValue();
        controlServers = atoi(initialServersNode->getNodeValue());
        controlServersDouble = (double)controlServers;

        // tracing
        controlFilePath = "../results/serviceCPIControllerTrace.txt";

        // Delete old control trace file
        ifstream cpFin(controlFilePath.c_str());
        if (!cpFin) {
            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceCPIController] " << controlFilePath << " does not exist" << endl;
            }
        } else {
            remove(controlFilePath.c_str());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceCPIController] Delete " << controlFilePath << endl;
            }
        }

        // first line of control trace file
        ofstream out;
        out.open(controlFilePath.c_str(), ios::app);
        if (out.is_open()) {
            out << "controlServersDouble_{k-1},";
            out << "controlServers_{k-1},";
            out << "measuredArrivalRate_{k},";
            out << "measuredAvgRespTime_{k}\n";
            out.close();
        }

        // mode deviation
        cXMLElement *deviationTriggerNode = getSimulation()->getSystemModule()->par("deviationTriggerXML").xmlValue();
        deviationTrigger = string(deviationTriggerNode->getNodeValue())=="true" ? 1 : 0;

        if (deviationTrigger) {

            cXMLElement *deviationServiceModuleNode = getSimulation()->getSystemModule()->par("deviationServiceModuleXML").xmlValue();
            deviationServiceModule = string(deviationServiceModuleNode->getNodeValue());

            cXMLElement *deviationStartTimeNode = getSimulation()->getSystemModule()->par("deviationStartTimeXML").xmlValue();
            deviationStartTime = atof(deviationStartTimeNode->getNodeValue());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceCPIController] initialize"
                                          << " deviationTrigger="       << deviationTrigger
                                          << " deviationServiceModule=" << deviationServiceModule
                                          << " deviationStartTime="     << deviationStartTime << endl;

                cout << "t=" << simTime() << " [ServiceCPIController] activeFlag[" << num << "]=" << activeFlag
                                                                      << " optAS[" << num << "]=" << optAS
                                                               << " recoveryFlag[" << num << "]=" << recoveryFlag
                                                                 << " recoveryAS[" << num << "]=" << recoveryAS << endl;
            }
        }

    }
}

void ServiceCPIController::handleMessage(cMessage *msg) {
    // adaptation loop
    getMeasurements();
    writeControlTrace();
    computeControlParameter();
    setControlParameter();

    //finish
    delete msg;
}

void ServiceCPIController::getMeasurements() {
    // get measurements
    measuredArrivalRate = pMonitor->getMeasuredArrivalRate();
    measuredAvgRespTime = pMonitor->getMeasuredAvgRespTime();

    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCPIController] controlServersDouble[" << num << "]=" << controlServersDouble
                                                               << " controlServers[" << num << "]=" << controlServers
                                                          << " measuredArrivalRate[" << num << "]=" << measuredArrivalRate
                                                          << " measuredAvgRespTime[" << num << "]=" << measuredAvgRespTime << endl;
    }
}

void ServiceCPIController::writeControlTrace() {
    ofstream out;
    out.open(controlFilePath.c_str(), ios::app);
    if (out.is_open()) {
        out << controlServersDouble;
        out << ",";
        out << controlServers;
        out << ",";
        out << measuredArrivalRate;
        out << ",";
        out << measuredAvgRespTime;
        out << "\n";
        out.close();
    }
}

void ServiceCPIController::computeControlParameter() {
    // compute new control parameter
    double K_p =  (1.0-pole)/beta;
    double err = setpoint-measuredAvgRespTime;

    controlServersDouble = (double)controlServers + K_p*err;

    int deltaSer = ceil(K_p*err);
    int saturatedDeltaSer = min(max(deltaSer, deltaSerMin), deltaSerMax);

    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAPIController] deltaSer[" << num << "]=" << deltaSer << " saturatedDeltaSer[" << num << "]=" << saturatedDeltaSer << endl;
    }

    // handle long tail problem
    if (abs(saturatedDeltaSer) > 0) {

        if (timer == 0) {
            int saturatedNewSer = controlServers + saturatedDeltaSer;
            controlServers = min(max(saturatedNewSer, minServers), maxServers);

            // reset
            timer = delay_loop;

        } else {
            // timing
            if (timer > 0) {timer = timer - 1; }
        }
    }

    // active part
    if (activeFlag == 1 and abs(optAS) > 0) {

        // set auxiliary signal
        controlServers = min(max(controlServers + optAS, minServers), maxServers);

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceAPIController] activeFlag[" << num << "]=" << activeFlag << " optAS[" << num << "]=" << optAS << endl;
        }

        // reset
        activeFlag = 0;
        optAS = 0;

    } else if (recoveryFlag == 1 and abs(recoveryAS) > 0) {
        // recovery auxiliary signal
        controlServers = min(max(controlServers + recoveryAS, minServers), maxServers);

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceAPIController] recoveryFlag[" << num << "]=" << recoveryFlag << " recoveryAS[" << num << "]=" << recoveryAS << endl;
        }

        // reset
        recoveryFlag = 0;
        recoveryAS = 0;
    }

    num = num + 1;
}

void ServiceCPIController::setControlParameter() {

    if (deviationTrigger && deviationServiceModule=="serviceC" && simTime().dbl()>deviationStartTime) {
        // set servers abnormally
        // cannot activate actuators

    } else {
        // set servers normally
        if(controlServers > pModel->getServers()) {
            int additionalServers = controlServers - pModel->getServers();
            for(int i = 0; i < additionalServers; i++) {
                pExecMgr->addServer();
            }
        }

        if(controlServers < pModel->getServers()) {
            int removalServers = pModel->getServers() - controlServers;
            for(int i = 0; i < removalServers; i++) {
                pExecMgr->removeServer();
            }
        }
    }

}

int ServiceCPIController::getControlServers() {
    return controlServers;
}

void ServiceCPIController::setActiveFlag(int activeFlag) {
    this->activeFlag = activeFlag;
}

void ServiceCPIController::setOptAS(int optAS) {
    this->optAS = optAS;
}

void ServiceCPIController::setRecoveryFlag(int recoveryFlag) {
    this->recoveryFlag = recoveryFlag;
}

void ServiceCPIController::setRecoveryAS(int recoveryAS) {
    this->recoveryAS = recoveryAS;
}

