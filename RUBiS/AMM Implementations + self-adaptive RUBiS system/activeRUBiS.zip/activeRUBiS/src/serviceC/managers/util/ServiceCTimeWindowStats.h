/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICECTIMEWINDOWSTATS_H_
#define SERVICECTIMEWINDOWSTATS_H_

#include <deque>
#include <memory>
#include <boost/accumulators/accumulators.hpp>
#include <boost/accumulators/statistics/stats.hpp>
#include <boost/accumulators/statistics/mean.hpp>
#include <boost/accumulators/statistics/moment.hpp>
#include <omnetpp.h>

using namespace omnetpp;
using namespace std;

/**
 * Computes statistics for events in a sliding time window
 *
 * @note This class is not thread-safe (intended for use in OMNET++)
 */
class ServiceCTimeWindowStats {

  public:
    ServiceCTimeWindowStats();
    virtual ~ServiceCTimeWindowStats();

    virtual void reset();
    virtual void setWindow(double seconds);
    virtual void record(double value);
    virtual double getAverage();
    virtual double getVariance();

    /**
     * Returns the average number of entries per second
     */
    virtual double getRate();
    virtual unsigned getCount();

    /**
      * Assuming that entries set the new level for a continuous signal,
      * it computes the percentage of time the signal was above 0.
      *
      * TODO this probably should be a specialization for boolean values
      */
     virtual double getPercentageAboveZero();

     /**
      * Returns the values of the entries and percentile response time
      */
     virtual std::vector<double> getEntriesVector();

protected:
    typedef boost::accumulators::accumulator_set<double, boost::accumulators::stats<boost::accumulators::tag::mean, boost::accumulators::tag::moment<2>>> Stats;
    std::unique_ptr<Stats> pStats;

    void loadStats();

    using Duration = omnetpp::simtime_t;
    using Timestamp = omnetpp::simtime_t;

    /**
     * Window duration
     */
    Duration window;

    struct Entry {
        Timestamp timestamp;
        double value;
    };

    std::deque<Entry> entries;

    std::vector<double> percentileVector;
    std::vector<double> entriesVector;

    const unsigned ENTRIES_BETWEEN_CHECKS = 1000; // entries records information of requests in one sampling time
    double lastValue = 0; /**< keeps the last value even if it falls out of the window */

    /**
     * Removes the entries that fell out of the time window
     */
    void removeOldEntries();

    inline Duration getDuration(Timestamp first, Timestamp last) const {
        return last - first;
    }

    inline Timestamp subtractDuration(Timestamp t, Duration d) const {
        return t - d;
    }

    inline Timestamp getTimestampNow() const {
        return omnetpp::simTime();
    }

    inline double asDouble(Duration t) const {
        return t.dbl();
    }
};

#endif
