/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <sstream>
#include <math.h>
#include <assert.h>
#include "managers/util/ServiceCUtils.h"
#include "managers/execution/ServiceCExecutionManager.h"
#include "ServiceCModel.h"

Define_Module(ServiceCModel);

void ServiceCModel::addExpectedServerChange(double time, ModelServerChange change) {
    ModelServerChangeEvent event;
    event.startTime = simTime().dbl();
    event.time = time;
    event.change = change;
    serverChangeEvents.insert(event);
}

void ServiceCModel::addServer(double bootDelay) {
    addExpectedServerChange(simTime().dbl() + bootDelay, ServiceCModel::SERVER_ONLINE);

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCModel] addServer bootDelay=" << bootDelay
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceCModel::removeServer(double offDelay) {
    addExpectedServerChange(simTime().dbl() + offDelay, ServiceCModel::SERVER_OFFLINE);

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBModel] removeServer offDelay=" << offDelay
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceCModel::serverBecameActive() {
    /* remove expected change...*/
    ModelServerChangeEvents::iterator it = serverChangeEvents.begin();
    while (it != serverChangeEvents.end() && it->change != ServiceCModel::SERVER_ONLINE) {
        it++;
    }

    assert(it != serverChangeEvents.end()); // there must be an expected server boot change for this
    serverChangeEvents.erase(it);

    activeServers++;

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCModel] serverBecameActive"
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceCModel::serverBecameShutDown() {
    /* remove expected change...*/
    ModelServerChangeEvents::iterator it = serverChangeEvents.begin();
    while (it != serverChangeEvents.end() && it->change != ServiceCModel::SERVER_OFFLINE) {
        it++;
    }

    assert(it != serverChangeEvents.end()); // there must be an expected server shutdown change for this
    serverChangeEvents.erase(it);

    activeServers--;

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCModel] serverBecameShutDown"
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

int ServiceCModel::numServerBooting() const {
    int bootingNum = 0;

    if (!serverChangeEvents.empty()){
        /* find the number of booting servers */
        ModelServerChangeEvents::const_iterator eventIt = serverChangeEvents.begin();
        while(eventIt != serverChangeEvents.end()) {
            if(eventIt->change == SERVER_ONLINE){
                bootingNum++;
            }
            eventIt++;
        }
   }
    return bootingNum;
}

int ServiceCModel::numServerShutting() const {
    int shuttingNum = 0;

    if (!serverChangeEvents.empty()){
        /* find the number of booting servers */
        ModelServerChangeEvents::const_iterator eventIt = serverChangeEvents.begin();
        while(eventIt != serverChangeEvents.end()) {
            if(eventIt->change == SERVER_OFFLINE){
                shuttingNum++;
            }
            eventIt++;
        }
   }
    return shuttingNum;
}

void ServiceCModel::pushServerPool(double time, int id) {
    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCModel] push server id=" << id << " time=" << time << endl;
    }

    ModelServerPoolEvent event;
    event.time = time;
    event.id = id;
    serverPoolEvents.insert(event);
}

int ServiceCModel::popServerPool() {
    int id = -1;
    if (!serverPoolEvents.empty()) {
        ModelServerPoolEvents::iterator it = serverPoolEvents.end();
        it--;
        id = it->id;
        serverPoolEvents.erase(it);
    }
    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceCModel] pop id=" << id << " time=" << simTime().dbl() << endl;
    }

    return id;
}

std::vector<int> ServiceCModel::getServerPool() {
    serverModuleIds.clear();
    ModelServerPoolEvents::iterator it = serverPoolEvents.begin();
    while (it != serverPoolEvents.end()) {
        serverModuleIds.push_back(it->id);
        it++;
    }
    return serverModuleIds;
}

void ServiceCModel::initialize(int stage) {
    if (stage == 0) {

        // logging
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

        // server config
        brownoutFactor = getParentModule()->par("brownoutFactor");

        // uncertainty
        bootDelay = ServiceCUtils::getMeanAndVarianceFromParameter(getParentModule()->par("bootDelay"));
        offDelay = ServiceCUtils::getMeanAndVarianceFromParameter(getParentModule()->par("offDelay"));

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceCModel] initialize"
                                      << " brownoutFactor=" << brownoutFactor
                                      << " bootDelay="      << bootDelay
                                      << " offDelay="       << offDelay << endl;
        }
    } else {
        // initial servers
        ServiceCExecutionManager* pExecMgr = check_and_cast<ServiceCExecutionManager*> (getParentModule()->getSubmodule("executionManagerC"));

        cXMLElement *initialServersNode = getParentModule()->par("initialServersXML").xmlValue();
        int initialServers = atoi(initialServersNode->getNodeValue());

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceCModel] initialServers=" << initialServers << endl;
        }

        while (initialServers > 0) {
            pExecMgr->addServerLatencyOptional(true); // add a server instantaneously
            initialServers--;
        }
    }
}

// servers
double ServiceCModel::getBrownoutFactor() const {
    return brownoutFactor;
}

void ServiceCModel::setBrownoutFactor(double factor) {
    brownoutFactor = factor;
}

int const ServiceCModel::getServers() const {
    return activeServers + numServerBooting()-numServerShutting();
}

int const ServiceCModel::getActiveServers() const {
    return activeServers;
}

int ServiceCModel::getServerThreads() const {
    return serverThreads;
}

void ServiceCModel::setServerThreads(int serverThreads) {
    this->serverThreads = serverThreads;
}

double ServiceCModel::getServiceTimeMean() const {
    return serviceTimeMean;
}

void ServiceCModel::setServiceTime(double serviceTimeMean, double serviceTimeVariance) {
    this->serviceTimeMean = serviceTimeMean;
    this->serviceTimeVariance = serviceTimeVariance;
}

double ServiceCModel::getLowFidelityServiceTimeMean() const {
    return lowFidelityServiceTimeMean;
}

void ServiceCModel::setLowFidelityServiceTime(double lowFidelityServiceTimeMean, double lowFidelityServiceTimeVariance) {
    this->lowFidelityServiceTimeMean = lowFidelityServiceTimeMean;
    this->lowFidelityServiceTimeVariance = lowFidelityServiceTimeVariance;
}

// uncertainty
double ServiceCModel::getBootDelay() const {
    return bootDelay;
}

// utility
double ServiceCModel::getUtility() const {
    return utility;
}

void ServiceCModel::setUtility(double utility) {
    this->utility = utility;
}

// envrionement
const ServiceCEnvironment& ServiceCModel::getEnvironment() const {
    return environment;
}

void ServiceCModel::setEnvironment(const ServiceCEnvironment& environment) {
    this->environment = environment;
}

const ServiceCObservations& ServiceCModel::getObservations() const {
    return observations;
}

void ServiceCModel::setObservations(const ServiceCObservations& observations) {
    this->observations = observations;
}
