/*******************************************************************************
 * Mandatory Controller.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "ServiceCMandatoryController.h"

Define_Module(ServiceCMandatoryController);

void ServiceCMandatoryController::initialize()
{
    pModel = check_and_cast<ServiceCModel*> (getParentModule()->getSubmodule("modelC"));
    pExecMgr = check_and_cast<ServiceCExecutionManager*> (getParentModule()->getSubmodule("executionManagerC"));
}

void ServiceCMandatoryController::handleMessage(cMessage *msg)
{
    setControlParamter();

    //finish
    delete msg;
}

void ServiceCMandatoryController::setControlParamter() {

    // set low fidelity mode
    pExecMgr->setBrownout(1.0);
    pModel->setBrownoutFactor(1.0);
}
