/*******************************************************************************
 * Controller Switcher.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "ServiceCSwitcher.h"

Define_Module(ServiceCSwitcher);

void ServiceCSwitcher::initialize() {}

void ServiceCSwitcher::handleMessage(cMessage *msg)
{
    if (triggerMandatoryCtrl) {
        send(msg, "manCtrl");
    }
    else {
        send(msg, "piCtrl");
    }
}

bool ServiceCSwitcher::getSwitcherMode() {
    return triggerMandatoryCtrl;
}

void ServiceCSwitcher::setSwitcherMode(bool MCtrl) {
    triggerMandatoryCtrl = MCtrl;
}
