/*******************************************************************************
 * Data Collection for System Identification.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICECDATACOLLECTION_H_
#define SERVICECDATACOLLECTION_H_

#include <omnetpp.h>
#include "managers/model/ServiceCModel.h"
#include "managers/monitor/ServiceCSimMonitor.h"
#include "managers/execution/ServiceCExecutionManager.h"

using namespace omnetpp;
using namespace std;

class ServiceCDataCollection : public cSimpleModule {

  public:
    struct MeasuredOutputsEvent {
        double measuredDimmer;
        int measuredServers;
        int measuredActiveServers;
        double measuredArrivalRate;
        double measuredAvgRespTime;
    };

    MeasuredOutputsEvent measuredOutputs;

    // logging
    bool cmdenvLogging;

    // identification
    bool identTrigger;
    string identServiceModule;
    string identFilePath;

    std::vector<double> identDimmerVec;
    std::vector<double> identServersVec;
    int identServers;

    // count
    int num = 0;

    ServiceCModel *pModel;
    ServiceCSimMonitor *pMonitor;
    ServiceCExecutionManager* pExecMgr;

    MeasuredOutputsEvent getMeasuredOutputs();
    void setIdentControlParameters();
    void writeIdentTrace(MeasuredOutputsEvent measuredOutputs);
    std::vector<double> split(std::string str); /* split string(xml) to double vector */

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
