/*******************************************************************************
 * Model Deviation Detector.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/
#ifndef SERVICEBDETECTOR_H_
#define SERVICEBDETECTOR_H_

#include <omnetpp.h>
#include <python3.8/Python.h>
#include "managers/monitor/ServiceBSimMonitor.h"
#include "managers/plan/ServiceBPIController.h"
#include "supervision/safeguard/ServiceBSwitcher.h"

using namespace omnetpp;

#define MAX_SERVICE_RATE omnetpp::getSimulation()->getSystemModule()->getSubmodule("serviceB")->par("maxServiceRate").doubleValue()

class ServiceBDetector : public cSimpleModule
{
  public:
    // logging
    bool cmdenvLogging;
    bool logging = false;

    // supervision
    bool supervisionTrigger;
    string supervisionType;
    string supervisionFilePath;

    // switch
    bool switchTrigger;

    //  SWDetectorPlus
    double B_k_prior = 0;
    double P_k_prior = 0;
    double avgErrorDist = 0.0;
    int slidingWindowSize = 28;
    double errorThreshold = -1;

    // ARMAPlus
    double predictionError = 0;

    // MoD2Plus
    string auxiliarySignalTriggerMode;
    string auxiliarySignalDesignMode;
    int timingInterval = 15;
    int rndSeed = 1;
    double B_k_posterior = 0;
    double P_k_posterior = 0;
    double B_k_predict = 0;
    double P_k_predict = 0;
    int alarm = 0;
    int activeFlag = 0;
    int optAS = 0;

    // recovery auxiliary signal
    int controlServersOld = 1;
    double measuredArrivalRateOld = 0;
    int historicOptAS = 0;

    int recoveryFlag = 0;
    int recoveryAS = 0;
    int stable_loop = 3;
    int timer = 3;

    // control parameter and measurements
    int controlServers;
    double measuredArrivalRate;
    double measuredAvgRespTime;

    // count
    int num = 0;

    // Python
    PyObject *pInstance;

    ServiceBSimMonitor *pMonitor;
    ServiceBPIController *pCtrl;
    ServiceBSwitcher *pSwitcher;

    void deviationDetector(int controlServers, double measuredArrivalRate, double measuredAvgRespTime);
    void writeTrace();

    ServiceBDetector();
    virtual ~ServiceBDetector();

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
