/*******************************************************************************
 * Controller Switcher.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "ServiceBSwitcher.h"

Define_Module(ServiceBSwitcher);

void ServiceBSwitcher::initialize() {}

void ServiceBSwitcher::handleMessage(cMessage *msg)
{
    if (triggerMandatoryCtrl) {
        send(msg, "manCtrl");
    }
    else {
        send(msg, "piCtrl");
    }
}

bool ServiceBSwitcher::getSwitcherMode() {
    return triggerMandatoryCtrl;
}

void ServiceBSwitcher::setSwitcherMode(bool MCtrl) {
    triggerMandatoryCtrl = MCtrl;
}
