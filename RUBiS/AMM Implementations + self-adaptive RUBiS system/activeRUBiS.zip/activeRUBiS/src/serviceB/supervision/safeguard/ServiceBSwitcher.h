/*******************************************************************************
 * Controller Switcher.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEBSWITCHER_H_
#define SERVICEBSWITCHER_H_

#include <omnetpp.h>

using namespace omnetpp;

class ServiceBSwitcher : public cSimpleModule
{
  public:
    bool triggerMandatoryCtrl=false;

    bool getSwitcherMode();
    void setSwitcherMode(bool MCtrl);

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
