/*******************************************************************************
 * Mandatory Controller.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEBMANDATORYCONTROLLER_H_
#define SERVICEBMANDATORYCONTROLLER_H_

#include <omnetpp.h>
#include "managers/model/ServiceBModel.h"
#include "managers/execution/ServiceBExecutionManager.h"

using namespace omnetpp;

class ServiceBMandatoryController : public cSimpleModule
{
  public:
    ServiceBModel *pModel;
    ServiceBExecutionManager* pExecMgr;

    void setControlParamter();

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
