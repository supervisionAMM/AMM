/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <sstream>
#include <cstdlib>
#include <boost/tokenizer.hpp>
#include "PassiveQueue.h"
#include "modules/ServiceBMTBrownoutServer.h"
#include "managers/util/ServiceBUtils.h"
#include "ServiceBExecutionManager.h"

Define_Module(ServiceBExecutionManager);

#define RNG 1

const char* ROUTER_MODULE_NAME = "routerB";
const char* INTERNAL_QUEUEB_MODULE_NAME = "queueB";
const char* SERVERB_MODULE_NAME = "serverB";
const char* SERVERB_MODULE_TYPE = "rubis.serviceB.modules.ServiceBServer";
const char* INTERNAL_SERVERB_MODULE_NAME = "serverB";
const char* CLASSIFIERB_MODULE_NAME = "classifierB";

void ServiceBExecutionManager::initialize() {

    serverBRemovedSignal = registerSignal("serverBRemoved");

    serverBBusySignal = registerSignal("serverBBusy");
    getSimulation()->getSystemModule()->subscribe(serverBBusySignal, this);

    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");
    pModel = check_and_cast<ServiceBModel*> (getParentModule()->getSubmodule("modelB"));
}

void ServiceBExecutionManager::handleMessage(cMessage* msg) {

    ServiceBBootComplete* bootComplete = check_and_cast<ServiceBBootComplete*>(msg);

    if (strcmp(bootComplete->getExpectedChange(),"removeServerBDelay") == 0) {

        doRemoveServer(bootComplete);
        delete bootComplete;

    } else if (strcmp(bootComplete->getExpectedChange(),"removeServerB") == 0) {

        cModule* module = getSimulation()->getModule(bootComplete->getModuleId());

        stringstream serverId;
        serverId << module->getId();

        // remove from model
        notifyRemoveServerCompleted(serverId.str().c_str());

        if(cmdenvLogging) {
            std::cout << "t=" << simTime() << " [ServiceBExecutionManager] reomveServer(id=" << bootComplete->getModuleId() << ") complete" << endl;
        }

        // disconnect gates and delete module
        module->gate("out")->disconnect();
        module->deleteModule();
        cancelAndDelete(msg);

    } else if (strcmp(bootComplete->getExpectedChange(),"addServerB") == 0) {

        // update server name and connect server to router, classifier
        doAddServerBootComplete(bootComplete);

        // notify add complete to model
        pModel->serverBecameActive();

        if(cmdenvLogging) {
            std::cout << "t=" << simTime() << " [ServiceBExecutionManager] addServer(id=" << bootComplete->getModuleId() << ") complete" << endl;
        }

        delete bootComplete;
    }
}

void ServiceBExecutionManager::setBrownout(double factor) {
    Enter_Method("setBrownout()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBExecutionManager] executing setBrownout factor=" << factor << endl;
    }

    pModel->setBrownoutFactor(factor);
    doSetBrownout(factor);
}

void ServiceBExecutionManager::doSetBrownout(double factor) {

    serverBModuleIds = pModel->getServerPool();
    for(unsigned int i=0; i<serverBModuleIds.size(); i++) {
        cModule* module = getSimulation()->getModule(serverBModuleIds[i]);
        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceBExecutionManager] doSetBrownout serverBModuleIds[" << i << "]=" << serverBModuleIds[i]
                                      << " moduleName="<< module->getName()
                                      << " factor="<< factor << endl;
        }
        module->getSubmodule("serverB")->par("brownoutFactor").setDoubleValue(factor);
    }
}

void ServiceBExecutionManager::addServer() {
    Enter_Method("addServer()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBExecutionManager] executing addServer()" << endl;
    }

    addServerLatencyOptional(); // add a server with bootDelay
}

void ServiceBExecutionManager::addServerLatencyOptional(bool instantaneous) {

    // new or copy a server module and new bootComplete
    ServiceBBootComplete* bootComplete = doAddServer();

    double bootDelay = 0;
    if (!instantaneous) {
        bootDelay = getParentModule()->par("bootDelay").doubleValue();

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceBExecutionManager] adding server(id="<< bootComplete->getModuleId() <<") with latency=" << bootDelay << endl;
        }
    }

    // add expected SERVER_ONLINE changes
    pModel->addServer(bootDelay);

    // push to server pool
    pModel->pushServerPool(simTime().dbl() + bootDelay, bootComplete->getModuleId());

    if (bootDelay == 0) {
        handleMessage(bootComplete);
    } else {
        scheduleAt(simTime() + bootDelay, bootComplete);
    }
}

ServiceBBootComplete* ServiceBExecutionManager::doAddServer() {

    // find factory object
    cModuleType *moduleType = cModuleType::get(SERVERB_MODULE_TYPE);
    int serverCount = pModel->getServers();
    stringstream name;
    name << SERVERB_MODULE_NAME;
    name << "-T"; // temp server name, different from update name
    name << serverCount + 1;
    cModule *module = moduleType->create(name.str().c_str(), getParentModule());

    // setup parameters
    module->finalizeParameters();
    module->buildInside();

    // copy all params of the server inside the appServer module from the template
    cModule* pNewSubmodule = module->getSubmodule(INTERNAL_SERVERB_MODULE_NAME);
    if (serverCount > 1) {
        // copy from an existing server
        stringstream templateName;
        templateName << SERVERB_MODULE_NAME;
        templateName << "-";
        templateName << 1;
        cModule* pTemplateSubmodule = getParentModule()->getSubmodule(templateName.str().c_str())->getSubmodule(INTERNAL_SERVERB_MODULE_NAME);

        for (int i = 0; i < pTemplateSubmodule->getNumParams(); i++) {
            pNewSubmodule->par(i) = pTemplateSubmodule->par(i);
        }

    } else {
        // if it's the first server, we need to set the parameters common to all servers in the model
        pModel->setServerThreads(pNewSubmodule->par("threads"));
        double variance = 0.0;
        double mean = ServiceBUtils::getMeanAndVarianceFromParameter(pNewSubmodule->par("serviceTime"), &variance);
        pModel->setServiceTime(mean, variance);
        mean = ServiceBUtils::getMeanAndVarianceFromParameter(pNewSubmodule->par("lowFidelityServiceTime"), &variance);
        pModel->setLowFidelityServiceTime(mean, variance);
    }

    // create activation message
    module->scheduleStart(simTime());
    module->callInitialize();

    if(cmdenvLogging) {
        cout << "t=" << simTime()<< " [ServiceBExecutionManager] executing doAddServer(id="<< module->getId() << ")" << endl;
    }

    ServiceBBootComplete* bootComplete = new ServiceBBootComplete;
    bootComplete->setModuleId(module->getId());
    bootComplete->setExpectedChange("addServerB");

    return bootComplete;
}

void ServiceBExecutionManager::doAddServerBootComplete(ServiceBBootComplete* bootComplete) {

    cModule *server = getSimulation()->getModule(bootComplete->getModuleId());
    cModule *router = getParentModule()->getSubmodule(ROUTER_MODULE_NAME);
    cModule *classifier = getParentModule()->getSubmodule(CLASSIFIERB_MODULE_NAME);

    // update booted server name
    int activeServerCount = pModel->getActiveServers();
    stringstream name;
    name << SERVERB_MODULE_NAME;
    name << "-";
    name << activeServerCount + 1;
    server->setName(name.str().c_str());

    // connect gates
    router->getOrCreateFirstUnconnectedGate("out", 0, false, true)->connectTo(server->gate("in"));
    server->gate("out")->connectTo(classifier->getOrCreateFirstUnconnectedGate("in", 0, false, true));

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBExecutionManager] executing doAddServerBootComplete(id=" << bootComplete->getModuleId()
                                  << "): update booted server name=" << server->getName() << " and connect gates"<< endl;
    }
}

void ServiceBExecutionManager::removeServer() {
    Enter_Method("removeServer()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBExecutionManager] executing removeServer()" << endl;
    }

    removeServerLatencyOptional(); // remove a server with offDelay
}

void ServiceBExecutionManager::removeServerLatencyOptional(bool instantaneous) {

    int moduleId = pModel->popServerPool();

    ServiceBBootComplete* bootComplete = new ServiceBBootComplete;
    bootComplete->setModuleId(moduleId);
    bootComplete->setExpectedChange("removeServerBDelay");

    double offDelay = 0;
    if (!instantaneous) {
        offDelay = getParentModule()->par("offDelay").doubleValue();

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceBExecutionManager] removing server(id="<< bootComplete->getModuleId() <<") with latency=" << offDelay << endl;
        }
    }

    // add offDelay
    std::string serverName = getSimulation()->getModule(moduleId)->getName();
    int serverId = atoi(serverName.substr(8).c_str());
    cout << "t=" << simTime() << " [ServiceBExecutionManager] serverName="<< serverName <<" serverId=" << serverId << endl;

    ServerRemovalEvent event;
    event.moduleId = moduleId;
    event.serverId = serverId;
    event.offDelay = offDelay;
    serverRemovalEvents.insert(event);

    // add expected SERVER_OFFLINE changes
    pModel->removeServer(offDelay);

    if (offDelay == 0) {
        handleMessage(bootComplete);
    } else {
        scheduleAt(simTime() + offDelay, bootComplete);
    }
}

void ServiceBExecutionManager::doRemoveServer(ServiceBBootComplete* bootComplete) {

    int moduleId = bootComplete->getModuleId();

    // pop moduleId of smallest serverId
    double offDelay = 0.0;
    if (!serverRemovalEvents.empty()) {
        ServerRemovalEvents::iterator it = serverRemovalEvents.end();
        it--;
        moduleId = it->moduleId;
        offDelay = it->offDelay;
        serverRemovalEvents.erase(it);

        cout << "t=" << simTime() << " [ServiceBExecutionManager] doRemoveServer new moduleId=" << moduleId << " offDelay=" << offDelay << endl;
    }

    // disconnect module
    cModule *module = getSimulation()->getModule(moduleId);
    cGate* pInGate = module->gate("in");
    if (pInGate->isConnected()) {
        cGate *otherEnd = pInGate->getPathStartGate();
        otherEnd->disconnect();
        ASSERT(otherEnd->getIndex() == otherEnd->getVectorSize()-1);

        // reduce the size of the out gate in the queue module
        otherEnd->getOwnerModule()->setGateSize(otherEnd->getName(), otherEnd->getVectorSize()-1);
        // this is probably leaking memory because the gate may not be being deleted
    }

    if(cmdenvLogging) {
         std::cout << "t=" << simTime() << " [ServiceBExecutionManager] doRemoveServer(id=" << moduleId << "): moduleName=" << module->getName() << endl;
    }

    // check to see if we can delete the server immediately (or if it's busy)
    if (isServerBeingRemoveEmpty(moduleId)) {
        completeServerRemoval(moduleId);
    } else {
        serverBBeingRemovedModuleIds.push_back(moduleId);
    }
}

void ServiceBExecutionManager::completeServerRemoval(int moduleId) {
    Enter_Method("sendMe()");

    // clear cache for server, so that the next time it is instantiated it is fresh
    cModule* module = getSimulation()->getModule(moduleId);
    check_and_cast<ServiceBMTBrownoutServer*>(module->getSubmodule(INTERNAL_SERVERB_MODULE_NAME))->clearServerCache();

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBExecutionManager] completeServerRemoval(id="<< moduleId <<"): clearServerCache" << endl;
    }

    ServiceBBootComplete* pBootComplete = new ServiceBBootComplete;
    pBootComplete->setModuleId(moduleId);
    pBootComplete->setExpectedChange("removeServerB");

    scheduleAt(simTime(), pBootComplete);
}

bool ServiceBExecutionManager::isServerBeingRemoveEmpty(int moduleId) {

    bool isEmpty = false;
    cModule* module = getSimulation()->getModule(moduleId);
    ServiceBMTBrownoutServer* internalServer = check_and_cast<ServiceBMTBrownoutServer*> (module->getSubmodule(INTERNAL_SERVERB_MODULE_NAME));
    if (internalServer->isEmpty()) {
        queueing::PassiveQueue* queue = check_and_cast<queueing::PassiveQueue*> (module->getSubmodule(INTERNAL_QUEUEB_MODULE_NAME));
        if (queue->length() == 0) {
            isEmpty = true;
        }
    }

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBExecutionManager] isServerBeingRemoveEmpty=" << isEmpty << endl;
    }

    return isEmpty;
}

void ServiceBExecutionManager::notifyRemoveServerCompleted(const char* serverId) {

    // update model for notify remove server completed
    pModel->serverBecameShutDown();

    // emit signal to notify others (notably simProbe)
    emit(serverBRemovedSignal, serverId);
}

void ServiceBExecutionManager::receiveSignal(cComponent *source, simsignal_t signalID, bool value, cObject *details) {

    if (signalID == serverBBusySignal && value == false) {
        std::vector<int>::iterator it = std::find(serverBBeingRemovedModuleIds.begin(), serverBBeingRemovedModuleIds.end(), source->getParentModule()->getId());

        if (it != serverBBeingRemovedModuleIds.end()) {

            int serverBBeingRemovedModuleId = it[0];
            serverBBeingRemovedModuleIds.erase(it);

            if(cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceBExecutionManager] serverBBeingRemovedModuleId=" << serverBBeingRemovedModuleId << endl;
            }

            if (isServerBeingRemoveEmpty(serverBBeingRemovedModuleId)) {
                completeServerRemoval(serverBBeingRemovedModuleId);
            }
        }
    }
}
