/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICEBUTILITYSCORER_H_
#define SERVICEBUTILITYSCORER_H_

#include <omnetpp.h>
#include "managers/model/ServiceBModel.h"

#define MAX_SERVERS      omnetpp::getSimulation()->getSystemModule()->getSubmodule("serviceC")->par("maxServersXML").xmlValue()->getNodeValue()
#define RT_THRESHOLD     omnetpp::getSimulation()->getSystemModule()->getSubmodule("serviceB")->par("responseTimeThreshold").doubleValue()
#define MAX_SERVICE_RATE omnetpp::getSimulation()->getSystemModule()->getSubmodule("serviceB")->par("maxServiceRate").doubleValue()
#define NORMAL_REVENUE   omnetpp::getSimulation()->getSystemModule()->getSubmodule("serviceB")->par("normalRevenue").doubleValue()
#define BROWNOUT_REVENUE omnetpp::getSimulation()->getSystemModule()->getSubmodule("serviceB")->par("brownoutRevenue").doubleValue()

class ServiceBUtilityScorer {

  public:
    /**
     * Computes accrued utility
     */
    static double getAccruedUtility(ServiceBModel* model, double measuredArrivalRate, double measuredAvgRespTime);
};

#endif
