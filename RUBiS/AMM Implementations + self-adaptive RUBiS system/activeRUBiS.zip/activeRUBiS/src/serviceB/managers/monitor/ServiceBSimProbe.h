/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICEBSIMPROBE_H_
#define SERVICEBSIMPROBE_H_

#include "managers/util/ServiceBTimeWindowStats.h"
#include "managers/model/ServiceBModel.h"

using namespace omnetpp;
using namespace std;

/**
 * This class collects statistics from the simulated system
 */
class ServiceBSimProbe : public omnetpp::cSimpleModule, omnetpp::cListener {

  public:
    //logging
    bool cmdenvLogging;

    //control
    double controlPeriod;

    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, const omnetpp::SimTime& t, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, double value, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, bool value, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, const char* value, cObject *details) override;

    double getUtilization(const std::string& serverName);

    ServiceBObservations getUpdatedObservations();
    ServiceBEnvironment getUpdatedEnvironment();

  protected:
    /* subscribed arrivalMonitor signals */
    simsignal_t serviceBInterArrivalSignal;

    /* subscribed server signals */
    simsignal_t serverBServiceTimeSignal;

    /* subscribed sink signals */
    simsignal_t serviceBLifeTimeSignal;

    /* subscribed server state signals */
    simsignal_t serverBBusySignal;
    simsignal_t serverBRemovedSignal;

    double window; /* time window in seconds for statistics */
    ServiceBTimeWindowStats arrival;
    ServiceBTimeWindowStats basicServiceTime;
    ServiceBTimeWindowStats optServiceTime;
    ServiceBTimeWindowStats basicResponseTime;
    ServiceBTimeWindowStats optResponseTime;
    ServiceBTimeWindowStats responseTime;

    std::map<std::string, ServiceBTimeWindowStats> utilization;

    ServiceBModel* pModel;

    virtual int numInitStages() const override {return 2;}
    virtual void initialize(int stage) override;
    virtual void handleMessage(omnetpp::cMessage *msg) override;
};

#endif
