/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICEBSIMMONITOR_H_
#define SERVICEBSIMMONITOR_H_

#include <omnetpp.h>
#include <memory>
#include "managers/model/ServiceBModel.h"
#include "ServiceBSimProbe.h"

using namespace omnetpp;
using namespace std;

#define DLL_PUBLIC __attribute__ ((visibility("default")))

/**
 * Periodically collects monitoring data from the probes and updates the model
 */
class DLL_PUBLIC ServiceBSimMonitor : public omnetpp::cSimpleModule, omnetpp::cListener {

  protected:
    omnetpp::cMessage *periodEvent; // pointer to the event object which we'll use for timing

    ServiceBModel *pModel;
    ServiceBSimProbe *pSimProbe;

    ServiceBEnvironment environment;
    ServiceBObservations observations;

    // logging
    bool cmdenvLogging;

    // ident
    bool identTrigger;
    std::string identServiceModule;

    // control
    bool controlTrigger;
    std::string controlServiceModule;
    double controlPeriod;
    double warmUpPeriod;

    // supervision
    bool supervisionTrigger;

    // measurements
    double measuredArrivalRate;
    double measuredAvgRespTime;

    virtual int numInitStages() const {return 2;}
    virtual void initialize(int stage);
    virtual void handleMessage(omnetpp::cMessage *msg);

    /**
     * Code to be executed periodically, according to the evaluation period,
     * before the adaptation happens
     */
    virtual void periodicHandler();

  public:
    double getMeasuredArrivalRate();
    double getMeasuredAvgRespTime(); // considering sensor noise
};

#endif
