/*******************************************************************************
 * Data Collection for System Identification.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <boost/tokenizer.hpp>
#include "ServiceBDataCollection.h"

Define_Module(ServiceBDataCollection);

#define RNG 3

void ServiceBDataCollection::initialize() {

    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

    // identification
    cXMLElement *identTriggerNode = getSimulation()->getSystemModule()->par("identTriggerXML").xmlValue();
    identTrigger = string(identTriggerNode->getNodeValue())=="true" ? 1 : 0;

    cXMLElement *identServiceModuleNode = getSimulation()->getSystemModule()->par("identServiceModuleXML").xmlValue();
    identServiceModule = string(identServiceModuleNode->getNodeValue());

    if (identTrigger && identServiceModule=="serviceB") {

        cXMLElement *identDimmerVecNode = getSimulation()->getSystemModule()->par("identDimmerVecXML").xmlValue();
        identDimmerVec = split(identDimmerVecNode->getNodeValue());

        cXMLElement *identServersVecNode = getSimulation()->getSystemModule()->par("identServersVecXML").xmlValue();
        identServersVec = split(identServersVecNode->getNodeValue());

        cXMLElement *initialServersNode = getParentModule()->par("initialServersXML").xmlValue();
        identServers = atoi(initialServersNode->getNodeValue());

        pModel = check_and_cast<ServiceBModel*> (getParentModule()->getSubmodule("modelB"));
        pMonitor = check_and_cast<ServiceBSimMonitor*> (getParentModule()->getSubmodule("simMonitorB"));
        pExecMgr = check_and_cast<ServiceBExecutionManager*> (getParentModule()->getSubmodule("executionManagerB"));

        // tracing
        identFilePath = "../ident/serviceBIdentTrace.txt";

        // delete old control trace file
        ifstream cpFin(identFilePath.c_str());
        if (!cpFin) {
            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceBDataCollection] " << identFilePath << " does not exist" << endl;
            }
        } else {
            remove(identFilePath.c_str());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceBDataCollection] Delete " << identFilePath << endl;
            }
        }

        // first line of control trace file
        ofstream out;
        out.open(identFilePath.c_str(), ios::app);
        if (out.is_open()) {
            out << "identServers_{k-1},";
            out << "measuredServers_{k},";
            out << "measuredActiveServers_{k},";
            out << "measuredArrivalRate_{k},";
            out << "measuredAvgRespTime_{k}\n";
            out.close();
        }
    }
}

void ServiceBDataCollection::handleMessage(cMessage *msg) {
    measuredOutputs = getMeasuredOutputs();
    writeIdentTrace(measuredOutputs);
    setIdentControlParameters();

    // finished
    delete msg;
}

ServiceBDataCollection::MeasuredOutputsEvent ServiceBDataCollection::getMeasuredOutputs() {

    // update measurements
    measuredOutputs.measuredDimmer = (1.0 - pModel->getBrownoutFactor());
    measuredOutputs.measuredServers = pModel->getServers();
    measuredOutputs.measuredActiveServers = pModel->getActiveServers();
    measuredOutputs.measuredArrivalRate = pMonitor->getMeasuredArrivalRate();
    measuredOutputs.measuredAvgRespTime = pMonitor->getMeasuredAvgRespTime();

    cout << "t=" << simTime() << " [ServiceBDataCollection] measuredOutputs"
                              << " measuredDimmer[" << num << "]="         << measuredOutputs.measuredDimmer
                              << " measuredServers[" << num << "]="        << measuredOutputs.measuredServers
                              << " measuredActiveServers[" << num << "]="  << measuredOutputs.measuredActiveServers
                              << " measuredArrivalRate[" << num << "]="    << measuredOutputs.measuredArrivalRate
                              << " measuredAvgRespTime[" << num << "]="    << measuredOutputs.measuredAvgRespTime << endl;

    return measuredOutputs;
}

void ServiceBDataCollection::setIdentControlParameters() {

    // set dimmer
    double dimmer = identDimmerVec[num];
    pExecMgr->setBrownout(1.0-dimmer);

    // set servers
    identServers = identServersVec[num];

    if(identServers > pModel->getServers()) {
        int additionalServers = identServers - pModel->getServers();
        for(int i = 0; i < additionalServers; i++) {
            pExecMgr->addServer();
        }
    }
    else {
        int removalServers = pModel->getServers() - identServers;
        for(int i = 0; i < removalServers; i++) {
            pExecMgr->removeServer();
        }
    }

    num = num + 1;
}

void ServiceBDataCollection::writeIdentTrace(MeasuredOutputsEvent measuredOutputs) {
    ofstream out;
    out.open(identFilePath.c_str(), ios::app);
    if (out.is_open()) {
        out << identServers;
        out << ",";
        out << measuredOutputs.measuredServers;
        out << ",";
        out << measuredOutputs.measuredActiveServers;
        out << ",";
        out << measuredOutputs.measuredArrivalRate;
        out << ",";
        out << measuredOutputs.measuredAvgRespTime;
        out << "\n";
        out.close();
    }
}

std::vector<double> ServiceBDataCollection::split(std::string str) {
    std::vector<double> results;
    typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
    tokenizer tokens(str, boost::char_separator<char>(","));
    tokenizer::iterator it = tokens.begin();

    int splitNum = 0;
    cout << "t=" << simTime() << " [ServiceBDataCollection] ";
    if (it != tokens.end()) {
        string command = *it;
        while (it != tokens.end()) {
            results.push_back(atof((*it).c_str()));
            splitNum++;
            std::cout<<atof((*it).c_str())<<",";
            it++;
        }
    }
    cout << endl;
    cout << "t=" << simTime() << " [ServiceBDataCollection] splitNum=" << splitNum << endl;

    return results;
}
