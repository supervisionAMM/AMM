/*******************************************************************************
 * Controller for Servers.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef CONTROLLER_H_
#define CONTROLLER_H_

#include <omnetpp.h>
#include "managers/model/Model.h"
#include "managers/monitor/SimMonitor.h"

using namespace omnetpp;
using namespace std;

class Controller : public cSimpleModule
{
  public:
    // logging
    bool cmdenvLogging;

    // control
    bool controlTrigger;

    // measurements
    double measuredArrivalRate;

    Model *pModel;
    SimMonitor *pMonitor;

    // count
    int num = 0;

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
