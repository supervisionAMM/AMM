/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SIMPROBE_H_
#define SIMPROBE_H_

#include <managers/model/Model.h>
#include <managers/util/TimeWindowStats.h>

using namespace omnetpp;
using namespace std;

/**
 * This class collects statistics from the simulated system
 */
class SimProbe : public omnetpp::cSimpleModule, omnetpp::cListener {

  public:
    //logging
    bool cmdenvLogging;

    //control
    double controlPeriod;

    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, double value, cObject *details) override;

    Environment getUpdatedEnvironment();

  protected:
    /* subscribed arrivalMonitor signals */
    simsignal_t interArrivalSignal;

    double window; /* time window in seconds for statistics */
    TimeWindowStats arrival;

    Model* pModel;

    virtual int numInitStages() const override {return 2;}
    virtual void initialize(int stage) override;
    virtual void handleMessage(omnetpp::cMessage *msg) override;
};

#endif
