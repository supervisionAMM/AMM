/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <set>
#include <iostream>
#include <fstream>
#include "SimProbe.h"

Define_Module(SimProbe);

void SimProbe::initialize(int stage) {
    if (stage == 1) {

        pModel = check_and_cast<Model*>(getSimulation()->getSystemModule()->getSubmodule("model"));

        // logging
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");

        // control
        controlPeriod = getSimulation()->getSystemModule()->par("controlPeriod").doubleValue();

        // register arrivalMonitor signals
        interArrivalSignal = registerSignal("interArrival");
        getSimulation()->getSystemModule()->subscribe(interArrivalSignal, this);

        // time windows
        window = controlPeriod;
        arrival.setWindow(window);
    }
}

void SimProbe::receiveSignal(cComponent *source, simsignal_t signalID, double value, cObject *details) {
    if (signalID == interArrivalSignal) {
        arrival.record(value);
    }
}

void SimProbe::handleMessage(cMessage *msg) {
}

Environment SimProbe::getUpdatedEnvironment() {
    double arrivalRate = arrival.getRate();
    double measuredMeanInterArrival = (arrivalRate > 0) ? (1.0/arrivalRate) : 0.0;

    Environment environment;
    environment.setArrivalRate(arrivalRate);
    environment.setArrivalMean(measuredMeanInterArrival);
    environment.setArrivalVariance(pow(measuredMeanInterArrival, 2)); // assume exponential distribution

    return environment;
}
