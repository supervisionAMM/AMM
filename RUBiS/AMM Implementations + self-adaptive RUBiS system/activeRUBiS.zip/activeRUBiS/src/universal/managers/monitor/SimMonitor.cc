/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <cmath>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include "managers/model/UtilityScorer.h"
#include "SimMonitor.h"

Define_Module(SimMonitor);

void SimMonitor::initialize(int stage) {
    if (stage == 1) {

        pModel = check_and_cast<Model*>(getSimulation()->getSystemModule()->getSubmodule("model"));
        pSimProbe = check_and_cast<SimProbe*>(getSimulation()->getSystemModule()->getSubmodule("simProbe"));

        pModelA = check_and_cast<ServiceAModel*>(getSimulation()->getSystemModule()->getSubmodule("serviceA")->getSubmodule("modelA"));
        pModelB = check_and_cast<ServiceBModel*>(getSimulation()->getSystemModule()->getSubmodule("serviceB")->getSubmodule("modelB"));
        pModelC = check_and_cast<ServiceCModel*>(getSimulation()->getSystemModule()->getSubmodule("serviceC")->getSubmodule("modelC"));

        // logging
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");

        // control
        cXMLElement *controlTriggerNode = getSimulation()->getSystemModule()->par("controlTriggerXML").xmlValue();
        controlTrigger = string(controlTriggerNode->getNodeValue())=="true" ? 1 : 0;

        controlPeriod = getSimulation()->getSystemModule()->par("controlPeriod").doubleValue();
        warmUpPeriod = getSimulation()->getSystemModule()->par("warmUpPeriod").doubleValue();

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [SimMonitor] initialize"
                                      << " controlTrigger=" << controlTrigger
                                      << " controlPeriod="  << controlPeriod
                                      << " warmUpPeriod="   << warmUpPeriod << endl;
        }

        if (controlTrigger) {

            utilityFilePath = "results/rubisUniveralUtility.txt";

            // Delete old control trace file
            ifstream cpFin(utilityFilePath.c_str());
            if (!cpFin) {
                if (cmdenvLogging) {
                    cout << "t=" << simTime() << " [SimMonitor] " << utilityFilePath << " does not exist" << endl;
                }
            } else {
                remove(utilityFilePath.c_str());

                if (cmdenvLogging) {
                    cout << "t=" << simTime() << " [SimMonitor] Delete " << utilityFilePath << endl;
                }
            }
        }

        // Create the event objects we'll use for timing -- just any ordinary message.
        periodEvent = new cMessage("periodEvent");
        scheduleAt(controlPeriod, periodEvent);
    }
}

void SimMonitor::handleMessage(cMessage *msg) {
    /*
     * the monitoring is divided into two parts:
     * One updates environment, observations and utility
     * One triggers adaptation and supervision
     */
    if (msg == periodEvent) {
        periodicHandler();
        scheduleAt(simTime() + controlPeriod, periodEvent);

        if (simTime() > warmUpPeriod) {

            // measurements
            measuredArrivalRate = pModel->getEnvironment().getArrivalRate();

            if (controlTrigger) {

                if (cmdenvLogging) {
                    cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
                }

                // utility
                utility = UtilityScorer::getAccruedUtility(pModelA, pModelB, pModelC);
                pModel->setUtility(utility);
                pModel->setCumUtility(utility);

                if (cmdenvLogging) {
                    cout << "t=" << simTime() << " [SimMonitor] utility=" << pModel->getUtility() << endl;
                    cout << "t=" << simTime() << " [SimMonitor] cumUtility=" << pModel->getCumUtility() << endl;
                }

                // trace
                writeControlTrace();

                cMessage *controlEvent = new cMessage("controlEvent");
                send(controlEvent, "ctrl");
            }
        }
    }
}

void SimMonitor::periodicHandler() {
    environment = pSimProbe->getUpdatedEnvironment();
    pModel->setEnvironment(environment);
}

double SimMonitor::getMeasuredArrivalRate() {
    return measuredArrivalRate;
}

void SimMonitor::writeControlTrace() {
    ofstream out;
    out.open(utilityFilePath.c_str(), ios::app);
    if (out.is_open()) {
        out << measuredArrivalRate;
        out << ",";
        out << utility;
        out << ",";
        out << pModel->getCumUtility();
        out << "\n";
        out.close();
    }
}
