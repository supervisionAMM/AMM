/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef MODEL_H_
#define MODEL_H_

#include <set>
#include <omnetpp.h>
#include "Environment.h"

using namespace omnetpp;
using namespace std;

class Model : public omnetpp::cSimpleModule {

  protected:
    // logging
    bool cmdenvLogging;

    // utility
    double utility = 0;
    double cumUtility = 0;

    // environment
    Environment environment;

    virtual void initialize(int stage);

  public:
    // utility
    double getUtility() const;
    void setUtility(double utility);
    double getCumUtility() const;
    void setCumUtility(double utility);

    // environment
    const Environment& getEnvironment() const;
    virtual void setEnvironment(const Environment& environment);
};

#endif
