/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SIMSOURCE_H_
#define SIMSOURCE_H_

#include <vector>
#include "Source.h"

using namespace omnetpp;
using namespace std;

/**
 * Generate arrival jobs from identWorkloadFile or interArrivalsFile
 */
class SimSource : public queueing::SourceBase {

  protected:
    // logging
    bool cmdenvLogging;

    //identification
    bool identTrigger;

    // workload
    const char* workloadFilePath;
    std::vector<double> serviceAInterArrivalTimes; // Store the interval time between two adjacent arrival jobs
    std::vector<double> serviceBInterArrivalTimes;
    std::vector<double> serviceCInterArrivalTimes;
    std::vector<double> serviceAArrivalTimes; // Store the arrival time for every arrival jobs from interArrivalsFile
    std::vector<double> serviceBArrivalTimes;
    std::vector<double> serviceCArrivalTimes;
    unsigned serviceANextArrivalIndex;
    unsigned serviceBNextArrivalIndex;
    unsigned serviceCNextArrivalIndex;

    /**
     * Preload interarrivals
     * Must generate at least one arrival
     */
    virtual void preload();

    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
