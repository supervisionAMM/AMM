#ifndef SENSOR_HPP
#define SENSOR_HPP

#include <stdio.h> 
#include <string>
#include <vector>

#include <random>
#include <stdint.h>

#include "archlib/target_system/Component.hpp"
#include "archlib/AdaptationCommand.h"

#include "services/InjectorData.h"

#include "libbsn/resource/Battery.hpp"
#include "libbsn/utils/utils.hpp"

class Sensor : public arch::target_system::Component {

    public:
		Sensor(int &argc, char **argv, const std::string &name, const std::string &type, const bool &active, const double &injector_factor, const bsn::resource::Battery &battery, const bool &instant_recharge);
    	~Sensor();

	private:
    	Sensor &operator=(const Sensor &);

  	public:
        virtual void setUp() = 0;
    	virtual void tearDown() = 0;
        virtual int32_t run();
		void body();

        void reconfigure(const archlib::AdaptationCommand::ConstPtr& msg);
		
        virtual double collect() = 0;
        virtual double process(const double &data) = 0;
        virtual void transfer(const double &data) = 0;

        // Evaluation
        double BATT_UNIT;
        double BATT_UNIT_sigma;
        double BATT_UNIT_offset;

        // Process noise 
        int uncertainty_trigger;
        int random_seed; 
		std::normal_distribution<double> PNGenerator;
		std::mt19937 rng;

        // Injector 
        double injector_factor;
        double injector_offset;
        
        // Tracing
        int data_tracing;
        int sensor_freq;
        double raw_cost;

    protected:
        bool isActive();
        void turnOn();
        void turnOff();
        void recharge();

    protected:
		std::string type;
		bool active;
        int buffer_size;
        int replicate_collect;
		bsn::resource::Battery battery;
        double data;
        bool instant_recharge;
        bool shouldStart;
        double cost;
};

#endif 