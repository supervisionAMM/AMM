#ifndef G4T1_HPP
#define G4T1_HPP

#include <memory>
#include <map>

#include <exception>
#include <iostream>
#include <fstream>

#include <stdlib.h>
#include <sys/stat.h>
#include <cstdio>

#include "ros/ros.h"
#include "ros/package.h"

#include "libbsn/processor/Processor.hpp"
#include "libbsn/utils/utils.hpp"
#include "messages/TargetSystemData.h"

#include "component/CentralHub.hpp" 

class G4T1 : public CentralHub {
    
    public:
        G4T1(int &argc, char **argv, const std::string &name);
        virtual ~G4T1();

    private:
        G4T1(const G4T1 & /*obj*/);
        G4T1 &operator=(const G4T1 & /*obj*/);

        std::string makePacket();
        std::vector<std::string> getPatientStatus();
        int32_t getSensorId(std::string type);

    public:
        virtual void setUp();
        virtual void tearDown();   

        virtual void collect(const messages::SensorData::ConstPtr& sensor_data);
        virtual void process();
        virtual void transfer();

		// Tracing
		int data_tracing;

        std::fstream fp;
        std::string g4t1_g3t1_1_filepath, g4t1_g3t1_2_filepath, g4t1_g3t1_3_filepath;
        std::string g4t1_g3t1_4_filepath, g4t1_g3t1_5_filepath, g4t1_g3t1_6_filepath;

    private:
        int oxi_freq;
        int ecg_freq;
        int trm_freq;
        int abps_freq;
        int abpd_freq;
        int glc_freq;

        double oxi_data;
        double ecg_data;
        double trm_data;
        double abps_data;
        double abpd_data;
        double glc_data;

        double oxi_risk;
        double ecg_risk;
        double trm_risk;
        double abps_risk;
        double abpd_risk;
        double glc_risk;

        double oxi_batt;
        double ecg_batt;
        double trm_batt;
        double abps_batt;
        double abpd_batt;
        double glc_batt;

        double patient_status;

        ros::Publisher pub;
        
        bool lost_packt;
};

#endif 