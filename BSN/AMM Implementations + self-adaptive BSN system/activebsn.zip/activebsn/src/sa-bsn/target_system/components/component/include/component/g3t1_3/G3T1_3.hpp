#ifndef G3T1_3_HPP
#define G3T1_3_HPP

#include <exception>
#include <iostream>
#include <fstream>

#include <stdlib.h>
#include <sys/stat.h>
#include <cstdio>

#include "ros/ros.h"
#include "ros/package.h"

#include "libbsn/range/Range.hpp"
#include "libbsn/resource/Battery.hpp"
#include "libbsn/generator/Markov.hpp"
#include "libbsn/generator/DataGenerator.hpp"
#include "libbsn/filters/MovingAverage.hpp"
#include "libbsn/utils/utils.hpp"
#include "libbsn/configuration/SensorConfiguration.hpp"

#include "component/Sensor.hpp"

#include "messages/SensorData.h"
#include "services/PatientData.h"

class G3T1_3 : public Sensor {
    	
  	public:
    	G3T1_3(int &argc, char **argv, const std::string &name);
    	virtual ~G3T1_3();

	private:
      	G3T1_3(const G3T1_3 &);
    	G3T1_3 &operator=(const G3T1_3 &);

		std::string label(double &risk);
    
	public:
		virtual void setUp();
    	virtual void tearDown();

        double collect();
        double process(const double &data);
        void transfer(const double &data);

		// Tracing
        std::fstream fp;
        std::string g3t1_filepath;

  	private:
		bsn::generator::Markov markov;
		bsn::generator::DataGenerator dataGenerator;		
		bsn::filters::MovingAverage filter;
		bsn::configuration::SensorConfiguration sensorConfig;

		ros::NodeHandle handle;
		ros::Publisher data_pub;
		ros::ServiceClient client;	

		double collected_risk;
};

#endif 