#include "component/g3t1_4/G3T1_4.hpp"

using namespace bsn::range;
using namespace bsn::resource;
using namespace bsn::generator;
using namespace bsn::configuration;

G3T1_4::G3T1_4(int &argc, char **argv, const std::string &name) :
    Sensor(argc, argv, name, "abps", true, 1, bsn::resource::Battery("abps_batt", 100, 100, 1), false),
    markov(),
    dataGenerator(),
    filter(1),
    sensorConfig(),
    collected_risk() {}

G3T1_4::~G3T1_4() {}

void G3T1_4::setUp() {
    
    Component::setUp();
    
    std::array<bsn::range::Range,5> ranges;
    std::string s;

    handle.getParam("start", shouldStart);

    { // Get ranges
        std::vector<std::string> lrs,mrs0,hrs0,mrs1,hrs1;

        handle.getParam("abps_HighRisk0", s);
        hrs0 = bsn::utils::split(s, ',');
        handle.getParam("abps_MidRisk0", s);
        mrs0 = bsn::utils::split(s, ',');
        handle.getParam("abps_LowRisk", s);
        lrs = bsn::utils::split(s, ',');
        handle.getParam("abps_MidRisk1", s);
        mrs1 = bsn::utils::split(s, ',');
        handle.getParam("abps_HighRisk1", s);
        hrs1 = bsn::utils::split(s, ',');

        ranges[0] = Range(std::stod(hrs0[0]), std::stod(hrs0[1]));
        ranges[1] = Range(std::stod(mrs0[0]), std::stod(mrs0[1]));
        ranges[2] = Range(std::stod(lrs[0]), std::stod(lrs[1]));
        ranges[3] = Range(std::stod(mrs1[0]), std::stod(mrs1[1]));
        ranges[4] = Range(std::stod(hrs1[0]), std::stod(hrs1[1]));
    }

    { // Configure sensor configuration
        Range low_range = ranges[2];
        
        std::array<Range,2> midRanges;
        midRanges[0] = ranges[1];
        midRanges[1] = ranges[3];
        
        std::array<Range,2> highRanges;
        highRanges[0] = ranges[0];
        highRanges[1] = ranges[4];

        std::array<Range,3> percentages;

        handle.getParam("lowrisk", s);
        std::vector<std::string> low_p = bsn::utils::split(s, ',');
        percentages[0] = Range(std::stod(low_p[0]), std::stod(low_p[1]));

        handle.getParam("midrisk", s);
        std::vector<std::string> mid_p = bsn::utils::split(s, ',');
        percentages[1] = Range(std::stod(mid_p[0]), std::stod(mid_p[1]));

        handle.getParam("highrisk", s);
        std::vector<std::string> high_p = bsn::utils::split(s, ',');
        percentages[2] = Range(std::stod(high_p[0]), std::stod(high_p[1]));

        sensorConfig = SensorConfiguration(0, low_range, midRanges, highRanges, percentages);
    }

    { //Check for instant recharge parameter
        handle.getParam("instant_recharge", instant_recharge);
    }

    // Tracing
    handle.getParam("data_tracing", data_tracing);
    
    if (data_tracing == 1) {
        std::string trace_dir = ros::package::getPath("component") + "/traces";

        // Make new directory
        struct stat st;
        if (stat(trace_dir.c_str(), &st) == -1) {
            std::string makeCommand = "mkdir -p " + trace_dir;
            system(makeCommand.c_str());
        }
        
        g3t1_filepath = trace_dir + "/component_g3t1_4_trace.txt";
        fp.open(g3t1_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),vitalSign,sensor_freq,raw_data,raw_cost,BATT_UNIT_offset,injector_offset,cost\n";
        fp.close();
    }    

    // Evaluation
    handle.getParam("BATT_UNIT", BATT_UNIT);
    handle.getParam("BATT_UNIT_sigma", BATT_UNIT_sigma);

    handle.getParam("uncertainty_trigger", uncertainty_trigger);
    handle.getParam("random_seed", random_seed);
    
    PNGenerator = std::normal_distribution<double> (0.0, BATT_UNIT_sigma);
    
    if (random_seed == -1) {
        std::random_device rd;
        rng.seed(rd());

    } else if (random_seed >= 0) {
        rng.seed(random_seed);
    }
}

void G3T1_4::tearDown() {
    Component::tearDown();
}

double G3T1_4::collect() {
    double m_data = 0;

    // Patient service
    ros::ServiceClient patient_client = handle.serviceClient<services::PatientData>("getPatientData");
    services::PatientData patient_srv;

    // Request
    patient_srv.request.vitalSign = "abps";
    patient_srv.request.sensorFreq = rosComponentDescriptor.getFreq();

    // Response
    if (patient_client.call(patient_srv)) {
        timestamp = patient_srv.response.timestamp;
        m_data = patient_srv.response.data;    
        ROS_INFO("new data collected: [%s]", std::to_string(m_data).c_str());
    } else {
        ROS_INFO("error collecting data");
    }

    // Injector service
    ros::ServiceClient injector_client = handle.serviceClient<services::InjectorData>("getInjectorData");
    services::InjectorData injector_srv;

    // Request
    std::string sensor_name = rosComponentDescriptor.getName();
    injector_srv.request.component = sensor_name.substr(1, sensor_name.size());
    injector_srv.request.timestamp = timestamp;
    injector_srv.request.sensorFreq = rosComponentDescriptor.getFreq();

    // Response
    if (injector_client.call(injector_srv)) {
        injector_factor = injector_srv.response.data;
        ROS_INFO("new injector_factor: [%s]", std::to_string(injector_factor).c_str());
    } else {
        ROS_INFO("error applying injector_factor");
    }

    // Cost
    cost += BATT_UNIT;

    // Tracing
    sensor_freq = patient_srv.request.sensorFreq; 

    collected_risk = sensorConfig.evaluateNumber(m_data);

    return m_data;
}

double G3T1_4::process(const double &m_data) {
    double filtered_data;
    
    filter.insert(m_data);
    filtered_data = filter.getValue();

    ROS_INFO("filtered data: [%s]", std::to_string(filtered_data).c_str());

    // Cost
    cost += BATT_UNIT;

    // Environment uncertainty
    if (uncertainty_trigger == 1) {
        injector_offset = BATT_UNIT * injector_factor;
    } 

    return filtered_data;
}

void G3T1_4::transfer(const double &m_data) {
    double risk;
    risk = sensorConfig.evaluateNumber(m_data);

    if (risk < 0 || risk > 100) throw std::domain_error("risk data out of boundaries");
    if (label(risk) != label(collected_risk)) throw std::domain_error("sensor accuracy fail");

    // Cost 
    cost += BATT_UNIT;
    raw_cost = cost;

    // Process noise and environment uncertainty
    if (uncertainty_trigger == 1) {
        BATT_UNIT_offset = PNGenerator(rng);
        cost += (BATT_UNIT_offset + injector_offset);
    }
    battery.consume(cost);

    ros::NodeHandle handle;
    data_pub = handle.advertise<messages::SensorData>("abps_data", 100);
    
    messages::SensorData msg;
    msg.type = type;
    msg.timestamp = timestamp;
    msg.sensorFreq = sensor_freq;
    msg.data = m_data;
    msg.risk = risk;
    msg.batt = battery.getCurrentLevel();

    data_pub.publish(msg);

    ROS_INFO("risk calculated and transferred: [%.2f%%]", risk);

    // Tracing
    if (data_tracing == 1) {
        fp.open(g3t1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
        fp << floor(timestamp/1000.0) << ",";
        fp << timestamp << ",";
        fp << "abps" << ","; 
        fp << sensor_freq << ",";   
        fp << m_data << ",";             
        fp << raw_cost << ",";  
        fp << BATT_UNIT_offset << ",";   
        fp << injector_offset << ","; 
        fp << cost << "\n"; 
        fp.close(); 
    } 
}

std::string G3T1_4::label(double &risk) {
    std::string ans;
    if(sensorConfig.isLowRisk(risk)){
        ans = "low";
    } else if (sensorConfig.isMediumRisk(risk)) {
        ans = "moderate";
    } else if (sensorConfig.isHighRisk(risk)) {
        ans = "high";
    } else {
        ans = "unknown";
    }

    return ans;
}