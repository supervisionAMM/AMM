#include "component/g3t1_1/G3T1_1.hpp"

int main(int argc, char **argv) {
    G3T1_1 g3t1_1(argc, argv, "oximeter");
    return g3t1_1.run();
}