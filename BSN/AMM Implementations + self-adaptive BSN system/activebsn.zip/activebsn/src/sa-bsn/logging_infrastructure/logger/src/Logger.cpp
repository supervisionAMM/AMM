#include "Logger.hpp"

Logger::Logger(int  &argc, char **argv, const std::string &name) : ROSComponent(argc, argv, name) {}

Logger::~Logger() {}

void Logger::setUp() {
    adapt = handle.advertise<archlib::AdaptationCommand>("reconfigure", 1000);
    persist = handle.advertise<archlib::Persist>("persist", 1000);
    status = handle.advertise<archlib::Status>("status", 1000);
    event = handle.advertise<archlib::Event>("event", 1000);

    double freq;
	handle.getParam("frequency", freq);
	rosComponentDescriptor.setFreq(freq);

    // Tracing 
    handle.getParam("data_tracing", data_tracing);

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("logging_infrastructure") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing == 1) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        g3t1_1_energy_status_filepath = trace_dir + "/logger_g3t1_1_energy_status_trace.txt";
        g3t1_2_energy_status_filepath = trace_dir + "/logger_g3t1_2_energy_status_trace.txt";
        g3t1_3_energy_status_filepath = trace_dir + "/logger_g3t1_3_energy_status_trace.txt";
        g3t1_4_energy_status_filepath = trace_dir + "/logger_g3t1_4_energy_status_trace.txt";
        g3t1_5_energy_status_filepath = trace_dir + "/logger_g3t1_5_energy_status_trace.txt";
        g3t1_6_energy_status_filepath = trace_dir + "/logger_g3t1_6_energy_status_trace.txt";      

        g3t1_1_adaptation_filepath = trace_dir + "/logger_g3t1_1_adaptation_trace.txt";
        g3t1_2_adaptation_filepath = trace_dir + "/logger_g3t1_2_adaptation_trace.txt";
        g3t1_3_adaptation_filepath = trace_dir + "/logger_g3t1_3_adaptation_trace.txt";
        g3t1_4_adaptation_filepath = trace_dir + "/logger_g3t1_4_adaptation_trace.txt";
        g3t1_5_adaptation_filepath = trace_dir + "/logger_g3t1_5_adaptation_trace.txt";
        g3t1_6_adaptation_filepath = trace_dir + "/logger_g3t1_6_adaptation_trace.txt";                   

        // Energy status filepath
        for (int index=0; index<6; index++) {
            if (index == 0) {fp.open(g3t1_1_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 1) {fp.open(g3t1_2_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 2) {fp.open(g3t1_3_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 3) {fp.open(g3t1_4_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 4) {fp.open(g3t1_5_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 5) {fp.open(g3t1_6_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

            fp << "time_second,timestamp(ms),name,source,target,freq,content\n";
            fp.close();
        }

        // Adaptation filepath
        for (int index=0; index<6; index++) {
            if (index == 0) {fp.open(g3t1_1_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 1) {fp.open(g3t1_2_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 2) {fp.open(g3t1_3_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 3) {fp.open(g3t1_4_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 4) {fp.open(g3t1_5_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 5) {fp.open(g3t1_6_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

            fp << "time_second,timestamp(ms),source,target,type,action\n";
            fp.close();
        }                                        
    }
}

void Logger::tearDown() {}

void Logger::body() {
    ros::NodeHandle nh;
    ros::Subscriber event_sub = nh.subscribe("log_event", 1000, &Logger::receiveEvent, this);
    ros::Subscriber status_sub = nh.subscribe("log_status", 1000, &Logger::receiveStatus, this);
    ros::Subscriber energy_status_sub = nh.subscribe("log_energy_status", 1000, &Logger::receiveEnergyStatus, this);
    ros::Subscriber reconfig_sub = nh.subscribe("log_adapt", 1000, &Logger::receiveAdaptationCommand, this);
    ros::spin();
}

void Logger::receiveEvent(const archlib::Event::ConstPtr& msg) {
    // ROS_INFO("I heard: [%s: %s]", msg->source.c_str(), msg->content.c_str());

    archlib::Persist persistMsg;
    persistMsg.source = msg->source;
    persistMsg.target = msg->target;
    persistMsg.type = "Event";
    persistMsg.timestamp = msg->timestamp;
    persistMsg.freq = msg->freq;
    persistMsg.content = msg->content;

    persist.publish(persistMsg);
    event.publish(msg);
}

void Logger::receiveStatus(const archlib::Status::ConstPtr& msg) {
    // ROS_INFO("I heard: [%s: %s]", msg->source.c_str(), msg->content.c_str());

    archlib::Persist persistMsg;
    persistMsg.source = msg->source;
    persistMsg.target = msg->target;
    persistMsg.type = "Status";
    persistMsg.timestamp = msg->timestamp;
    persistMsg.freq = msg->freq;
    persistMsg.content = msg->content;

    persist.publish(persistMsg);
    status.publish(msg);
}

void Logger::receiveEnergyStatus(const archlib::EnergyStatus::ConstPtr& msg) {
    // ROS_INFO("I heard: [%s: %s]", msg->source.c_str(), to_string(msg->content).c_str());

    archlib::Persist persistMsg;
    persistMsg.source = msg->source;
    persistMsg.target = msg->target;
    persistMsg.type = "EnergyStatus";
    persistMsg.timestamp = msg->timestamp;
    persistMsg.freq = msg->freq;
    persistMsg.content = msg->content;

    persist.publish(persistMsg);

    // Tracing
    if (data_tracing == 1) {
        if (msg->source == "/g3t1_1") {fp.open(g3t1_1_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_2") {fp.open(g3t1_2_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_3") {fp.open(g3t1_3_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_4") {fp.open(g3t1_4_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_5") {fp.open(g3t1_5_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_6") {fp.open(g3t1_6_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}                                

        fp << floor(msg->timestamp/1000.0) << ",";   
        fp << msg->timestamp << ",";
        fp << msg->source << ",";      
        fp << msg->target << ",";   
        fp << "EnergyStatus" << ","; 
        fp << msg->freq << ",";   
        fp << msg->content << "\n";   
        fp.close();  
    } 
}

void Logger::receiveAdaptationCommand(const archlib::AdaptationCommand::ConstPtr& msg) {
    //ROS_INFO("I heard: [%s: %s]", msg->action.c_str(), msg->target.c_str());

    archlib::Persist persistMsg;
    persistMsg.source = msg->source;
    persistMsg.target = msg->target;
    persistMsg.type = "AdaptationCommand";
    persistMsg.timestamp = msg->timestamp;
    persistMsg.content = msg->action;

    persist.publish(persistMsg);
    adapt.publish(msg);

    // Tracing
    if (data_tracing == 1) {
        if (msg->source == "/g3t1_1") {fp.open(g3t1_1_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_2") {fp.open(g3t1_2_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_3") {fp.open(g3t1_3_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_4") {fp.open(g3t1_4_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_5") {fp.open(g3t1_5_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (msg->source == "/g3t1_6") {fp.open(g3t1_6_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}     

        fp << floor(msg->timestamp/1000.0) << ",";   
        fp << msg->timestamp << ",";
        fp << msg->source << ",";      
        fp << msg->target << ",";   
        fp << "AdaptationCommand" << ",";       
        fp << msg->action << "\n";   
        fp.close();  
    } 
}