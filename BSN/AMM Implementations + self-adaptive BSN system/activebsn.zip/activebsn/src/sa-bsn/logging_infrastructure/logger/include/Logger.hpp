#ifndef LOGGER_HPP
#define LOGGER_HPP

#include <fstream>
#include <iostream>

#include <sys/stat.h>
#include <cstdio>

#include "ros/ros.h"
#include "ros/package.h"

#include "archlib/Event.h"
#include "archlib/Status.h"
#include "archlib/EnergyStatus.h"
#include "archlib/AdaptationCommand.h"
#include "archlib/Persist.h"

#include "archlib/ROSComponent.hpp"

class Logger : public arch::ROSComponent {

	public:
    	Logger(int &argc, char **argv, const std::string &name);
    	virtual ~Logger();

    private:
      	Logger(const Logger &);
    	Logger &operator=(const Logger &);

	public:
		virtual void setUp();
		virtual void tearDown();
		virtual void body();

	  	void receiveEvent(const archlib::Event::ConstPtr& msg);
	  	void receiveStatus(const archlib::Status::ConstPtr& msg);
		void receiveEnergyStatus(const archlib::EnergyStatus::ConstPtr& msg);
		void receiveAdaptationCommand(const archlib::AdaptationCommand::ConstPtr& msg);

		// Tracing
		int data_tracing; 

		std::fstream fp;
		std::string g3t1_1_energy_status_filepath, g3t1_2_energy_status_filepath, g3t1_3_energy_status_filepath;
		std::string g3t1_4_energy_status_filepath, g3t1_5_energy_status_filepath, g3t1_6_energy_status_filepath;
		std::string g3t1_1_adaptation_filepath, g3t1_2_adaptation_filepath, g3t1_3_adaptation_filepath;
		std::string g3t1_4_adaptation_filepath, g3t1_5_adaptation_filepath, g3t1_6_adaptation_filepath;

	protected:
		ros::NodeHandle handle;

	private:
		ros::Publisher adapt, status, event, persist;
};

#endif 