#include "controller/Controller.hpp"

Controller::Controller(int &argc, char **argv, std::string name) : Enactor(argc, argv, name) {}

Controller::~Controller() {}

void Controller::setUp() {
    // Get start time from timer.txt writen in script
    std::string timer_path = ros::package::getPath("enactor") + "/../../timer.txt";

    std::ifstream fin(timer_path);
    if (!fin) {
        ROS_ERROR("Could not read timer.txt.");
    } else {
        std::string timer_str;
        fin >> timer_str;
        time_ref = atoi(timer_str.c_str());
    }
    std::cout << "[setUp] time_ref=" << time_ref << std::endl;

    ros::NodeHandle nh;
    adapt = nh.advertise<archlib::AdaptationCommand>("log_adapt", 10);
    except = nh.advertise<archlib::Exception>("exception", 10);

    double frequency;
	nh.getParam("frequency", frequency);
    rosComponentDescriptor.setFreq(frequency);

    receiveAdaptationParameter(); 
    if (adaptation_parameter != "cost") {adaptation_parameter = "cost";} // handle connetion problem

    int warm_second_time;
    nh.getParam("warm_time", warm_second_time); 
    warm_time = warm_second_time * 1000;
    std::cout << "[setUp] warm_time=" << warm_time << std::endl;

    nh.getParam("mode", mode); 
    std::cout << "[setUp] mode=" << mode << std::endl;

    nh.getParam("time_window", time_window); 
    std::cout << "[setUp] time_window=" << time_window << std::endl;

    nh.getParam("setpoint", setpoint); 
    curr_value["/g3t1_1"] = curr_value["/g3t1_2"] = curr_value["/g3t1_3"] = curr_value["/g3t1_4"] = curr_value["/g3t1_5"] = curr_value["/g3t1_6"] = setpoint;
    ref_value["/g3t1_1"] = ref_value["/g3t1_2"] = ref_value["/g3t1_3"] = ref_value["/g3t1_4"] = ref_value["/g3t1_5"] = ref_value["/g3t1_6"] = setpoint;

    // Nominal model
    std::string nominal_B_str;
    nh.getParam("nominal_B", nominal_B_str); 

    std::vector<std::string> temp = bsn::utils::split(nominal_B_str, ',');
    nominal_B["/g3t1_1"] = atof(temp[0].c_str());
    nominal_B["/g3t1_2"] = atof(temp[1].c_str());
    nominal_B["/g3t1_3"] = atof(temp[2].c_str());
    nominal_B["/g3t1_4"] = atof(temp[3].c_str());
    nominal_B["/g3t1_5"] = atof(temp[4].c_str());
    nominal_B["/g3t1_6"] = atof(temp[5].c_str());
    std::cout << "[setUp] nominal_B=[" << nominal_B["/g3t1_1"] << "," << nominal_B["/g3t1_2"] << "," << nominal_B["/g3t1_3"] << "," 
                                       << nominal_B["/g3t1_4"] << "," << nominal_B["/g3t1_5"] << "," << nominal_B["/g3t1_6"] << "]"  << std::endl;

    nh.getParam("pole", pole); 
    std::cout << "[setUp] pole=" << pole << std::endl;   

    // kp
    kp["/g3t1_1"] = (1.0-pole)/nominal_B["/g3t1_1"];
    kp["/g3t1_2"] = (1.0-pole)/nominal_B["/g3t1_2"];
    kp["/g3t1_3"] = (1.0-pole)/nominal_B["/g3t1_3"];
    kp["/g3t1_4"] = (1.0-pole)/nominal_B["/g3t1_4"];
    kp["/g3t1_5"] = (1.0-pole)/nominal_B["/g3t1_5"];
    kp["/g3t1_6"] = (1.0-pole)/nominal_B["/g3t1_6"];
    std::cout << "[setUp] kp=[" << kp["/g3t1_1"] << "," << kp["/g3t1_2"] << "," << kp["/g3t1_3"] << "," 
                                << kp["/g3t1_4"] << "," << kp["/g3t1_5"] << "," << kp["/g3t1_6"] << "]"  << std::endl;

    nh.getParam("min_freq", min_freq);
    nh.getParam("max_freq", max_freq);
    nh.getParam("max_delta_freq", max_delta_freq);
    std::cout << "[setUp] freqRange=[" << min_freq << "," << max_freq << "] max_delta_freq=" << max_delta_freq << std::endl;

    freq_double["/g3t1_1"] = freq_double["/g3t1_2"] = freq_double["/g3t1_3"] = freq_double["/g3t1_4"] = freq_double["/g3t1_5"] = freq_double["/g3t1_6"] = (double)min_freq;
    freq["/g3t1_1"] = freq["/g3t1_2"] = freq["/g3t1_3"] = freq["/g3t1_4"] = freq["/g3t1_5"] = freq["/g3t1_6"] = min_freq;

    // Model deviation
    nh.getParam("deviation_trigger", deviation_trigger);

    int deviation_second_time;
    nh.getParam("deviation_time", deviation_second_time);
    deviation_time = deviation_second_time * 1000;
    std::cout << "[setUp] deviation_trigger=" << deviation_trigger << " deviation_time=" << deviation_time << std::endl;

    injection_flag["/g3t1_1"] = injection_flag["/g3t1_2"] = injection_flag["/g3t1_3"] = 0;
    injection_flag["/g3t1_4"] = injection_flag["/g3t1_5"] = injection_flag["/g3t1_6"] = 0;

    // Load identification data
    if (mode == "identification") {
        loadSamplingFreqs(); 
        sampling_num = ident_g3t1_1_freqs.size();
        std::cout << "[setUp] sampling_num=" << sampling_num << std::endl;
    }

    // Tracing 
    nh.getParam("data_tracing", data_tracing);

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("enactor") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing == 1) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        g3t1_plant_filepath = trace_dir + "/g3t1_plant_trace.txt";
        fp.open(g3t1_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),component,freq_double,freq,cost\n";
        fp.close();

        g3t1_1_plant_filepath = trace_dir + "/g3t1_1_plant_trace.txt";
        g3t1_2_plant_filepath = trace_dir + "/g3t1_2_plant_trace.txt";
        g3t1_3_plant_filepath = trace_dir + "/g3t1_3_plant_trace.txt";
        g3t1_4_plant_filepath = trace_dir + "/g3t1_4_plant_trace.txt";
        g3t1_5_plant_filepath = trace_dir + "/g3t1_5_plant_trace.txt";
        g3t1_6_plant_filepath = trace_dir + "/g3t1_6_plant_trace.txt";

        for(int index=0; index<6; index++) {
            if (index == 0) {fp.open(g3t1_1_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
            else if (index == 1) {fp.open(g3t1_2_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
            else if (index == 2) {fp.open(g3t1_3_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
            else if (index == 3) {fp.open(g3t1_4_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
            else if (index == 4) {fp.open(g3t1_5_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
            else if (index == 5) {fp.open(g3t1_6_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}

            fp << "time_second,timestamp(ms),component,freq,cost\n";
            fp.close();  
        }  
    }

    // Supervision 
    if (mode == "supervision") {
        nh.getParam("supervision_type", supervision_type);
        nh.getParam("AS_trigger_mode", AS_trigger_mode);
        nh.getParam("AS_design_mode", AS_design_mode);
        nh.getParam("timing_interval", timing_interval);
        nh.getParam("rnd_seed", rnd_seed);

        nh.getParam("sliding_window_size", sliding_window_size);
        nh.getParam("error_threshold", error_threshold_str);

        std::cout << "[setUp] supervision_type=" << supervision_type << std::endl;
        std::cout << "[setUp] AS_trigger_mode=" << AS_trigger_mode << " AS_design_mode=" << AS_design_mode << std::endl;
        std::cout << "[setUp] timing_interval=" << timing_interval << " rnd_seed=" << rnd_seed << std::endl;
        std::cout << "[setUp] sliding_window_size=" << sliding_window_size << " error_threshold_str=" << error_threshold_str << std::endl;

        // Initializes python interpreter
        Py_Initialize();

        // Import python script and construct the instance
        PyRun_SimpleString("import sys");
        PyRun_SimpleString("sys.path.append('/home/tong/activebsn/src/sa-bsn/system_manager/enactor/detector_repository')");

        if (supervision_type == "SWDetectorPlus") {
            stable_loop = 28;
            recoveryAS["/g3t1_1"] = recoveryAS["/g3t1_2"] = recoveryAS["/g3t1_3"] = recoveryAS["/g3t1_4"] = recoveryAS["/g3t1_5"] = recoveryAS["/g3t1_6"] = 0;
            timer["/g3t1_1"] = timer["/g3t1_2"] = timer["/g3t1_3"] = timer["/g3t1_4"] = timer["/g3t1_5"] = timer["/g3t1_6"] = stable_loop;

            // Tracing
            if (data_tracing == 1) {
                g3t1_detector_filepath = trace_dir + "/g3t1_detector_trace.txt";
                fp.open(g3t1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
                fp << "time_second,timestamp(ms),component,freq,cost,B_k_prior,P_k_prior,avgErrorDist,alarm,activeFlag,optAS\n";
                fp.close();

                g3t1_1_detector_filepath = trace_dir + "/g3t1_1_detector_trace.txt";
                g3t1_2_detector_filepath = trace_dir + "/g3t1_2_detector_trace.txt";
                g3t1_3_detector_filepath = trace_dir + "/g3t1_3_detector_trace.txt";
                g3t1_4_detector_filepath = trace_dir + "/g3t1_4_detector_trace.txt";
                g3t1_5_detector_filepath = trace_dir + "/g3t1_5_detector_trace.txt";
                g3t1_6_detector_filepath = trace_dir + "/g3t1_6_detector_trace.txt";

                for(int index=0; index<6; index++) {
                    if (index == 0) {fp.open(g3t1_1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 1) {fp.open(g3t1_2_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 2) {fp.open(g3t1_3_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 3) {fp.open(g3t1_4_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 4) {fp.open(g3t1_5_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 5) {fp.open(g3t1_6_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}

                    fp << "time_second,timestamp(ms),component,freq,cost,B_k_prior,P_k_prior,avgErrorDist,alarm,activeFlag,optAS\n";
                    fp.close();
                }
            }

            PyObject *pModule = PyImport_ImportModule("SWDetectorPlus");
            if (pModule == nullptr){
                std::cout <<"[Error] Import module error" << std::endl;
            }

            PyObject *pClass = PyObject_GetAttrString(pModule, "SWDetector_Plus");
            if (pClass == nullptr){
                std::cout << "[Error] Import class error" << std::endl;
            }

            PyObject *initArgs = Py_BuildValue("(i)", logging);
            pInstance = PyObject_Call(pClass, initArgs, nullptr);
            if (pInstance == nullptr){
                std::cout << "[Error] Initialize instance error" << std::endl;
            }

            PyObject *args1 = Py_BuildValue("(i)", sliding_window_size);
            PyObject *pRet1 = PyObject_CallMethod(pInstance, "set_sliding_window_size", "O", args1);
            if (pRet1 == nullptr){
                std::cout << "[Error] No pRet returned" << std::endl;
            }

            PyObject *args2 = Py_BuildValue("(s)", error_threshold_str.c_str());
            PyObject *pRet2 = PyObject_CallMethod(pInstance, "set_error_threshold", "O", args2);
            if (pRet2 == nullptr){
                std::cout << "[Error] No pRet returned" << std::endl;
            }

        } else if (supervision_type == "ARMAPlus") {
            stable_loop = 1;
            recoveryAS["/g3t1_1"] = recoveryAS["/g3t1_2"] = recoveryAS["/g3t1_3"] = recoveryAS["/g3t1_4"] = recoveryAS["/g3t1_5"] = recoveryAS["/g3t1_6"] = 0;
            timer["/g3t1_1"] = timer["/g3t1_2"] = timer["/g3t1_3"] = timer["/g3t1_4"] = timer["/g3t1_5"] = timer["/g3t1_6"] = stable_loop;

            // Tracing
            if (data_tracing == 1) {
                g3t1_detector_filepath = trace_dir + "/g3t1_detector_trace.txt";
                fp.open(g3t1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
                fp << "time_second,timestamp(ms),component,freq,cost,B_k_prior,P_k_prior,predictionError,alarm,activeFlag,optAS\n";
                fp.close();

                g3t1_1_detector_filepath = trace_dir + "/g3t1_1_detector_trace.txt";
                g3t1_2_detector_filepath = trace_dir + "/g3t1_2_detector_trace.txt";
                g3t1_3_detector_filepath = trace_dir + "/g3t1_3_detector_trace.txt";
                g3t1_4_detector_filepath = trace_dir + "/g3t1_4_detector_trace.txt";
                g3t1_5_detector_filepath = trace_dir + "/g3t1_5_detector_trace.txt";
                g3t1_6_detector_filepath = trace_dir + "/g3t1_6_detector_trace.txt";

                for(int index=0; index<6; index++) {
                    if (index == 0) {fp.open(g3t1_1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 1) {fp.open(g3t1_2_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 2) {fp.open(g3t1_3_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 3) {fp.open(g3t1_4_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 4) {fp.open(g3t1_5_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 5) {fp.open(g3t1_6_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}

                    fp << "time_second,timestamp(ms),component,freq,cost,B_k_prior,P_k_prior,predictionError,alarm,activeFlag,optAS\n";
                    fp.close();
                }
            }

            PyObject *pModule = PyImport_ImportModule("ARMAPlus");
            if (pModule == nullptr){
                std::cout << "[Error] Import module error" << std::endl;
            } 

            PyObject *pClass = PyObject_GetAttrString(pModule, "ARMA_Plus");
            if (pClass == nullptr){
                std::cout << "[Error] Import class error" << std::endl;
            } 

            PyObject *initArgs = Py_BuildValue("(i)", logging);
            pInstance = PyObject_Call(pClass, initArgs, nullptr);
            if (pInstance == nullptr){
                std::cout << "[Error] Initialize instance error" << std::endl;
            } 

            PyObject *args = Py_BuildValue("(i)", sliding_window_size);
            PyObject *pRet = PyObject_CallMethod(pInstance, "set_sliding_window_size", "O", args);
            if (pRet == nullptr){
                std::cout << "[Error] No pRet returned" << std::endl;
            } 

        } else if (supervision_type == "MoD2Plus") {
            stable_loop = 1;
            recoveryAS["/g3t1_1"] = recoveryAS["/g3t1_2"] = recoveryAS["/g3t1_3"] = recoveryAS["/g3t1_4"] = recoveryAS["/g3t1_5"] = recoveryAS["/g3t1_6"] = 0;
            timer["/g3t1_1"] = timer["/g3t1_2"] = timer["/g3t1_3"] = timer["/g3t1_4"] = timer["/g3t1_5"] = timer["/g3t1_6"] = stable_loop;

            // Tracing
            if (data_tracing == 1) {
                g3t1_detector_filepath = trace_dir + "/g3t1_detector_trace.txt";
                fp.open(g3t1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
                fp << "time_second,timestamp(ms),component,freq,cost,B_k_posterior,P_k_posterior,B_k_predict,P_k_predict,alarm,activeFlag,optAS\n";
                fp.close();

                g3t1_1_detector_filepath = trace_dir + "/g3t1_1_detector_trace.txt";
                g3t1_2_detector_filepath = trace_dir + "/g3t1_2_detector_trace.txt";
                g3t1_3_detector_filepath = trace_dir + "/g3t1_3_detector_trace.txt";
                g3t1_4_detector_filepath = trace_dir + "/g3t1_4_detector_trace.txt";
                g3t1_5_detector_filepath = trace_dir + "/g3t1_5_detector_trace.txt";
                g3t1_6_detector_filepath = trace_dir + "/g3t1_6_detector_trace.txt";

                for(int index=0; index<6; index++) {
                    if (index == 0) {fp.open(g3t1_1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 1) {fp.open(g3t1_2_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 2) {fp.open(g3t1_3_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 3) {fp.open(g3t1_4_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 4) {fp.open(g3t1_5_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}
                    else if (index == 5) {fp.open(g3t1_6_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);}

                    fp << "time_second,timestamp(ms),component,freq,cost,B_k_posterior,P_k_posterior,B_k_predict,P_k_predict,alarm,activeFlag,optAS\n";
                    fp.close();
                }  
            }                                       

            PyObject *pModule = PyImport_ImportModule("MoD2Plus");
            if (pModule == nullptr){
                std::cout <<"[Error] Import module error" << std::endl;
            }

            PyObject *pClass = PyObject_GetAttrString(pModule, "MoD2_Plus");
            if (pClass == nullptr){
                std::cout << "[Error] Import class error" << std::endl;
            }

            PyObject *initArgs = Py_BuildValue("(iss)", logging, AS_trigger_mode.c_str(), AS_design_mode.c_str());
            pInstance = PyObject_Call(pClass, initArgs, nullptr);
            if (pInstance == nullptr){
                std::cout << "[Error] Initialize instance error" << std::endl;
            }

            // timing_trigger
            if (AS_trigger_mode == "timing_trigger") {             
                PyObject *args = Py_BuildValue("(i)", timing_interval);
                PyObject *pRet = PyObject_CallMethod(pInstance, "set_timing_interval", "O", args);
                if (pRet == nullptr){
                    std::cout << "[Error] No pRet returned" << std::endl;
                }
            }

            // random_design
            if (AS_design_mode == "random_design") {
                PyObject *args = Py_BuildValue("(i)", rnd_seed);
                PyObject *pRet = PyObject_CallMethod(pInstance, "set_rnd_seed", "O", args);
                if (pRet == nullptr){
                    std::cout << "[Error] No pRet returned" << std::endl;
                }
            }
        } 

        // // test
        // std::string sup_components[6] = {"/g3t1_1","/g3t1_2","/g3t1_3","/g3t1_4","/g3t1_5","/g3t1_6"};
        // int sup_freqs[6] = {1, 1, 1, 1, 1, 1};
		// double sup_relis[6] = {0.7, 0.7, 0.7, 0.7, 0.7, 0.7};
        // for (int i=0; i<100; i++) {
        //     for (int index=0; index<6; index++) {
        //         apply_reli_strategy(sup_components[index]);
        //     }
        //     deviationDetector(sup_components, sup_freqs, sup_relis);
        //     if (i > 10) {
        //         activeFlag[i%6] == 1;
        //     }
        // }
    }

}

void Controller::receiveEvent(const archlib::Event::ConstPtr& msg) {
    timestamp = msg->timestamp;
    
    if (msg->content=="activate") {
        invocations[msg->source] = {};
        if(adaptation_parameter == "cost") {
            curr_value[msg->source] = setpoint;
            ref_value[msg->source] = setpoint;
        }
        
        replicate_task[msg->source] = 1;
        freq_double[msg->source] = msg->freq;
        freq[msg->source] = msg->freq;
        exception_buffer[msg->source] = 0;

    } else if (msg->content=="deactivate") {
        invocations.erase(msg->source);
        if(adaptation_parameter == "cost") {
            curr_value.erase(msg->source);
            ref_value.erase(msg->source);
        }

        kp.erase(msg->source);
        replicate_task.erase(msg->source);
        freq.erase(msg->source);
        exception_buffer.erase(msg->source);
    }
}

void Controller::apply_cost_strategy(const std::string &component) {
    double error = ref_value[component] - curr_value[component]; 
    std::cout << "t=" << timestamp << " [apply_cost_strategy] error[" << component << "]=" << error << std::endl;

    //double new_freq = freq[component] + ((error>0) ? (-kp[component]*error) : (kp[component]*error));
    double delta_freq_double = kp[component] * error;
    double saturated_delta_freq_double = std::min(std::max(delta_freq_double, -(double)max_delta_freq), (double)max_delta_freq);

    double new_freq_double = freq[component] + saturated_delta_freq_double;
    double saturated_new_freq_double = std::min(std::max(new_freq_double, (double)min_freq), (double)max_freq);

    freq_double[component] = saturated_new_freq_double;

    //int new_freq = freq[component] + ((error>0) ? (-round(kp[component]*error)) : (round(kp[component]*error)));
    int delta_freq_int = round(kp[component] * error);
    int saturated_delta_freq_int = std::min(std::max(delta_freq_int, -max_delta_freq), max_delta_freq);

    int new_freq_int = freq[component] + saturated_delta_freq_int;
    int saturated_new_freq_int = std::min(std::max(new_freq_int, min_freq), max_freq);

    freq[component] = saturated_new_freq_int;

    std::cout << "t=" << timestamp << " [apply_cost_strategy] component=" << component << " freq_double=" << freq_double[component] << " freq=" << freq[component] << std::endl;

    // Active part
    if (mode == "supervision") {
        // Auxiliary signal
        std::cout << "t=" << timestamp << " [apply_cost_strategy] component=" << component << " activeFlag=" << activeFlag[component] << " optAS=" << optAS[component] << " timer=" << timer[component] << std::endl;
        if (activeFlag[component] > 0 && abs(optAS[component]) > 0 && timer[component] == stable_loop) {  
            freq[component] = std::min(std::max(freq[component] + optAS[component], min_freq), max_freq);
            std::cout << "t=" << timestamp << " [apply_cost_strategy] component=" << component 
                                           << " activeFlag=" << activeFlag[component] << " optAS=" << optAS[component] << " freq=" << freq[component] << std::endl;

            // Reset
            recoveryAS[component] = 0 - optAS[component];
            activeFlag[component] = 0;
            optAS[component] = 0;
        }
        
        // Recovery
        if (abs(recoveryAS[component]) > 0) {

            if (timer[component] == 0) {
                freq[component] = std::min(std::max(freq[component] + recoveryAS[component], min_freq), max_freq);
                std::cout << "t=" << timestamp << " [apply_reli_strategy] component=" << component 
                                            << " recoveryAS=" << recoveryAS[component] << " freq=" << freq[component] << std::endl;

                // Reset
                recoveryAS[component] = 0;
                timer[component] = stable_loop;

            } else {
                // Timer
                timer[component] -= 1;
            }
        }
    }

    // Model deviation injection
    if (deviation_trigger == 1 && timestamp >= deviation_time && injection_flag[component] == 0) {
        deviation_freq[component] = freq[component];
        injection_flag[component] = 1;           
    }

    if (deviation_trigger == 1 && timestamp >= deviation_time && injection_flag[component] == 1) {
        archlib::AdaptationCommand msg;
        msg.source = ros::this_node::getName();
        msg.target = component;
        msg.timestamp = timestamp;
        msg.action = "freq=" + std::to_string(deviation_freq[component]);
        adapt.publish(msg);

    } else if (deviation_trigger == 0 || timestamp < deviation_time) {
        archlib::AdaptationCommand msg;
        msg.source = ros::this_node::getName();
        msg.target = component;
        msg.timestamp = timestamp;
        msg.action = "freq=" + std::to_string(freq[component]);
        adapt.publish(msg);
    }

    // Exceed stability_margin
    if(error > stability_margin*ref_value[component] || error < -stability_margin*ref_value[component]) {
        exception_buffer[component] = (exception_buffer[component] < 0) ? 0 : exception_buffer[component] + 1;
    } else {
        exception_buffer[component] = (exception_buffer[component] > 0) ? 0 : exception_buffer[component] - 1;
    }

    // Send exception to "/engine"
    if(exception_buffer[component]>4){
        archlib::Exception msg;
        msg.source = ros::this_node::getName();
        msg.target = "/engine";
        msg.timestamp = timestamp;
        msg.content = component+"=1";
        except.publish(msg);
        exception_buffer[component] = 0;

    } else if (exception_buffer[component]<-4) {
        archlib::Exception msg;
        msg.source = ros::this_node::getName();
        msg.target = "/engine";
        msg.timestamp = timestamp;
        msg.content = component+"=-1";
        except.publish(msg);
        exception_buffer[component] = 0;
    }
    
    invocations[component].clear();
}