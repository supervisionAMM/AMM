#include "enactor/Enactor.hpp"

#define W(x) std::cerr << #x << " = " << x << std::endl;

Enactor::Enactor(int &argc, char **argv, std::string name) : ROSComponent(argc, argv, name), cycles(0), stability_margin(0.02) {}

Enactor::~Enactor() {}

int Enactor::nowInMilliSecond() const{
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
}

void Enactor::tearDown() {}

void Enactor::receiveAdaptationParameter() {
    ros::NodeHandle client_handler;
    ros::ServiceClient client_module;

    client_module = client_handler.serviceClient<archlib::EngineRequest>("EngineRequest");
    archlib::EngineRequest adapt_srv;
    
    if(!client_module.call(adapt_srv)) {
        ROS_ERROR("Failed to connect to Strategy Manager node.");
        return;
    }

    adaptation_parameter = adapt_srv.response.content;
    std::cout << "enactor adaptation_parameter=" << adaptation_parameter << std::endl;

    if(adaptation_parameter != "reliability" && adaptation_parameter != "cost") {
        ROS_ERROR("Invalid adaptation parameter received.");
        return;
    }
}

void Enactor::receiveStatus() {
    timestamp = this->nowInMilliSecond() - time_ref; 

    ros::NodeHandle client_handler;
    ros::ServiceClient client_module;

    client_module = client_handler.serviceClient<archlib::DataAccessRequest>("DataAccessRequest");
    archlib::DataAccessRequest r_srv;

    r_srv.request.timestamp = timestamp;
    r_srv.request.name = ros::this_node::getName();
    if (adaptation_parameter == "reliability") {
        r_srv.request.query = "all:reliability:" + std::to_string(time_window);
    } else if(adaptation_parameter == "cost") {
        r_srv.request.query = "all:cost:" + std::to_string(time_window);
    }

    if (!client_module.call(r_srv)) {
        ROS_ERROR("Failed to connect to data access node.");
        return;
    }
    
    std::string ans = r_srv.response.content;
    // std::cout << "received=> [" << ans << "]" << std::endl;
    if (ans == "") {
        ROS_ERROR("Received empty answer when asked for status.");
    } 

    // Get in form "/g3t1_1:0.90;/g3t1_2:0.90;..."
    std::vector<std::string> pairs = bsn::utils::split(ans, ';');

    // Observation: update cost - y(k)
    for (auto s : pairs) {
        std::vector<std::string> pair = bsn::utils::split(s, ':');
        std::string component = pair[0];
        std::string content = pair[1];
        curr_value[component] = stod(content);
    }

    // Default: no adaptation
    if (mode == "default" && timestamp >= warm_time) {
        // Observation: tracing - u(k-1), y(k)
        for (auto s : pairs) {
            std::vector<std::string> pair = bsn::utils::split(s, ':');
            std::string component = pair[0];

            if (data_tracing == 1 && component != "/g4t1") {
                Observation obj("Observation", timestamp, component, freq_double[component], freq[component], curr_value[component]);
                g3t1_vec.push_back(obj); 

                std::cout << "t=" << timestamp << " [default] component=" << component << " freq=" << freq[component] << " cost=" << curr_value[component] << std::endl;
            }
        }

        if (data_tracing == 1) {flush();}        
    }

    // Identifications
    if (mode == "identification" && sampling_cnt < sampling_num && timestamp >= warm_time) {
        // Observation: tracing - u(k-1), y(k)
        for (auto s : pairs) {
            std::vector<std::string> pair = bsn::utils::split(s, ':');
            std::string component = pair[0];

            if (data_tracing == 1 && component != "/g4t1") {
                Observation obj("Observation", timestamp, component, freq_double[component], freq[component], curr_value[component]);
                g3t1_vec.push_back(obj); 

                std::cout << "t=" << timestamp << " [identification] component=" << component << " freq_double=" << freq_double[component] << " freq=" << freq[component] << " cost=" << curr_value[component] << std::endl;
            }
        }

        if (data_tracing == 1) {flush();}

        // Read samping date and set freqs
        for (auto s : pairs) {
            std::vector<std::string> pair = bsn::utils::split(s, ':');
            std::string component = pair[0];

            if (component != "/g4t1" && sampling_cnt < sampling_num) {
                if (component == "/g3t1_1") {temp_ident_freqs = ident_g3t1_1_freqs; }
                if (component == "/g3t1_2") {temp_ident_freqs = ident_g3t1_2_freqs; }
                if (component == "/g3t1_3") {temp_ident_freqs = ident_g3t1_3_freqs; }
                if (component == "/g3t1_4") {temp_ident_freqs = ident_g3t1_4_freqs; }
                if (component == "/g3t1_5") {temp_ident_freqs = ident_g3t1_5_freqs; }
                if (component == "/g3t1_6") {temp_ident_freqs = ident_g3t1_6_freqs; }

                int new_freq = temp_ident_freqs.at(sampling_cnt);
                freq_double[component] = (double)new_freq;

                freq[component] = new_freq;
                archlib::AdaptationCommand msg;
                msg.source = ros::this_node::getName();
                msg.target = component;
                msg.timestamp = timestamp;
                msg.action = "freq=" + std::to_string(freq[component]);
                adapt.publish(msg);                  
                
                std::cout << "t=" << timestamp << " [identification] sampling_cnt=" << sampling_cnt << " component=" << component << " freq="<< freq[component] << std::endl;
            }
        }
        
        // Counting
        sampling_cnt = sampling_cnt + 1;
    }
    
    if ((mode == "control" || mode == "supervision") && timestamp >= warm_time) {
        // Observation: tracing - u(k-1), y(k)
        for (auto s : pairs) {
            std::vector<std::string> pair = bsn::utils::split(s, ':');
            std::string component = pair[0];

            if (component != "/g4t1") {
                if (data_tracing == 1) {
                    Observation obj("Observation", timestamp, component, freq_double[component], freq[component], curr_value[component]);
                    g3t1_vec.push_back(obj); 
                }

                std::cout << "t=" << timestamp << " [tracing] component=" << component << " freq_double=" << freq_double[component] << " freq=" << freq[component] << " cost=" << curr_value[component] << std::endl;
                
                if (mode == "supervision") {
                    if (component == "/g3t1_1") {sup_components[0] = component; sup_freqs[0] = freq[component]; sup_costs[0] = curr_value[component];}
                    if (component == "/g3t1_2") {sup_components[1] = component; sup_freqs[1] = freq[component]; sup_costs[1] = curr_value[component];}
                    if (component == "/g3t1_3") {sup_components[2] = component; sup_freqs[2] = freq[component]; sup_costs[2] = curr_value[component];}
                    if (component == "/g3t1_4") {sup_components[3] = component; sup_freqs[3] = freq[component]; sup_costs[3] = curr_value[component];}
                    if (component == "/g3t1_5") {sup_components[4] = component; sup_freqs[4] = freq[component]; sup_costs[4] = curr_value[component];}
                    if (component == "/g3t1_6") {sup_components[5] = component; sup_freqs[5] = freq[component]; sup_costs[5] = curr_value[component];}               
                }
            }
        }

        if (data_tracing == 1) {flush();}
    
        // Supervision
        if (mode == "supervision") {
            deviationDetector(sup_components, sup_freqs, sup_costs);  
        }

        // Adaptation: update freq - u(k)
        for (auto s : pairs) {
            std::vector<std::string> pair = bsn::utils::split(s, ':');
            std::string component = pair[0];
            
            if(adaptation_parameter == "cost" && component != "/g4t1") {
                // Do not treat g4t1 as sensor
                apply_cost_strategy(component);
            }
        }
    }
}

void Enactor::receiveStrategy(const archlib::Strategy::ConstPtr& msg) {    
    // Receive setpoint from engine or use static setpoint
    timestamp = msg->timestamp;

    std::vector<std::string> refs = bsn::utils::split(msg->content, ';');

    for(std::vector<std::string>::iterator ref = refs.begin(); ref != refs.end(); ref++){
        std::vector<std::string> pair = bsn::utils::split(*ref, ':'); 
        if(adaptation_parameter == "cost") {
            // ref_value[pair[0]] = stod(pair[1]);
            ref_value[pair[0]] = setpoint; // set static references
        }
    }
}

void Enactor::body(){
    ros::NodeHandle n;

    ros::Subscriber subs_event = n.subscribe("event", 1000, &Enactor::receiveEvent, this);
    ros::Subscriber subs_strategy = n.subscribe("strategy", 1000, &Enactor::receiveStrategy, this);

    ros::Rate loop_rate(rosComponentDescriptor.getFreq());
    while(ros::ok()){
        if(cycles <= 60*rosComponentDescriptor.getFreq()) ++cycles;
        receiveStatus();
        ros::spinOnce();
        loop_rate.sleep();
    }
}

/* identification */ 
void Enactor::loadSamplingFreqs() {
    std::string sampling_file_path = ros::package::getPath("enactor") + "/identification/sampling_freqs.txt";

    std::ifstream fin(sampling_file_path);
    if (!fin) {
        ROS_ERROR("Controller could not read sampling frequnecy file.");

    } else {
        std::string freq_str;
        while (fin >> freq_str) {
            std::vector<std::string> freq_vec = bsn::utils::split(freq_str, ',');
            std::cout << "t=" << timestamp << " [identification] freq_vec=[" << freq_vec[0] << "," << freq_vec[1] << "," << freq_vec[2] << "," << freq_vec[3] << "," << freq_vec[4] << "," << freq_vec[5] << "]" << std::endl;

            if (freq_vec.size() == 6) {
                ident_g3t1_1_freqs.push_back(std::stoi(freq_vec[0]));
                ident_g3t1_2_freqs.push_back(std::stoi(freq_vec[1]));
                ident_g3t1_3_freqs.push_back(std::stoi(freq_vec[2]));
                ident_g3t1_4_freqs.push_back(std::stoi(freq_vec[3]));
                ident_g3t1_5_freqs.push_back(std::stoi(freq_vec[4]));
                ident_g3t1_6_freqs.push_back(std::stoi(freq_vec[5]));
            } else {
                ROS_ERROR("Sampling frequency content error.");
            }
        }

        fin.close();
        ROS_INFO("Load sampling frequnecy file successfully.");
    }
}

/* tracing */ 
void Enactor::flush(){
    fp.open(g3t1_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
    for(std::vector<Observation>::iterator it = g3t1_vec.begin(); it != g3t1_vec.end(); ++it) {
        fp << floor((*it).getTimestamp()/1000.0) << ",";
        fp << (*it).getTimestamp() << ",";
        fp << (*it).getComponent() << ",";
        fp << (*it).getFreqDouble() << ",";
        fp << (*it).getFreq() << ",";
        fp << (*it).getCost() << "\n";
    }
    fp.close();

    for(std::vector<Observation>::iterator it = g3t1_vec.begin(); it != g3t1_vec.end(); ++it) {
        if ((*it).getComponent()=="/g3t1_1") {fp.open(g3t1_1_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getComponent()=="/g3t1_2") {fp.open(g3t1_2_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getComponent()=="/g3t1_3") {fp.open(g3t1_3_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getComponent()=="/g3t1_4") {fp.open(g3t1_4_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getComponent()=="/g3t1_5") {fp.open(g3t1_5_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getComponent()=="/g3t1_6") {fp.open(g3t1_6_plant_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}                        

        fp << floor((*it).getTimestamp()/1000.0) << ",";
        fp << (*it).getTimestamp() << ",";
        fp << (*it).getComponent() << ",";
        fp << (*it).getFreq() << ",";
        fp << (*it).getCost() << "\n";
        fp.close();                       
    }
    g3t1_vec.clear();
}

/* supervision */ 
void Enactor::deviationDetector(std::string sup_components[], int sup_freqs[], double sup_costs[]) {
    // transfer with strings
    std::string U_str = std::to_string(sup_freqs[0]) + "," + std::to_string(sup_freqs[1]) + "," + std::to_string(sup_freqs[2]) + "," + 
                        std::to_string(sup_freqs[3]) + "," + std::to_string(sup_freqs[4]) + "," + std::to_string(sup_freqs[5]);

    std::string Y_str = std::to_string(sup_costs[0]) + "," + std::to_string(sup_costs[1]) + "," + std::to_string(sup_costs[2]) + "," + 
                        std::to_string(sup_costs[3]) + "," + std::to_string(sup_costs[4]) + "," + std::to_string(sup_costs[5]);             

    std::cout << "t=" << timestamp << " [Detector] U_str=" << U_str << " Y_str=" << Y_str << std::endl;         
    
    if (supervision_type == "SWDetectorPlus") {
        PyObject *mainArgs = Py_BuildValue("(ss)", U_str.c_str(), Y_str.c_str());
        PyObject *mainPRet = PyObject_CallMethod(pInstance, "deviation_detector", "O", mainArgs);
        if (mainPRet == nullptr){
            std::cout << "[Error] No pRet returned" << std::endl;
            
        } else {
            //returned alarm signal
            const char *B_k_prior_str, *P_k_prior_str, *avgErrorDist_str, *alarm_str, *activeFlag_str, *optAS_str;

            PyArg_ParseTuple(mainPRet, "s|s|s|s|s|s", &B_k_prior_str, &P_k_prior_str, &avgErrorDist_str, &alarm_str, &activeFlag_str, &optAS_str);
            std::cout << "t=" << timestamp << " [Detector] supervision_type=" << supervision_type
                                                             << " B_k_prior=" << B_k_prior_str
                                                             << " P_k_prior=" << P_k_prior_str
                                                          << " avgErrorDist=" << avgErrorDist_str << std::endl; 
            std::cout << "t=" << timestamp << " [Detector] alarm=" << alarm_str << " activeFlag=" << activeFlag_str << " optAS=" << optAS_str << std::endl;   

            // tracing
            if (data_tracing == 1) {
                std::vector<std::string> B_k_prior = bsn::utils::split(B_k_prior_str, ',');
                std::vector<std::string> P_k_prior = bsn::utils::split(P_k_prior_str, ',');
                std::vector<std::string> avgErrorDist = bsn::utils::split(avgErrorDist_str, ',');

                std::string temp1 = alarm_str;
                std::vector<std::string> s1 = bsn::utils::split(temp1, ',');
                for(int i=0; i<s1.size(); i++) {alarm[i] = atoi(s1[i].c_str());}

                std::string temp2 = activeFlag_str;
                std::vector<std::string> s2 = bsn::utils::split(temp2, ',');
                activeFlag["/g3t1_1"] = atoi(s2[0].c_str());
                activeFlag["/g3t1_2"] = atoi(s2[1].c_str());
                activeFlag["/g3t1_3"] = atoi(s2[2].c_str());
                activeFlag["/g3t1_4"] = atoi(s2[3].c_str());
                activeFlag["/g3t1_5"] = atoi(s2[4].c_str());
                activeFlag["/g3t1_6"] = atoi(s2[5].c_str());

                std::string temp3 = optAS_str;
                std::vector<std::string> s3 = bsn::utils::split(temp3, ',');
                optAS["/g3t1_1"] = atoi(s3[0].c_str());
                optAS["/g3t1_2"] = atoi(s3[1].c_str());
                optAS["/g3t1_3"] = atoi(s3[2].c_str());
                optAS["/g3t1_4"] = atoi(s3[3].c_str());
                optAS["/g3t1_5"] = atoi(s3[4].c_str());
                optAS["/g3t1_6"] = atoi(s3[5].c_str());
                
                fp.open(g3t1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
                for(int index=0; index<6; index++) {
                    fp << floor(timestamp/1000.0) << ",";
                    fp << timestamp << ",";
                    fp << sup_components[index] << ",";
                    fp << sup_freqs[index] << ",";
                    fp << sup_costs[index] << ",";
                    fp << B_k_prior[index] << ",";
                    fp << P_k_prior[index] << ",";
                    fp << avgErrorDist[index] << ",";         
                    fp << alarm[index] << ",";

                    if (index == 0) {
                        fp << activeFlag["/g3t1_1"] << ",";            
                        fp << optAS["/g3t1_1"] << "\n";         
                    } else if (index == 1) {
                        fp << activeFlag["/g3t1_2"] << ",";            
                        fp << optAS["/g3t1_2"] << "\n";         
                    } else if (index == 2) {
                        fp << activeFlag["/g3t1_3"] << ",";            
                        fp << optAS["/g3t1_3"] << "\n";         
                    } else if (index == 3) {
                        fp << activeFlag["/g3t1_4"] << ",";            
                        fp << optAS["/g3t1_4"] << "\n";         
                    } else if (index == 4) {
                        fp << activeFlag["/g3t1_5"] << ",";            
                        fp << optAS["/g3t1_5"] << "\n";         
                    } else if (index == 5) {
                        fp << activeFlag["/g3t1_6"] << ",";            
                        fp << optAS["/g3t1_6"] << "\n";         
                    }                                                                                                    
                }
                fp.close();

                for(int index=0; index<6; index++) {
                    if (index == 0) {fp.open(g3t1_1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 1) {fp.open(g3t1_2_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 2) {fp.open(g3t1_3_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 3) {fp.open(g3t1_4_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 4) {fp.open(g3t1_5_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 5) {fp.open(g3t1_6_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
 
                    fp << floor(timestamp/1000.0) << ",";
                    fp << timestamp << ",";
                    fp << sup_components[index] << ",";
                    fp << sup_freqs[index] << ",";
                    fp << sup_costs[index] << ",";
                    fp << B_k_prior[index] << ",";
                    fp << P_k_prior[index] << ",";
                    fp << avgErrorDist[index] << ",";         
                    fp << alarm[index] << ",";

                    if (index == 0) {
                        fp << activeFlag["/g3t1_1"] << ",";            
                        fp << optAS["/g3t1_1"] << "\n";         
                    } else if (index == 1) {
                        fp << activeFlag["/g3t1_2"] << ",";            
                        fp << optAS["/g3t1_2"] << "\n";         
                    } else if (index == 2) {
                        fp << activeFlag["/g3t1_3"] << ",";            
                        fp << optAS["/g3t1_3"] << "\n";         
                    } else if (index == 3) {
                        fp << activeFlag["/g3t1_4"] << ",";            
                        fp << optAS["/g3t1_4"] << "\n";         
                    } else if (index == 4) {
                        fp << activeFlag["/g3t1_5"] << ",";            
                        fp << optAS["/g3t1_5"] << "\n";         
                    } else if (index == 5) {
                        fp << activeFlag["/g3t1_6"] << ",";            
                        fp << optAS["/g3t1_6"] << "\n";         
                    }   
                    fp.close();         
                }
            }         
        }

    } else if (supervision_type == "ARMAPlus") {
        PyObject *mainArgs = Py_BuildValue("(ss)", U_str.c_str(), Y_str.c_str());
        PyObject *mainPRet = PyObject_CallMethod(pInstance, "deviation_detector", "O", mainArgs);
        if (mainPRet == nullptr){
            std::cout << "[Error] No pRet returned" << std::endl;

        } else {
            //returned alarm signal
            const char *B_k_prior_str, *P_k_prior_str, *predictionError_str, *alarm_str, *activeFlag_str, *optAS_str;

            PyArg_ParseTuple(mainPRet, "s|s|s|s|s|s", &B_k_prior_str, &P_k_prior_str, &predictionError_str, &alarm_str, &activeFlag_str, &optAS_str);

            std::cout << "t=" << timestamp << " [Detector] supervision_type=" << supervision_type
                                                             << " B_k_prior=" << B_k_prior_str
                                                             << " P_k_prior=" << P_k_prior_str
                                                       << " predictionError=" << predictionError_str << std::endl;   
            std::cout << "t=" << timestamp << " [Detector] alarm=" << alarm_str << " activeFlag=" << activeFlag_str << " optAS=" << optAS_str << std::endl;   

            // tracing
            if (data_tracing == 1) {
                std::vector<std::string> B_k_prior = bsn::utils::split(B_k_prior_str, ',');
                std::vector<std::string> P_k_prior = bsn::utils::split(P_k_prior_str, ',');
                std::vector<std::string> predictionError = bsn::utils::split(predictionError_str, ',');

                std::string temp1 = alarm_str;
                std::vector<std::string> s1 = bsn::utils::split(temp1, ',');
                for(int i=0; i<s1.size(); i++) {alarm[i] = atoi(s1[i].c_str());}

                std::string temp2 = activeFlag_str;
                std::vector<std::string> s2 = bsn::utils::split(temp2, ',');
                activeFlag["/g3t1_1"] = atoi(s2[0].c_str());
                activeFlag["/g3t1_2"] = atoi(s2[1].c_str());
                activeFlag["/g3t1_3"] = atoi(s2[2].c_str());
                activeFlag["/g3t1_4"] = atoi(s2[3].c_str());
                activeFlag["/g3t1_5"] = atoi(s2[4].c_str());
                activeFlag["/g3t1_6"] = atoi(s2[5].c_str());

                std::string temp3 = optAS_str;
                std::vector<std::string> s3 = bsn::utils::split(temp3, ',');
                optAS["/g3t1_1"] = atoi(s3[0].c_str());
                optAS["/g3t1_2"] = atoi(s3[1].c_str());
                optAS["/g3t1_3"] = atoi(s3[2].c_str());
                optAS["/g3t1_4"] = atoi(s3[3].c_str());
                optAS["/g3t1_5"] = atoi(s3[4].c_str());
                optAS["/g3t1_6"] = atoi(s3[5].c_str());

                fp.open(g3t1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
                for(int index=0; index<6; index++) {
                    fp << floor(timestamp/1000.0) << ",";
                    fp << timestamp << ",";
                    fp << sup_components[index] << ",";
                    fp << sup_freqs[index] << ",";
                    fp << sup_costs[index] << ",";
                    fp << B_k_prior[index] << ",";
                    fp << P_k_prior[index] << ",";
                    fp << predictionError[index] << ",";            
                    fp << alarm[index] << ",";

                    if (index == 0) {
                        fp << activeFlag["/g3t1_1"] << ",";            
                        fp << optAS["/g3t1_1"] << "\n";         
                    } else if (index == 1) {
                        fp << activeFlag["/g3t1_2"] << ",";            
                        fp << optAS["/g3t1_2"] << "\n";         
                    } else if (index == 2) {
                        fp << activeFlag["/g3t1_3"] << ",";            
                        fp << optAS["/g3t1_3"] << "\n";         
                    } else if (index == 3) {
                        fp << activeFlag["/g3t1_4"] << ",";            
                        fp << optAS["/g3t1_4"] << "\n";         
                    } else if (index == 4) {
                        fp << activeFlag["/g3t1_5"] << ",";            
                        fp << optAS["/g3t1_5"] << "\n";         
                    } else if (index == 5) {
                        fp << activeFlag["/g3t1_6"] << ",";            
                        fp << optAS["/g3t1_6"] << "\n";         
                    }          
                }
                fp.close();

                for(int index=0; index<6; index++) {
                    if (index == 0) {fp.open(g3t1_1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 1) {fp.open(g3t1_2_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 2) {fp.open(g3t1_3_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 3) {fp.open(g3t1_4_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 4) {fp.open(g3t1_5_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 5) {fp.open(g3t1_6_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

                    fp << floor(timestamp/1000.0) << ",";
                    fp << timestamp << ",";
                    fp << sup_components[index] << ",";
                    fp << sup_freqs[index] << ",";
                    fp << sup_costs[index] << ",";
                    fp << B_k_prior[index] << ",";
                    fp << P_k_prior[index] << ",";
                    fp << predictionError[index] << ",";         
                    fp << alarm[index] << ",";

                    if (index == 0) {
                        fp << activeFlag["/g3t1_1"] << ",";            
                        fp << optAS["/g3t1_1"] << "\n";         
                    } else if (index == 1) {
                        fp << activeFlag["/g3t1_2"] << ",";            
                        fp << optAS["/g3t1_2"] << "\n";         
                    } else if (index == 2) {
                        fp << activeFlag["/g3t1_3"] << ",";            
                        fp << optAS["/g3t1_3"] << "\n";         
                    } else if (index == 3) {
                        fp << activeFlag["/g3t1_4"] << ",";            
                        fp << optAS["/g3t1_4"] << "\n";         
                    } else if (index == 4) {
                        fp << activeFlag["/g3t1_5"] << ",";            
                        fp << optAS["/g3t1_5"] << "\n";         
                    } else if (index == 5) {
                        fp << activeFlag["/g3t1_6"] << ",";            
                        fp << optAS["/g3t1_6"] << "\n";         
                    }   
                    fp.close();         
                }
            }
        }

    } else if (supervision_type == "MoD2Plus") {
        PyObject *mainArgs = Py_BuildValue("(ss)", U_str.c_str(), Y_str.c_str());
        PyObject *mainPRet = PyObject_CallMethod(pInstance, "deviation_detector", "O", mainArgs);
        if (mainPRet == nullptr){
            std::cout << "[Error] No pRet returned" << std::endl;

        } else {
            //returned alarm signal
            const char *B_k_posterior_str, *P_k_posterior_str, *B_k_predict_str, *P_k_predict_str, *alarm_str, *activeFlag_str, *optAS_str;

            PyArg_ParseTuple(mainPRet, "s|s|s|s|s|s|s", &B_k_posterior_str, &P_k_posterior_str, &B_k_predict_str, &P_k_predict_str, &alarm_str, &activeFlag_str, &optAS_str);

            std::cout << "t=" << timestamp << " [Detector] supervision_type=" << supervision_type
                                                         << " B_k_posterior=" << B_k_posterior_str
                                                         << " P_k_posterior=" << P_k_posterior_str
                                                           << " B_k_predict=" << B_k_predict_str
                                                           << " P_k_predict=" << P_k_predict_str << std::endl;   
            std::cout << "t=" << timestamp << " [Detector] alarm=" << alarm_str << " activeFlag=" << activeFlag_str << " optAS=" << optAS_str << std::endl;   

            // tracing
            if (data_tracing == 1) {
                std::vector<std::string> B_k_posterior = bsn::utils::split(B_k_posterior_str, ',');
                std::vector<std::string> P_k_posterior = bsn::utils::split(P_k_posterior_str, ',');
                std::vector<std::string> B_k_predict = bsn::utils::split(B_k_predict_str, ',');
                std::vector<std::string> P_k_predict = bsn::utils::split(P_k_predict_str, ',');

                std::string temp1 = alarm_str;
                std::vector<std::string> s1 = bsn::utils::split(temp1, ',');
                for(int i=0; i<s1.size(); i++) {alarm[i] = atoi(s1[i].c_str());}

                std::string temp2 = activeFlag_str;
                std::vector<std::string> s2 = bsn::utils::split(temp2, ',');
                activeFlag["/g3t1_1"] = atoi(s2[0].c_str());
                activeFlag["/g3t1_2"] = atoi(s2[1].c_str());
                activeFlag["/g3t1_3"] = atoi(s2[2].c_str());
                activeFlag["/g3t1_4"] = atoi(s2[3].c_str());
                activeFlag["/g3t1_5"] = atoi(s2[4].c_str());
                activeFlag["/g3t1_6"] = atoi(s2[5].c_str());

                std::string temp3 = optAS_str;
                std::vector<std::string> s3 = bsn::utils::split(temp3, ',');
                optAS["/g3t1_1"] = atoi(s3[0].c_str());
                optAS["/g3t1_2"] = atoi(s3[1].c_str());
                optAS["/g3t1_3"] = atoi(s3[2].c_str());
                optAS["/g3t1_4"] = atoi(s3[3].c_str());
                optAS["/g3t1_5"] = atoi(s3[4].c_str());
                optAS["/g3t1_6"] = atoi(s3[5].c_str());

                fp.open(g3t1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
                for(int index=0; index<6; index++) {
                    fp << floor(timestamp/1000.0) << ",";
                    fp << timestamp << ",";
                    fp << sup_components[index] << ",";
                    fp << sup_freqs[index] << ",";
                    fp << sup_costs[index] << ",";
                    fp << B_k_posterior[index] << ",";
                    fp << P_k_posterior[index] << ",";
                    fp << B_k_predict[index] << ",";
                    fp << P_k_predict[index] << ",";            
                    fp << alarm[index] << ",";

                    if (index == 0) {
                        fp << activeFlag["/g3t1_1"] << ",";            
                        fp << optAS["/g3t1_1"] << "\n";         
                    } else if (index == 1) {
                        fp << activeFlag["/g3t1_2"] << ",";            
                        fp << optAS["/g3t1_2"] << "\n";         
                    } else if (index == 2) {
                        fp << activeFlag["/g3t1_3"] << ",";            
                        fp << optAS["/g3t1_3"] << "\n";         
                    } else if (index == 3) {
                        fp << activeFlag["/g3t1_4"] << ",";            
                        fp << optAS["/g3t1_4"] << "\n";         
                    } else if (index == 4) {
                        fp << activeFlag["/g3t1_5"] << ",";            
                        fp << optAS["/g3t1_5"] << "\n";         
                    } else if (index == 5) {
                        fp << activeFlag["/g3t1_6"] << ",";            
                        fp << optAS["/g3t1_6"] << "\n";         
                    }          
                }
                fp.close();

                for(int index=0; index<6; index++) {
                    if (index == 0) {fp.open(g3t1_1_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 1) {fp.open(g3t1_2_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 2) {fp.open(g3t1_3_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 3) {fp.open(g3t1_4_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 4) {fp.open(g3t1_5_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                    else if (index == 5) {fp.open(g3t1_6_detector_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

                    fp << floor(timestamp/1000.0) << ",";
                    fp << timestamp << ",";
                    fp << sup_components[index] << ",";
                    fp << sup_freqs[index] << ",";
                    fp << sup_costs[index] << ",";
                    fp << B_k_posterior[index] << ",";
                    fp << P_k_posterior[index] << ",";
                    fp << B_k_predict[index] << ",";
                    fp << P_k_predict[index] << ",";            
                    fp << alarm[index] << ",";

                    if (index == 0) {
                        fp << activeFlag["/g3t1_1"] << ",";            
                        fp << optAS["/g3t1_1"] << "\n";         
                    } else if (index == 1) {
                        fp << activeFlag["/g3t1_2"] << ",";            
                        fp << optAS["/g3t1_2"] << "\n";         
                    } else if (index == 2) {
                        fp << activeFlag["/g3t1_3"] << ",";            
                        fp << optAS["/g3t1_3"] << "\n";         
                    } else if (index == 3) {
                        fp << activeFlag["/g3t1_4"] << ",";            
                        fp << optAS["/g3t1_4"] << "\n";         
                    } else if (index == 4) {
                        fp << activeFlag["/g3t1_5"] << ",";            
                        fp << optAS["/g3t1_5"] << "\n";         
                    } else if (index == 5) {
                        fp << activeFlag["/g3t1_6"] << ",";            
                        fp << optAS["/g3t1_6"] << "\n";         
                    }          
                    fp.close();         
                }           
            }
        }
    }
}