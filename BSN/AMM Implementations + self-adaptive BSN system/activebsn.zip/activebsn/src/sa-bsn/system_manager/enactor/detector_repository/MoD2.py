import numpy as np
from scipy import stats


def degradation_detector(index, delta):
    # error sigma
    var = np.array([[0.0585, 0.0, 0.0, 0.0, 0.0, 0.0],
                    [0.0, 0.0612, 0.0, 0.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0478, 0.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0, 0.0599, 0.0, 0.0],
                    [0.0, 0.0, 0.0, 0.0, 0.0547, 0.0],
                    [0.0, 0.0, 0.0, 0.0, 0.0, 0.0595]])

    # alarm if the derived probability that model parameter value
    # falls into safe region does not exceed the probability threshold
    prob_6sigma = 0.999999981  # 6sigma
    loc = 0.0
    scale = np.sqrt(var[index][index])

    if delta <= loc:
        cdf = stats.norm.cdf(delta, loc, scale)
    else:
        cdf = 1.0 - stats.norm.cdf(delta, loc, scale)

    alarm = 0
    if cdf < (1.0 - prob_6sigma) / 2:
        alarm = 1

    return alarm


class MoD2:
    # model-guided deviation detector (with original nominal model)

    def __init__(self, logging):

        self.logging = logging
        self.counting = 0

        # nominal model parameters
        # x(k) = A*x(k-1) + B*u(k-1)
        # y(k) = C*x(k)
        self.A = np.zeros((6, 6))

        self.B = np.array([[0.1502, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.1505, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.1506, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.1503, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.1503, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 0.1504]])

        self.C = 1.0 * np.eye(6)

        # deviated model parameter
        # using copy to avoid B_k_prior and B_k_posterior change together
        self.B_k_prior = np.copy(self.B)
        self.P_k_prior = 1.0e-05 * np.eye(6)  # estimate uncertainty
        self.B_k_posterior = np.copy(self.B)
        self.P_k_posterior = 1.0e-05 * np.eye(6)  # estimate uncertainty

        # system state
        self.delta_state_prior = np.zeros((6, 6))
        self.delta_state_var_prior = np.zeros((6, 6))
        self.delta_state_posterior = np.zeros((6, 6))
        self.delta_state_var_posterior = np.zeros((6, 6))

        # uncertainty of model parameter value (process noise)
        self.Q = np.array([[1.0e-05, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 3.0e-05, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 3.0e-05, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 1.0e-05, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 1.0e-05, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 2.0e-05]])
        
        # uncertainty compensation terms
        # x(k) = A*x(k-1) + B*u(k-1) + w(k)
        # y(k) = C*x(k) + v(k)
        # -->
        # y(k) = C*A*x(k-1) + C*B*u(k-1) + C*w(k) + v(k)
        self.gamma = np.zeros((6, 6))

        self.W = np.zeros((6, 6))  # measurement error of environment input
        
        self.V = np.array([[8.0e-06, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 8.0e-06, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 8.0e-06, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 8.0e-06, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 8.0e-06, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 8.0e-06]])

        self.pole = 0.6
        self.safe_region = np.array([[0.0, 1.0 / (1 - self.pole) * self.B[0][0]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[1][1]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[2][2]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[3][3]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[4][4]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[5][5]]])
        # print("safe_region:\n{}\n".format(self.safe_region))

        # probability threshold
        self.prob_threshold = 0.999999998  # 6sigma
        
        self.setpoint = 0.9

        # alarm signal
        self.alarm = np.zeros(6)

        # historical measurements
        self.list_u = []  # historical controller output
        self.list_y = []  # historical managed system output

    def deviation_detector(self, u_1, y):

        self.counting = self.counting + 1

        if len(self.list_u) < 3:
            self.list_u.append(u_1)
            self.list_y.append(y)
        else:
            self.list_u.append(u_1)
            self.list_y.append(y)

            if self.logging:
                print("############### deviation_detector k=" + str(self.counting) + " ############### ")

            # state estimation
            ## input: time series observation
            ##    [0]     [1]     [2]    [3]
            ##  u(k-4), u(k-3), u(k-2), u(k-1)
            ##  y(k-3), y(k-2), y(k-1), y(k)
            delta_y_2 = self.list_y[1] - self.list_y[0]
            delta_u_2 = self.list_u[2] - self.list_u[1]

            # output: delta_state_prior, delta_state_var_prior
            self.delta_state_posterior, \
            self.delta_state_var_posterior, \
            self.delta_state_prior, \
            self.delta_state_var_prior = self.observer(self.B_k_posterior,
                                                       self.delta_state_prior,
                                                       self.delta_state_var_prior,
                                                       delta_y_2, delta_u_2)

            # model parameter estimation and deviation detection
            # input: time series observation
            y_0 = self.list_y[3]            
            delta_u_1 = self.list_u[3] - self.list_u[2]
            delta_y_0 = self.list_y[3] - self.list_y[2]

            # output: B_k_posterior, P_k_posterior
            if abs(delta_u_1[0][0]) > 0 or abs(delta_u_1[1][1]) > 0 or abs(delta_u_1[2][2]) > 0 or \
               abs(delta_u_1[3][3]) > 0 or abs(delta_u_1[4][4]) > 0 or abs(delta_u_1[5][5]) > 0:
                # output: B_k_posterior, P_k_posterior
                self.B_k_prior, \
                self.P_k_prior, \
                self.B_k_posterior, \
                self.P_k_posterior = self.estimator(self.delta_state_prior,
                                                    self.delta_state_var_prior,
                                                    self.B_k_prior,
                                                    self.P_k_prior,
                                                    self.B_k_posterior,
                                                    self.P_k_posterior,
                                                    delta_u_1, delta_y_0)

                # alarmer
                self.alarm = self.deviation_alarmer(self.B_k_posterior,
                                                    self.P_k_posterior)

                if self.logging:
                    print("\n********** passive decision **********")
                    for i in range(0, 6):
                        print("delta_u_1[{}]:{}".format(i, delta_u_1[i][i]))
                        print("delta_y_0[{}]:{}".format(i, delta_y_0[i][i]))
                        print("B_k_prior[{}]:{}".format(i, self.B_k_prior[i][i]))
                        print("P_k_prior[{}]:{}".format(i, self.P_k_prior[i][i]))
                        print("B_k_posterior[{}]:{}".format(i, self.B_k_posterior[i][i]))
                        print("P_k_posterior[{}]:{}".format(i, self.P_k_posterior[i][i]))
                        print("alarm[{}]:{}\n".format(i, self.alarm[i]))

            # degradation detector
            for index in range(0, 6):
                if delta_u_1[index][index] == 0 and self.alarm[index] == 0:
                    delta = y_0[index][index] - self.setpoint
                    # self.alarm[index] = degradation_detector(index, delta)

            # update historical measurements
            self.list_u.remove(self.list_u[0])
            self.list_y.remove(self.list_y[0])

        return self.alarm

    def observer(self, B_k_posterior, delta_state_prior, delta_state_var_prior, delta_y_2, delta_u_2):
        # refined nominal model
        # delta_y(k-2) = C*delta_x(k-2) + v(k-2)
        # delta_x(k-1) = A*delta_x(k-2) + B*delta_u(k-2) + w(k-1)

        # update process
        # observation model which maps the true state space into the observed space
        H = self.C

        # measurement pre-fit residual
        R_k = delta_y_2 - np.dot(H, delta_state_prior)

        # pre-fit residual variance
        S_k = np.dot(np.dot(H, delta_state_var_prior), H.T) + self.V

        # updated Kalman gain
        K = np.dot(np.dot(delta_state_var_prior, H.T), np.linalg.inv(S_k))

        # updated (a posteriori) state estimate
        delta_state_posterior = delta_state_prior + np.dot(K, R_k)

        # updated (a posteriori) delta_state estimate variance
        delta_state_var_posterior = np.dot((np.eye(len(delta_state_var_prior)) - np.dot(K, H)), delta_state_var_prior)

        # prediction process
        # predicted (a priori) state estimate
        delta_state_prior = np.dot(self.A, delta_state_posterior) + \
                            np.dot(B_k_posterior.T, delta_u_2)

        # predicted (a priori) state estimate variance
        delta_state_var_prior = np.dot(np.dot(self.A, delta_state_var_posterior), self.A) + self.W

        return delta_state_posterior, delta_state_var_posterior, delta_state_prior, delta_state_var_prior

    def estimator(self, delta_state_prior, delta_state_var_prior,
                  B_k_prior, P_k_prior, B_k_posterior, P_k_posterior, delta_u_1, delta_y_0):
        # refined nominal model
        # B(k) = B(k-1) + q(k)
        # delta_y(k) = C*A*delta_x(k) + C*B(k)*delta_u(k-1) + C*w(k) + v(k)

        # prediction process
        for i in range(0, 6):
            if abs(delta_u_1[i][i]) > 0.0:
                # predicted (a priori) model parameter estimate
                B_k_prior[i][i] = B_k_posterior[i][i]

                # predicted (a priori) model parameter estimate variance
                P_k_prior[i][i] = P_k_posterior[i][i] + self.Q[i][i]

        # update process
        # observation model which maps the true model parameter space into the observed space
        H = np.dot(self.C, delta_u_1.T)
        # print("H:\n{}".format(H))

        # measurement pre-fit residual
        error = delta_y_0 - (np.dot(np.dot(self.C, self.A), delta_state_prior) + np.dot(H, B_k_prior))
        # print("error:\n{}".format(error))

        # pre-fit residual variance
        S_k = np.dot(np.dot(np.dot(self.C, self.A), delta_state_var_prior), np.dot(self.C, self.A).T) + \
              np.dot(np.dot(H, P_k_prior), H.T) + \
              np.dot(np.dot(self.C, self.W), self.C.T) + self.V
        # print("S_k:\n{}".format(S_k))

        # updated Kalman gain
        K = np.dot(np.dot(P_k_prior, H.T), np.linalg.inv(S_k))
        # print("K:\n{}".format(K))

        # updated (a posteriori) model parameter estimate and its variance or keep the last values
        for i in range(0, 6):
            if abs(delta_u_1[i][i]) > 0.0:
                # updated (a posteriori) model parameter estimate
                B_k_posterior[i][i] = B_k_prior[i][i] + \
                                      K[i][i] * error[i][i]

                # updated (a posteriori) model parameter estimate variance
                P_k_posterior[i][i] = (1.0 - np.dot(K, H)[i][i]) * P_k_prior[i][i]

        return B_k_prior, P_k_prior, B_k_posterior, P_k_posterior

    def deviation_alarmer(self, B_k_posterior, P_k_posterior):
        # alarm if the derived probability that model parameter value
        # falls into safe region exceeds the probability threshold
        cdf = np.zeros(6)
        alarm = np.zeros(6)

        for index in range(0, 6):
            loc = B_k_posterior[index][index]
            scale = np.sqrt(P_k_posterior[index][index])
            cdf[index] = stats.norm.cdf(self.safe_region[index][1], loc, scale) - \
                         stats.norm.cdf(self.safe_region[index][0], loc, scale)

            if cdf[index] < self.prob_threshold:
                alarm[index] = 1

        return alarm

    def get_B_k_prior(self):
        return self.B_k_prior

    def get_P_k_prior(self):
        return self.P_k_prior

    def get_B_k_posterior(self):
        return self.B_k_posterior

    def get_P_k_posterior(self):
        return self.P_k_posterior

    def get_alarm(self):
        return self.alarm