import numpy as np

from sklearn.linear_model import LinearRegression
from scipy import stats
from cvxopt import matrix, solvers

np.set_printoptions(suppress=True, precision=10, threshold=2000, linewidth=150)
solvers.options['maxiters'] = 10
solvers.options['show_progress'] = False

import warnings

warnings.filterwarnings("ignore")  # RuntimeWarning: divide by zero encountered in double_scalars


def passive_detector(alpha_1, beta, epsilon, delta_u_1, delta_y_1, delta_y_0):
    # alarm if derived probability of occurring prediction error does not exceed the probability threshold
    # regard a data point outside (mean ± 6std) as an outlier
    
    prob_6sigma = 0.999999981
    passive_alarm = np.zeros(6)
        
    prediction_error = delta_y_0 - (np.dot(alpha_1, delta_y_1) + np.dot(beta, delta_u_1))
    for n in range(0, 6):
        loc = 0.0
        scale = np.sqrt(epsilon[n][n])

        if prediction_error[n][n] <= loc:
            cdf = stats.norm.cdf(prediction_error[n][n], loc, scale)
        else:
            cdf = 1.0 - stats.norm.cdf(prediction_error[n][n], loc, scale)

        if cdf < (1.0 - prob_6sigma) / 2.0:
            passive_alarm[n] = 1
            
    return prediction_error, passive_alarm      


class ARMA_Plus:
    # autoregressive moving average active detector

    def __init__(self, logging):

        self.logging = logging
        self.counting = 0

        ############################## ARMA section ##################################################
        # nominal model parameters
        # x(k) = A*x(k-1) + B*u(k-1)
        # y(k) = C*x(k)
        self.A = np.zeros((6, 6))

        self.B = np.array([[0.1502, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.1505, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.1506, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.1503, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.1503, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 0.1504]])
        
        self.C = 1.0 * np.eye(6)

        # uncertainty compensation terms
        self.V = np.zeros((6, 6))

        # detector parameters
        self.alpha_1 = np.zeros((6, 6))
        self.beta = np.copy(self.B)
        self.epsilon = np.copy(self.V)

        self.sliding_window_size = 28
        self.prediction_error = np.zeros((6, 6))

        # probability threshold
        self.prob_threshold = 0.999999998  # 6sigma

        # alarm signal
        self.alarm = np.zeros(6)

        # historical measurements
        self.list_u = []  # historical adaptation output
        self.list_y = []  # historical managed system output

        ############################## auxiliary signal trigger section ################################################
        # auxiliary_signal_trigger_mode = "prior_trigger"
        # deviated model parameter
        self.B_k_prior = np.copy(self.B)
        self.P_k_prior = 1.0e-05 * np.eye(6)  # estimate uncertainty

        # uncertainty of model parameter value (process noise)
        self.Q = np.array([[1.0e-05, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 3.0e-05, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 3.0e-05, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 1.0e-05, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 1.0e-05, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 2.0e-05]])
  
        # safe region of model parameter values
        self.pole = 0.6
        self.safe_region = np.array([[0.0, 1.0 / (1 - self.pole) * self.B[0][0]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[1][1]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[2][2]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[3][3]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[4][4]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[5][5]]])
        # print("safe_region:\n{}\n".format(self.safe_region))
        
        # index range
        self.index_range = [0, 6]

        # active flag
        self.active_flag = np.zeros(6)
        self.active_trigger_threshold = 0.999999998  # 6sigma

        ############################## auxiliary signal design section ##################################################
        # auxiliary_signal_design_mode = "optimal_design"
        ## constraints
        self.safety_n_sigma = 6
        self.U_constraint = [[1, 20], [1, 20], [1, 20], [1, 20], [1, 20], [1, 20]]
        self.Y_constraint = [[0.0, 1.3], [0.0, 1.3], [0.0, 1.3], [0.0, 1.3], [0.0, 1.3], [0.0, 1.3]] 
 
        ## safety auxiliary signal constraints
        self.safety_AS = [[-19, 19], [-19, 19], [-19, 19], [-19, 19], [-19, 19], [-19, 19]]

        ## action function parameters of the auxiliary signal
        self.T = 1.0
        self.r_C = [1.5, 1.5,
                    1.5, 1.5,
                    1.5, 1.5]

        ## safety function parameters of auxiliary signal: 2.0/(Y_low + Y_high)
        self.r_S = [2.0 / (0.0 + 1.3), 2.0 / (0.0 + 1.3),
                    2.0 / (0.0 + 1.3), 2.0 / (0.0 + 1.3),
                    2.0 / (0.0 + 1.3), 2.0 / (0.0 + 1.3)]

        ## accuracy enhancement function parameters of auxiliary signal
        self.r_D = [1.0 / abs(self.B[0][0]), 1.0 / abs(self.B[1][1]),
                    1.0 / abs(self.B[2][2]), 1.0 / abs(self.B[3][3]),
                    1.0 / abs(self.B[4][4]), 1.0 / abs(self.B[5][5])]

        # optimal auxiliary control signal
        self.opt_AS = np.zeros(6)

    def deviation_detector(self, u_1_str, y_str):
        # convert string to array
        ## 6,6,6,6,6,6
        ## 0.9,0.9,0.9,0.9,0.9,0.9
        U_str = u_1_str.strip().split(",")
        Y_str = y_str.strip().split(",")

        u_1 = np.array([[int(U_str[0]), 0.0, 0.0, 0.0, 0.0, 0.0],
                        [0.0, int(U_str[1]), 0.0, 0.0, 0.0, 0.0],
                        [0.0, 0.0, int(U_str[2]), 0.0, 0.0, 0.0],
                        [0.0, 0.0, 0.0, int(U_str[3]), 0.0, 0.0],
                        [0.0, 0.0, 0.0, 0.0, int(U_str[4]), 0.0],
                        [0.0, 0.0, 0.0, 0.0, 0.0, int(U_str[5])]])

        y = np.array([[float(Y_str[0]), 0.0, 0.0, 0.0, 0.0, 0.0],
                      [0.0, float(Y_str[1]), 0.0, 0.0, 0.0, 0.0],
                      [0.0, 0.0, float(Y_str[2]), 0.0, 0.0, 0.0],
                      [0.0, 0.0, 0.0, float(Y_str[3]), 0.0, 0.0],
                      [0.0, 0.0, 0.0, 0.0, float(Y_str[4]), 0.0],
                      [0.0, 0.0, 0.0, 0.0, 0.0, float(Y_str[5])]])
        # print(u_1, y)

        if len(self.list_u) < self.sliding_window_size:
            self.list_u.append(u_1)
            self.list_y.append(y)
        else:
            self.list_u.append(u_1)
            self.list_y.append(y)

            if self.logging:
                print("############### deviation_detector k=" + str(self.counting) + " ###############")

            # online identification
            ## input: time series observation
            ## u(k-sw-1), ..., u(k-2)
            ## y(k-sw), ..., y(k-1)
            self.alpha_1, self.beta, self.epsilon = self.ARSI(
                self.list_u[len(self.list_u) - self.sliding_window_size:len(self.list_u) - 1],
                self.list_y[len(self.list_y) - self.sliding_window_size:len(self.list_y) - 1])
            
            # passive decision
            ## input: time series observation
            delta_u_1 = self.list_u[len(self.list_u) - 1] - self.list_u[len(self.list_u) - 2]
            delta_y_1 = self.list_y[len(self.list_y) - 2] - self.list_y[len(self.list_y) - 3]
            delta_y_0 = self.list_y[len(self.list_y) - 1] - self.list_y[len(self.list_y) - 2]
            self.prediction_error, self.alarm = passive_detector(self.alpha_1, self.beta, self.epsilon,
                                                                 delta_u_1, delta_y_1, delta_y_0)

            # active part
            delta_u_1 = self.list_u[len(self.list_u) - 1] - self.list_u[len(self.list_u) - 2]
            
            for index in range(self.index_range[0], self.index_range[1]):
                if abs(delta_u_1[index][index]) > 0.0:
                    # reset auxiliary signal trigger and design
                    self.active_flag[index] = 0
                    self.opt_AS[index] = 0

                    # reset prior model parameter
                    self.B_k_prior[index][index] = self.B.T[index][index]
                    self.P_k_prior[index][index] = 5.0e-06

                else:
                    # when no alarm, continue active part
                    if np.all(self.alarm == 0):

                        ## keep last B_prior
                        self.B_k_prior[index][index] = self.B_k_prior[index][index]

                        ## enlarge P_k_prior as time goes on
                        self.P_k_prior[index][index] = self.P_k_prior[index][index] + self.Q[index][index]

                        # auxiliary signal trigger
                        if self.logging:
                            print("\n********** prior_trigger index={" + str(index) + "} **********")
                            print("u_1[{}]:{}".format(index, u_1[index][index]))
                            print("y[{}]:{}".format(index, y[index]))
                            print("B_k_prior[{}]:{}".format(index, self.B_k_prior[index][index]))
                            print("P_k_prior[{}]:{}".format(index, self.P_k_prior[index][index]))

                        self.active_flag[index] = self.activate_prior_trigger(index,
                                                                              self.B_k_prior[index][index],
                                                                              self.P_k_prior[index][index])

                        if self.logging:
                            print("activate_combine_trigger...")
                            print("u_1[{}]:{}".format(index, u_1[index][index]))
                            print("y[{}]:{}".format(index, y[index]))
                            print("B_k_prior[{}]:{}".format(index, self.B_k_prior[index][index]))
                            print("P_k_prior[{}]:{}".format(index, self.P_k_prior[index][index]))
                            print("active_flag[{}]:{}\n".format(index, self.active_flag[index]))

                        # auxiliary signal design
                        if self.active_flag[index] == 1:
                            ## safety auxiliary signal
                            self.safety_AS[index] = self.calculate_safety_AS(index, 
                                                                             u_1[index][index],
                                                                             y[index][index],
                                                                             self.B_k_prior[index][index],
                                                                             self.P_k_prior[index][index])


                            ## optimal auxiliary signal
                            self.opt_AS[index] = self.calculate_optimal_AS(index, self.B.T[index][index])

                            if self.logging:
                                print("\n********** optimal_design index={" + str(index) + "} **********")
                                print("safety_AS[{}]:{}".format(index, self.safety_AS[index]))
                                print("opt_AS[{}]:{}\n".format(index, self.opt_AS[index]))

        # transfer with strings
        B_k_prior_str, P_k_prior_str, prediction_error_str, \
        alarm_str, active_flag_str, opt_AS_str = self.transferToString(self.B_k_prior, self.P_k_prior, self.prediction_error, 
                                                                       self.alarm, self.active_flag, self.opt_AS)
        
        return B_k_prior_str, P_k_prior_str, prediction_error_str, \
               alarm_str, active_flag_str, opt_AS_str


    def ARSI(self, list_u, list_y):
        
        # delta form
        list_delta_u_1 = []
        list_delta_y_1 = []
        list_delta_y_0 = []

        for n in range(2, len(list_u)):
            list_delta_u_1.append(list_u[n] - list_u[n - 1])
            list_delta_y_1.append(list_y[n - 1] - list_y[n - 2])
            list_delta_y_0.append(list_y[n] - list_y[n - 1])

        # AR-SI: alpha_1=0.0, beta
        ## delta_y(k) = delta_y(k-1) + beta*delta_u(k-1)
        alpha_1 = np.zeros((6, 6))
        beta = np.zeros((6, 6))
        epsilon = np.zeros((6, 6))

        # identification
        for index in range(0, 6):
            X = []
            Y = []
            for n in range(0, len(list_delta_u_1)):
                X.append([])
                X[n].append(list_delta_y_1[n][index][index])
                X[n].append(list_delta_u_1[n][index][index])
                Y.append(list_delta_y_0[n][index][index])

            model = LinearRegression(fit_intercept=False)
            model.fit(X, Y)
            alpha_1 = round(model.coef_[0], 5)
            beta_new = round(model.coef_[1], 5)
            # print("alpha_1[{}]: {}, beta_new[{}]: {}".format(index, alpha_1, index, beta_new))
            
            ## variance
            sum_var = 0
            for n in range(0, len(list_delta_u_1)):
                delta = list_delta_y_0[n][index][index] - (alpha_1 * list_delta_y_1[n][index][index] + beta_new * list_delta_u_1[n][index][index])
                # print(delta)
                sum_var = sum_var + delta * delta
            epsilon_new = sum_var / len(list_delta_u_1)
            # print("epsilon_new: {}\n".format(round(epsilon_new, 5)))

            ## assignment
            if abs(beta_new) == 0.0:
                beta[index][index] = self.B[index][index]
            elif abs(beta_new) > 0.0:
                beta[index][index] = beta_new
            epsilon[index][index] = epsilon_new
        # print("beta: {}, epsilon: {}\n".format(beta[index][index], epsilon[index][index]))
        
        return alpha_1, beta, epsilon


    def activate_prior_trigger(self, index, B_k_prior_i, P_k_prior_i):
        # calculate the probability of model parameter value falls into safe region
        # prior mean and variance
        loc = B_k_prior_i
        scale = np.sqrt(P_k_prior_i)
        prior_trigger_indicator = stats.norm.cdf(self.safe_region[index][1], loc, scale) - \
                                  stats.norm.cdf(self.safe_region[index][0], loc, scale)

        prior_active_flag = 0
        if prior_trigger_indicator < self.active_trigger_threshold:
            prior_active_flag = 1

        return prior_active_flag

    def calculate_safety_AS(self, index, u_i, y_i, B_k_prior_i, P_k_prior_i):
        # u_as_1 = (y_constraint[0] - y + v(k) + C*w(k))/C*B_k
        # u_as_2 = (y_constraint[1] - y - v(k) - C*w(k))/C*B_k

        # model parameter
        C_i = self.C[index][index]
        # print("C_i: {}".format(C_i))

        # max deviation model parameter
        if B_k_prior_i > 0:
            max_B_k = B_k_prior_i + self.safety_n_sigma * np.sqrt(P_k_prior_i)
        else:
            max_B_k = B_k_prior_i - self.safety_n_sigma * np.sqrt(P_k_prior_i)
        # print("max_B_k: {}".format(max_B_k))

        # possible max measurement error
        max_uncertainty = self.safety_n_sigma * np.sqrt(self.epsilon)
        # print("max_uncertainty: {}".format(max_uncertainty))

        # cost constraint
        Y_constraint_i = self.Y_constraint[index]
        # print("Y_constraint_i: {}".format(Y_constraint_i))

        # compute safety auxiliary signal
        ## if cost exceed Y_constraint
        if y_i < Y_constraint_i[0]:
            y_i = Y_constraint_i[0]
        elif y_i > Y_constraint_i[1]:
            y_i = Y_constraint_i[1]
            
        ## consider max_B_k>0 or max_B_k<=0
        if max_B_k > 0:
            u_as_1 = (Y_constraint_i[0] - y_i + max_uncertainty) / (C_i * max_B_k)
            u_as_2 = (Y_constraint_i[1] - y_i - max_uncertainty) / (C_i * max_B_k)
        else:
            u_as_1 = (Y_constraint_i[1] - y_i - max_uncertainty) / (C_i * max_B_k)
            u_as_2 = (Y_constraint_i[0] - y_i + max_uncertainty) / (C_i * max_B_k)
        # print("u_as_1[{}]: {}".format(index, u_as_1))
        # print("u_as_2[{}]: {}".format(index, u_as_2))

        AS_constraint_low_i = self.U_constraint[index][0] - u_i
        AS_constraint_upper_i = self.U_constraint[index][1] - u_i
        # print("AS_constraint_low_i[{}]: {}".format(index, AS_constraint_low_i))
        # print("AS_constraint_upper_i[{}]: {}".format(index, AS_constraint_upper_i))
        
        u_safety_low = max(np.ceil(u_as_1), AS_constraint_low_i)
        u_safety_high = min(np.floor(u_as_2), AS_constraint_upper_i)
        safety_AS_i = [u_safety_low, u_safety_high]
        # print("safety_AS_i: {}".format(safety_AS_i))

        return safety_AS_i

    def calculate_safety_AS(self, index, u_i, y_i, B_k_prior_i, P_k_prior_i):
        # u_as_1 = (Y_constraint[0] - y + v(k) + C*w(k))/(C*B_k)
        # u_as_2 = (Y_constraint[1] - y - v(k) - C*w(k))/(C*B_k)

        # model parameter
        C_i = self.C[index][index]
        # print("C_i: {}".format(C_i))

        # max deviation model parameter
        if B_k_prior_i > 0:
            max_B_k = B_k_prior_i + self.safety_n_sigma * np.sqrt(P_k_prior_i)
        else:
            max_B_k = B_k_prior_i - self.safety_n_sigma * np.sqrt(P_k_prior_i)
        # print("max_B_k: {}".format(max_B_k))

        # cost constraint
        Y_constraint_i = self.Y_constraint[index]
        # print("Y_constraint_i: {}".format(Y_constraint_i))
        
        # compute safety auxiliary signal
        ## if reliability temp exceed Y_constraint
        if y_i < Y_constraint_i[0]:
            y_i = Y_constraint_i[0]
        elif y_i > Y_constraint_i[1]:
            y_i = Y_constraint_i[1]
            
        ## consider max_B_k>0 or max_B_k<=0
        if max_B_k > 0:
            u_as_1 = (Y_constraint_i[0] - y_i) / (C_i * max_B_k)
            u_as_2 = (Y_constraint_i[1] - y_i) / (C_i * max_B_k)
        else:
            u_as_1 = (Y_constraint_i[1] - y_i) / (C_i * max_B_k)
            u_as_2 = (Y_constraint_i[0] - y_i) / (C_i * max_B_k)
        # print("u_as_1[{}]: {}".format(index, u_as_1))
        # print("u_as_2[{}]: {}".format(index, u_as_2))

        AS_constraint_low_i = self.U_constraint[index][0] - u_i
        AS_constraint_upper_i = self.U_constraint[index][1] - u_i
        # print("AS_constraint_low_i[{}]: {}".format(index, AS_constraint_low_i))
        # print("AS_constraint_upper_i[{}]: {}".format(index, AS_constraint_upper_i))
        
        u_safety_low = max(np.ceil(u_as_1), AS_constraint_low_i)
        u_safety_high = min(np.floor(u_as_2), AS_constraint_upper_i)
        safety_AS_i = [u_safety_low, u_safety_high]
        # print("safety_AS_i: {}".format(safety_AS_i))

        return safety_AS_i

    def calculate_optimal_AS(self, index, B_k_posterior_i):
        # Multi-objective optimization:
        ## 1) Minimize operational cost of auxiliary signal
        ##          f_C = T*r_C*u'(k)^2
        ## 2) Maximize system safety under auxiliary signal
        ##          f_S = r_S*(0.5*(y_u+y_L)-y'(k+1))^2
        ## 3) Maximize expected detection improvement
        ##          f_D = r_D*y'(k+1)^2
        ## subject to: 1) u'(k) ∈ [safety_AS_min, safety_AS_max]
        ##             2) y'(k+1) = C*B(k+1)*u'(k)
        ## ->
        ## max(u') f = f_D + f_S - f_C
        ##           = r_D*y'(k+1)^2 + r_S*y'(k+1)^2 - r_S*(y_u+y_L)*y'(k+1) + 0.25*r_S*(y_u+y_L)^2 - T*r_C*u'(k)^2
        ##           = (r_D*C^2*B(k+1)^2 + r_S*C^2*B(k+1)^2 - T*r_C)*u'(k)^2 - r_S*(y_u+y_L)*C*B(k+1)*u'(k+1) + 0.25*r_S*(y_u+y_L)^2
        ## subject to: u'(k) ∈ [safety_AS_min, safety_AS_max]
        ##
        ## convert to the standard form of a QP following CVXOPT
        ## min(u') 0.5*(-2.0*r_D*C^2*B(k+1)^2 - 2.0*r_S*C^2*B(k+1)^2 + 2.0*T*r_C)*u'(k)^2 + r_S*(y_u+y_L)*C*B(k+1)*u'(k+1)
        ## subject to: -u'(k) >= safety_AS_min
        ##              u'(k) <= safety_AS_max

        # function parameters
        T_i = self.T
        r_C_i = self.r_C[index]
        r_S_i = self.r_S[index]
        r_D_i = self.r_D[index]

        # model parameters
        C_i = self.C[index][index]

        # safety auxiliary signal
        safety_AS_min = self.safety_AS[index][0]
        safety_AS_max = self.safety_AS[index][1]

        # optimization matrices
        ## x = [u'(k)]
        ## P = [-2.0*r_D*C^2*B(k+1)^2 - 2.0*r_S*C^2*B(k+1)^2 + T*r_C]
        P_0_0 = - 2.0 * r_D_i * pow(C_i, 2) * pow(B_k_posterior_i, 2) \
                - 2.0 * r_S_i * pow(C_i, 2) * pow(B_k_posterior_i, 2) + T_i * r_C_i

        P = matrix(np.array([P_0_0]), tc='d')
        # print("P_0_0: {}".format(P_0_0))

        ## x = [u'(k)]
        ## q = [r_S*(y_u+y_L)*C*B(k+1)]
        y_L = self.Y_constraint[index][0]
        y_U = self.Y_constraint[index][1]
        q_0_0 = r_S_i * (y_U + y_L) * C_i * B_k_posterior_i
        q = matrix(np.array([q_0_0]), tc='d')
        # print("q_0_0: {}".format(q_0_0))

        # inequality matrix
        if abs(safety_AS_min) > 0 and abs(safety_AS_max) > 0:
            ## Tips: elements of h to be close to 1.0
            ## x = [u'(k)]
            ## G = [-1.0/safety_AS_min; 1.0/safety_AS_max], h = [1.0; 1.0]
            G = matrix(np.array([[-1.0/safety_AS_min], [1.0/safety_AS_max]]), tc='d')
            h = matrix(np.array([[1.0], [1.0]]), tc='d')
        else:
            ## x = [u'(k)]
            ## G = [-1.0; 1.0], h = [safety_AS_min; safety_AS_max]
            G = matrix(np.array([[-1.0], [1.0]]), tc='d')
            h = matrix(np.array([[safety_AS_min], [safety_AS_max]]), tc='d')

        try:
            # cvxopt solver
            ## minimize (1/2)*x*P*x + q*x
            ## subject to: G*x < h
            sol = solvers.qp(P, q, G, h)
            
        except:
            print("exception: {}".format(exception))
            
            # discrete control parameter
            opt_AS_i = 0
            print("opt_AS_i: {}\n".format(opt_AS_i))
        
        else:
            # extract optimal value and solution
            status = sol['status']
            opt_AS_i = sol['x'][0]
            costFunction = sol['primal objective']
            print("status({}): {}".format(index, status))
            print("opt_AS_i({}): {}".format(index, opt_AS_i))
            # print("costFunction({}): {}\n".format(index, costFunction))
            
            # discrete control parameter
            if status == "optimal":
                opt_AS_i = min(max(int(np.floor(opt_AS_i)), int(safety_AS_min)), int(safety_AS_max))
            else:
                opt_AS_i = 0
            print("opt_AS_i: {}\n".format(opt_AS_i))
            
        # handling opt_AS = 0 with active_flag = 1
        if self.active_flag[index] > 0 and opt_AS_i == 0:
            # reset auxiliary signal trigger
            self.active_flag[index] = 0

            # reset prior model parameter
            self.B_k_prior[index][index] = self.B.T[index][index]
            self.P_k_prior[index][index] = 1.0e-05
            
        return opt_AS_i
    
    def set_sliding_window_size(self, sliding_window_size):
        self.sliding_window_size = sliding_window_size

    def get_beta(self):
        return self.beta

    def get_epsilon(self):
        return self.epsilon

    def get_prediction_error(self):
        return self.prediction_error

    def get_B_k_prior(self):
        return self.B_k_prior

    def get_P_k_prior(self):
        return self.P_k_prior
    
    def transferToString(self, B_k_prior, P_k_prior, prediction_error, alarm, active_flag, opt_AS):
        B_k_prior_str = ""
        for index in range(0, 6):
            B_k_prior_str = B_k_prior_str + str(B_k_prior[index][index]) + "," 
        B_k_prior_str = B_k_prior_str + str(B_k_prior[5][5])   
        
        P_k_prior_str = ""
        for index in range(0, 6):
            P_k_prior_str = P_k_prior_str + str(P_k_prior[index][index]) + "," 
        P_k_prior_str = P_k_prior_str + str(P_k_prior[5][5])    
        
        prediction_error_str = ""
        for index in range(0, 6):
            prediction_error_str = prediction_error_str + str(prediction_error[index][index]) + "," 
        prediction_error_str = prediction_error_str + str(prediction_error[5][5])   

        alarm_str = ""
        for index in range(0, 6):
            alarm_str = alarm_str + str(int(alarm[index])) + ","
        alarm_str = alarm_str + str(int(alarm[5]))        
 
        active_flag_str = ""
        for index in range(0, 6):
            active_flag_str = active_flag_str + str(int(active_flag[index])) + ","
        active_flag_str = active_flag_str + str(int(active_flag[5]))            
      
        opt_AS_str = ""
        for index in range(0, 6):
            opt_AS_str = opt_AS_str + str(int(opt_AS[index])) + ","
        opt_AS_str = opt_AS_str + str(int(opt_AS[5]))                       
                     
        return B_k_prior_str, P_k_prior_str, prediction_error_str, alarm_str, active_flag_str, opt_AS_str
    

if __name__ == "__main__":
    print("ARMA_plus...")

    detector = ARMA_Plus(False)

    n = 400
    freq = 5
    for k in range(0, n):
        U_str = str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq)
        Y_str = "0.991508,0.996441,0.992127,0.978251,0.996470,0.921172"
        print("k={}, U_str={}, Y_str={}".format(k, U_str, Y_str))

        B_k_posterior_str, P_k_posterior_str, prediction_error_str, \
        alarm_str, active_flag_str, opt_AS_str = detector.deviation_detector(U_str, Y_str)

        print("B_k_posterior_str={}".format(B_k_posterior_str))
        print("P_k_posterior_str={}".format(P_k_posterior_str))
        print("prediction_error_str={}".format(prediction_error_str))
        print("alarm_str={}".format(alarm_str))
        print("active_flag_str={}".format(active_flag_str))
        print("opt_AS_str={}\n".format(opt_AS_str))