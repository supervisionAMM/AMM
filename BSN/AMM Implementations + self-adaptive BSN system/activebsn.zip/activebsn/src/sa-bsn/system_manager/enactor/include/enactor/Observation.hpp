#ifndef OBSERVATION_HPP
#define OBSERVATION_HPP

#include <string>

class Observation {

    public:
        Observation(const std::string &name, const int &timestamp, const std::string &component, const double &freq_double, const int &freq, const double &cost) : name(name), timestamp(timestamp), component(component), freq_double(freq_double), freq(freq), cost(cost){};

        std::string getName() const { return this->name;};
        int getTimestamp() const {return this->timestamp;};
        std::string getComponent() const {return this->component;};
        double getFreqDouble() const {return this->freq_double;};
        int getFreq() const {return this->freq;};
        double getCost() const {return this->cost;};

    private:
        std::string name;
        int timestamp;
        std::string component;
        double freq_double;
        int freq;
        double cost;
};

#endif 