import numpy as np
from scipy import stats
from sklearn.linear_model import LinearRegression

import warnings

warnings.filterwarnings("ignore")  # RuntimeWarning: divide by zero encountered in double_scalars

    
def passive_detector(alpha_1, beta, epsilon, delta_u_1, delta_y_1, delta_y_0):
    # alarm if derived probability of occurring prediction error does not exceed the probability threshold
    # regard a data point outside (mean ± 6std) as an outlier
    
    prob_6sigma = 0.999999981
    passive_alarm = np.zeros(6)
        
    prediction_error = delta_y_0 - (np.dot(alpha_1, delta_y_1) + np.dot(beta, delta_u_1))
    for n in range(0, 6):
        loc = 0.0
        scale = np.sqrt(epsilon[n][n])

        if prediction_error[n][n] <= loc:
            cdf = stats.norm.cdf(prediction_error[n][n], loc, scale)
        else:
            cdf = 1.0 - stats.norm.cdf(prediction_error[n][n], loc, scale)

        if cdf < (1.0 - prob_6sigma) / 2.0:
            passive_alarm[n] = 1
            
    return prediction_error, passive_alarm         


class ARMA:
    # autoregressive moving average detector

    def __init__(self):
        # nominal model parameters
        # x(k) = A*x(k-1) + B*u(k-1)
        # y(k) = C*x(k)
        self.A = np.zeros((6, 6))

        self.B = np.array([[0.1502, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.1505, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.1506, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.1503, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.1503, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 0.1504]])
        
        self.C = 1.0 * np.eye(6)

        # uncertainty compensation terms
        self.V = np.array([[8.0e-06, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 8.0e-06, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 8.0e-06, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 8.0e-06, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 8.0e-06, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 8.0e-06]])

        # detector parameters
        self.alpha_1 = np.zeros((6, 6))
        self.beta = np.copy(self.B)
        self.epsilon = np.copy(self.V)

        self.sliding_window_size = 28
        self.prediction_error = np.zeros((6, 6))

        # probability threshold (He@ICSE'19)
        self.prob_threshold = 0.999999998  # 6sigma

        # alarm signal
        self.alarm = np.zeros(6)

        # historical measurements
        self.list_u = []  # historical adaptation output
        self.list_y = []  # historical managed system output

    def deviation_detector(self, u_1, y):

        if len(self.list_u) < self.sliding_window_size:
            self.list_u.append(u_1)
            self.list_y.append(y)
        else:
            self.list_u.append(u_1)
            self.list_y.append(y)
            
            # online identification
            ## input: time series observation
            ## u(k-sw-1), ..., u(k-2)
            ## y(k-sw), ..., y(k-1)
            self.alpha_1, self.beta, self.epsilon = self.ARSI(
                self.list_u[len(self.list_u) - self.sliding_window_size:len(self.list_u) - 1],
                self.list_y[len(self.list_y) - self.sliding_window_size:len(self.list_y) - 1])
            
            # deviation detection
            delta_u_1 = self.list_u[len(self.list_u) - 1] - self.list_u[len(self.list_u) - 2]
            delta_y_1 = self.list_y[len(self.list_y) - 2] - self.list_y[len(self.list_y) - 3]
            delta_y_0 = self.list_y[len(self.list_y) - 1] - self.list_y[len(self.list_y) - 2]
            self.prediction_error, self.alarm = passive_detector(self.alpha_1, self.beta, self.epsilon,
                                                                 delta_u_1, delta_y_1, delta_y_0)

        return self.alarm

    def ARSI(self, list_u, list_y):
        
        # delta form
        list_delta_u_1 = []
        list_delta_y_1 = []
        list_delta_y_0 = []

        for n in range(2, len(list_u)):
            list_delta_u_1.append(list_u[n] - list_u[n - 1])
            list_delta_y_1.append(list_y[n - 1] - list_y[n - 2])
            list_delta_y_0.append(list_y[n] - list_y[n - 1])

        # AR-SI: alpha_1=0.0, beta
        ## delta_y(k) = delta_y(k-1) + beta*delta_u(k-1)
        alpha_1 = np.zeros((6, 6))
        beta = np.zeros((6, 6))
        epsilon = np.zeros((6, 6))

        # identification
        for index in range(0, 6):
            X = []
            Y = []
            for n in range(0, len(list_delta_u_1)):
                X.append([])
                X[n].append(list_delta_y_1[n][index][index])
                X[n].append(list_delta_u_1[n][index][index])
                Y.append(list_delta_y_0[n][index][index])
                
            model = LinearRegression(fit_intercept=False)
            model.fit(X, Y)
            alpha_1 = round(model.coef_[0], 5)
            beta_new = round(model.coef_[1], 5)
            # print("alpha_1[{}]: {}, beta_new[{}]: {}".format(index, alpha_1, index, beta_new))
            
            ## variance
            sum_var = 0
            for n in range(0, len(list_delta_u_1)):
                delta = list_delta_y_0[n][index][index] - (alpha_1 * list_delta_y_1[n][index][index] + beta_new * list_delta_u_1[n][index][index])
                # print(delta)
                sum_var = sum_var + delta * delta
            epsilon_new = sum_var / len(list_delta_u_1)
            # print("epsilon_new: {}\n".format(round(epsilon_new, 5)))

            ## assignment
            if abs(beta_new) == 0.0:
                beta[index][index] = self.B[index][index]
            elif abs(beta_new) > 0.0:
                beta[index][index] = beta_new
            epsilon[index][index] = epsilon_new
        # print("beta: {}, epsilon: {}\n".format(beta[index][index], epsilon[index][index]))
        
        return alpha_1, beta, epsilon

    def set_sliding_window_size(self, sliding_window_size):
        self.sliding_window_size = sliding_window_size

    def get_beta(self):
        return self.beta

    def get_epsilon(self):
        return self.epsilon

    def get_prediction_error(self):
        return self.prediction_error