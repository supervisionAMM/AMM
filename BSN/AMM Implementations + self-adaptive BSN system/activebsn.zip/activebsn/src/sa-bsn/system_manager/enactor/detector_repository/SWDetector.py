#! /usr/bin/env python
import numpy as np


class SWDetector:
    # sliding window detector

    def __init__(self):
        # parameter
        self.sliding_window_size = 28
        self.error_threshold = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

        # horizon list
        self.list_y = []

        # results
        self.avg_error_dist = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.alarm = np.zeros(6)

    def deviation_detector(self, y):

        if len(self.list_y) < self.sliding_window_size:
            self.list_y.append(y)
        else:
            self.list_y.append(y)

            for index in range(0, 6):
                # average error
                sum_error_1 = 0
                for k in range(0, int(self.sliding_window_size / 2)):
                    sum_error_1 = sum_error_1 + self.list_y[k][index][index]
                avg_error_1 = sum_error_1 / (self.sliding_window_size / 2)

                sum_error_2 = 0
                for k in range(int(self.sliding_window_size / 2), self.sliding_window_size):
                    sum_error_2 = sum_error_2 + self.list_y[k][index][index]
                avg_error_2 = sum_error_2 / (self.sliding_window_size / 2)

                # threshold
                avg_error_dist = abs(avg_error_2 - avg_error_1)
                self.avg_error_dist[index] = avg_error_dist
                # print("avg_error_dist:{}".format(avg_error_dist))

                if avg_error_dist > self.error_threshold[index]:
                    self.alarm[index] = 1

            # update old data
            self.list_y.remove(self.list_y[0])

        return self.alarm

    def set_sliding_window_size(self, sliding_window_size):
        self.sliding_window_size = sliding_window_size

    def set_error_threshold(self, error_threshold):
        self.error_threshold = error_threshold

    def get_avg_error_dist(self):
        return self.avg_error_dist