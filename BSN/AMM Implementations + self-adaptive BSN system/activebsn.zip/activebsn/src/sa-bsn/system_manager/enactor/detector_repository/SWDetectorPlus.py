import numpy as np

from scipy import stats
from cvxopt import matrix, solvers

np.set_printoptions(suppress=True, precision=10, threshold=2000, linewidth=150)
solvers.options['maxiters'] = 10
solvers.options['show_progress'] = False


class SWDetector_Plus:
    # sliding window active detector

    def __init__(self, logging):

        self.logging = logging
        self.counting = 0

        ############################## SWDetector section ################################
        # parameter
        self.sliding_window_size = 28
        self.error_threshold = [0.0757, 0.0634, 0.0709, 0.0611, 0.0778, 0.0628]

        # horizon list
        self.list_y = []

        # results
        self.avg_error_dist = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.alarm = np.zeros(6)

        ############################## knowledge section ##################################################
        # nominal model parameters
        # x(k) = A*x(k-1) + B*u(k-1)
        # y(k) = C*x(k)
        self.A = np.zeros((6, 6))

        self.B = np.array([[0.1502, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.1505, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.1506, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.1503, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.1503, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 0.1504]])
        
        self.C = 1.0 * np.eye(6)

        # deviated model parameter
        self.B_k_prior = np.copy(self.B)
        self.P_k_prior = 1.0e-05 * np.eye(6)  # estimate uncertainty

        # uncertainty of model parameter value (process noise)
        self.Q = np.array([[1.0e-05, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 3.0e-05, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 3.0e-05, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 1.0e-05, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 1.0e-05, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 2.0e-05]])
        
        ############################## auxiliary signal trigger section ################################################
        # safe region of model parameter values
        self.pole = 0.6
        self.safe_region = np.array([[0.0, 1.0 / (1 - self.pole) * self.B[0][0]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[1][1]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[2][2]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[3][3]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[4][4]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[5][5]]])
        # print("safe_region:\n{}\n".format(self.safe_region))
        
        # probability threshold
        self.prob_threshold = 0.999999998  # 6sigma
        
        self.setpoint = 0.9

        # alarm signal
        self.alarm = np.zeros(6)

        # historical measurements
        self.list_u = []  # historical controller output
        self.list_y = []  # historical managed system output

        # auxiliary_signal_trigger_mode = "prior_trigger"
        self.index_range = [0, 6]
        self.active_flag = np.zeros(6)
        self.active_trigger_threshold = 0.999999998  # 6sigma

        ############################## auxiliary signal design section ##################################################
        # 1) auxiliary_signal_design_mode = "optimal_design"
        ## constraints
        self.safety_n_sigma = 6
        self.U_constraint = [[1, 20], [1, 20], [1, 20], [1, 20], [1, 20], [1, 20]]
        self.Y_constraint = [[0.0, 1.3], [0.0, 1.3], [0.0, 1.3], [0.0, 1.3], [0.0, 1.3], [0.0, 1.3]] 
 
        ## safety auxiliary signal constraints
        self.safety_AS = [[-19, 19], [-19, 19], [-19, 19], [-19, 19], [-19, 19], [-19, 19]]
        
        ## action function parameters of the auxiliary signal
        self.T = 1.0
        self.r_C = [1.5, 1.5,
                    1.5, 1.5,
                    1.5, 1.5]

        ## safety function parameters of auxiliary signal: 2.0/(Y_low + Y_high)
        self.r_S = [2.0 / (0.0 + 1.3), 2.0 / (0.0 + 1.3),
                    2.0 / (0.0 + 1.3), 2.0 / (0.0 + 1.3),
                    2.0 / (0.0 + 1.3), 2.0 / (0.0 + 1.3)]

        ## accuracy enhancement function parameters of auxiliary signal
        self.r_D = [1.0 / abs(self.B[0][0]), 1.0 / abs(self.B[1][1]),
                    1.0 / abs(self.B[2][2]), 1.0 / abs(self.B[3][3]),
                    1.0 / abs(self.B[4][4]), 1.0 / abs(self.B[5][5])]

        # optimal auxiliary control signal
        self.opt_AS = np.zeros(6)
      
    def deviation_detector(self, u_1_str, y_str):

        self.counting = self.counting + 1

        # convert string to array
        ## 6,6,6,6,6,6
        ## 0.9,0.9,0.9,0.9,0.9,0.9
        U_str = u_1_str.strip().split(",")
        Y_str = y_str.strip().split(",")

        u_1 = np.array([[int(U_str[0]), 0.0, 0.0, 0.0, 0.0, 0.0],
                        [0.0, int(U_str[1]), 0.0, 0.0, 0.0, 0.0],
                        [0.0, 0.0, int(U_str[2]), 0.0, 0.0, 0.0],
                        [0.0, 0.0, 0.0, int(U_str[3]), 0.0, 0.0],
                        [0.0, 0.0, 0.0, 0.0, int(U_str[4]), 0.0],
                        [0.0, 0.0, 0.0, 0.0, 0.0, int(U_str[5])]])

        y = np.array([float(Y_str[0]), float(Y_str[1]), float(Y_str[2]), 
                      float(Y_str[3]), float(Y_str[4]), float(Y_str[5])])

        if len(self.list_u) < self.sliding_window_size:
            self.list_u.append(u_1)
            self.list_y.append(y)
        else:
            self.list_u.append(u_1)
            self.list_y.append(y)
            
            if self.logging:
                print("############### deviation_detector k=" + str(self.counting) + " ############### ")

            # passive decision
            for n in range(0, len(y)):
                # average error
                sum_error_1 = 0
                for k in range(0, int(self.sliding_window_size / 2)):
                    sum_error_1 = sum_error_1 + self.list_y[k][n]
                avg_error_1 = sum_error_1 / (self.sliding_window_size / 2)

                sum_error_2 = 0
                for k in range(int(self.sliding_window_size / 2), self.sliding_window_size):
                    sum_error_2 = sum_error_2 + self.list_y[k][n]
                avg_error_2 = sum_error_2 / (self.sliding_window_size / 2)

                # threshold
                avg_error_dist = abs(avg_error_2 - avg_error_1)
                self.avg_error_dist[n] = avg_error_dist

                if avg_error_dist > self.error_threshold[n]:
                    self.alarm[n] = 1
        
            # active part
            delta_u_1 = self.list_u[len(self.list_u) - 1] - self.list_u[len(self.list_u) - 2]
            
            for index in range(self.index_range[0], self.index_range[1]):
                if abs(delta_u_1[index][index]) > 0:
                    # reset auxiliary signal trigger and design
                    self.active_flag[index] = 0
                    self.opt_AS[index] = 0

                    # reset prior model parameter
                    self.B_k_prior[index][index] = self.B.T[index][index]
                    self.P_k_prior[index][index] = 1.0e-05

                    # if self.logging:
                    #     print("********** passive decision **********")
                    #     print("u_1[{}]:{}".format(index, u_1[index][index]))
                    #     print("y_0[{}]:{}".format(index, y[index]))
                    #     print("B_k_prior[{}]:{}".format(index, self.B_k_prior[index][index]))
                    #     print("P_k_prior[{}]:{}".format(index, self.P_k_prior[index][index]))
                    #     print("alarm[{}]:{}\n".format(index, self.alarm[index]))

                else:
                    # when no alarm, continue active part
                    if np.all(self.alarm == 0):

                        ## keep last B_prior
                        self.B_k_prior[index][index] = self.B_k_prior[index][index]

                        ## enlarge P_k_prior as time goes on
                        self.P_k_prior[index][index] = self.P_k_prior[index][index] + self.Q[index][index]

                        # auxiliary signal trigger
                        if self.logging:
                            print("********** prior_trigger index={" + str(index) + "} **********")
                            print("u_1[{}]:{}".format(index, u_1[index][index]))
                            print("y[{}]:{}".format(index, y[index]))
                            print("B_k_prior[{}]:{}".format(index, self.B_k_prior[index][index]))
                            print("P_k_prior[{}]:{}\n".format(index, self.P_k_prior[index][index]))

                        self.active_flag[index] = self.activate_prior_trigger(index,
                                                                            self.B_k_prior[index][index],
                                                                            self.P_k_prior[index][index])

                        if self.logging:
                            print("activate_prior_trigger...")
                            print("u_1[{}]:{}".format(index, u_1[index][index]))
                            print("y[{}]:{}".format(index, y[index]))
                            print("B_k_prior[{}]:{}".format(index, self.B_k_prior[index][index]))
                            print("P_k_prior[{}]:{}".format(index, self.P_k_prior[index][index]))
                            print("active_flag[{}]:{}\n".format(index, self.active_flag[index]))

                        # auxiliary signal design
                        if self.active_flag[index] == 1:
                            ## safety auxiliary signal
                            self.safety_AS[index] = self.calculate_safety_AS(index, 
                                                                             u_1[index][index],
                                                                             y[index],
                                                                             self.B_k_prior[index][index],
                                                                             self.P_k_prior[index][index])

                            ## optimal auxiliary signal
                            self.opt_AS[index] = self.calculate_optimal_AS(index, self.B.T[index][index])

                            if self.logging:
                                print("********* optimal_design index={" + str(index) + "} **********")
                                print("safety_AS[{}]:{}".format(index, self.safety_AS[index]))
                                print("opt_AS[{}]:{}\n".format(index, self.opt_AS[index]))
                            
            # update old data
            self.list_u.remove(self.list_u[0])
            self.list_y.remove(self.list_y[0])

        # transfer with strings
        B_k_prior_str, P_k_prior_str, avg_error_dist_str, \
        alarm_str, active_flag_str, opt_AS_str = self.transferToString(self.B_k_prior, self.P_k_prior, self.avg_error_dist, 
                                                                       self.alarm, self.active_flag, self.opt_AS)                         

        return B_k_prior_str, P_k_prior_str, avg_error_dist_str, \
               alarm_str, active_flag_str, opt_AS_str

    def activate_prior_trigger(self, index, B_k_prior_i, P_k_prior_i):
        # calculate the probability of model parameter value falls into safe region
        # prior mean and variance
        loc = B_k_prior_i
        scale = np.sqrt(P_k_prior_i)
        prior_trigger_indicator = stats.norm.cdf(self.safe_region[index][1], loc, scale) - \
                                  stats.norm.cdf(self.safe_region[index][0], loc, scale)

        prior_active_flag = 0
        if prior_trigger_indicator < self.active_trigger_threshold:
            prior_active_flag = 1

        return prior_active_flag

    def calculate_safety_AS(self, index, u_i, y_i, B_k_prior_i, P_k_prior_i):
        # u_as_1 = (Y_constraint[0] - y + v(k) + C*w(k))/(C*B_k)
        # u_as_2 = (Y_constraint[1] - y - v(k) - C*w(k))/(C*B_k)

        # model parameter
        C_i = self.C[index][index]
        # print("C_i: {}".format(C_i))

        # max deviation model parameter
        if B_k_prior_i > 0:
            max_B_k = B_k_prior_i + self.safety_n_sigma * np.sqrt(P_k_prior_i)
        else:
            max_B_k = B_k_prior_i - self.safety_n_sigma * np.sqrt(P_k_prior_i)
        # print("max_B_k: {}".format(max_B_k))

        # cost constraint
        Y_constraint_i = self.Y_constraint[index]
        # print("Y_constraint_i: {}".format(Y_constraint_i))
        
        # compute safety auxiliary signal
        ## if reliability temp exceed Y_constraint
        if y_i < Y_constraint_i[0]:
            y_i = Y_constraint_i[0]
        elif y_i > Y_constraint_i[1]:
            y_i = Y_constraint_i[1]
            
        ## consider max_B_k>0 or max_B_k<=0
        if max_B_k > 0:
            u_as_1 = (Y_constraint_i[0] - y_i) / (C_i * max_B_k)
            u_as_2 = (Y_constraint_i[1] - y_i) / (C_i * max_B_k)
        else:
            u_as_1 = (Y_constraint_i[1] - y_i) / (C_i * max_B_k)
            u_as_2 = (Y_constraint_i[0] - y_i) / (C_i * max_B_k)
        # print("u_as_1[{}]: {}".format(index, u_as_1))
        # print("u_as_2[{}]: {}".format(index, u_as_2))

        AS_constraint_low_i = self.U_constraint[index][0] - u_i
        AS_constraint_upper_i = self.U_constraint[index][1] - u_i
        # print("AS_constraint_low_i[{}]: {}".format(index, AS_constraint_low_i))
        # print("AS_constraint_upper_i[{}]: {}".format(index, AS_constraint_upper_i))
        
        u_safety_low = max(np.ceil(u_as_1), AS_constraint_low_i)
        u_safety_high = min(np.floor(u_as_2), AS_constraint_upper_i)
        safety_AS_i = [u_safety_low, u_safety_high]
        # print("safety_AS_i: {}".format(safety_AS_i))

        return safety_AS_i

    def calculate_optimal_AS(self, index, B_k_posterior_i):
        # Multi-objective optimization:
        ## 1) Minimize operational cost of auxiliary signal
        ##          f_C = T*r_C*u'(k)^2
        ## 2) Maximize system safety under auxiliary signal
        ##          f_S = r_S*(0.5*(y_u+y_L)-y'(k+1))^2
        ## 3) Maximize expected detection improvement
        ##          f_D = r_D*y'(k+1)^2
        ## subject to: 1) u'(k) ∈ [safety_AS_min, safety_AS_max]
        ##             2) y'(k+1) = C*B(k+1)*u'(k)
        ## ->
        ## max(u') f = f_D + f_S - f_C
        ##           = r_D*y'(k+1)^2 + r_S*y'(k+1)^2 - r_S*(y_u+y_L)*y'(k+1) + 0.25*r_S*(y_u+y_L)^2 - T*r_C*u'(k)^2
        ##           = (r_D*C^2*B(k+1)^2 + r_S*C^2*B(k+1)^2 - T*r_C)*u'(k)^2 - r_S*(y_u+y_L)*C*B(k+1)*u'(k+1) + 0.25*r_S*(y_u+y_L)^2
        ## subject to: u'(k) ∈ [safety_AS_min, safety_AS_max]
        ##
        ## convert to the standard form of a QP following CVXOPT
        ## min(u') 0.5*(-2.0*r_D*C^2*B(k+1)^2 - 2.0*r_S*C^2*B(k+1)^2 + 2.0*T*r_C)*u'(k)^2 + r_S*(y_u+y_L)*C*B(k+1)*u'(k+1)
        ## subject to: -u'(k) >= safety_AS_min
        ##              u'(k) <= safety_AS_max

        # function parameters
        T_i = self.T
        r_C_i = self.r_C[index]
        r_S_i = self.r_S[index]
        r_D_i = self.r_D[index]

        # model parameters
        C_i = self.C[index][index]

        # safety auxiliary signal
        safety_AS_min = self.safety_AS[index][0]
        safety_AS_max = self.safety_AS[index][1]

        # optimization matrices
        ## x = [u'(k)]
        ## P = [-2.0*r_D*C^2*B(k+1)^2 - 2.0*r_S*C^2*B(k+1)^2 + T*r_C]
        P_0_0 = - 2.0 * r_D_i * pow(C_i, 2) * pow(B_k_posterior_i, 2) \
                - 2.0 * r_S_i * pow(C_i, 2) * pow(B_k_posterior_i, 2) + T_i * r_C_i

        P = matrix(np.array([P_0_0]), tc='d')
        # print("P_0_0: {}".format(P_0_0))

        ## x = [u'(k)]
        ## q = [r_S*(y_u+y_L)*C*B(k+1)]
        y_L = self.Y_constraint[index][0]
        y_U = self.Y_constraint[index][1]
        q_0_0 = r_S_i * (y_U + y_L) * C_i * B_k_posterior_i
        q = matrix(np.array([q_0_0]), tc='d')
        # print("q_0_0: {}".format(q_0_0))

        # inequality matrix
        if abs(safety_AS_min) > 0 and abs(safety_AS_max) > 0:
            ## Tips: elements of h to be close to 1.0
            ## x = [u'(k)]
            ## G = [-1.0/safety_AS_min; 1.0/safety_AS_max], h = [1.0; 1.0]
            G = matrix(np.array([[-1.0/safety_AS_min], [1.0/safety_AS_max]]), tc='d')
            h = matrix(np.array([[1.0], [1.0]]), tc='d')
        else:
            ## x = [u'(k)]
            ## G = [-1.0; 1.0], h = [safety_AS_min; safety_AS_max]
            G = matrix(np.array([[-1.0], [1.0]]), tc='d')
            h = matrix(np.array([[safety_AS_min], [safety_AS_max]]), tc='d')

        try:
            # cvxopt solver
            ## minimize (1/2)*x*P*x + q*x
            ## subject to: G*x < h
            sol = solvers.qp(P, q, G, h)
            
        except:
            print("exception: {}".format(exception))
            
            # discrete control parameter
            opt_AS_i = 0
            print("opt_AS_i: {}\n".format(opt_AS_i))
        
        else:
            # extract optimal value and solution
            status = sol['status']
            opt_AS_i = sol['x'][0]
            costFunction = sol['primal objective']
            print("status({}): {}".format(index, status))
            print("opt_AS_i({}): {}".format(index, opt_AS_i))
            # print("costFunction({}): {}\n".format(index, costFunction))
            
            # discrete control parameter
            if status == "optimal":
                opt_AS_i = min(max(int(np.floor(opt_AS_i)), int(safety_AS_min)), int(safety_AS_max))
            else:
                opt_AS_i = 0
            print("opt_AS_i: {}\n".format(opt_AS_i))
            
        # handling opt_AS = 0 with active_flag = 1
        if self.active_flag[index] > 0 and opt_AS_i == 0:
            # reset auxiliary signal trigger
            self.active_flag[index] = 0

            # reset prior model parameter
            self.B_k_prior[index][index] = self.B.T[index][index]
            self.P_k_prior[index][index] = 1.0e-05
            
        return opt_AS_i

    def set_sliding_window_size(self, sliding_window_size):
        
        self.sliding_window_size = sliding_window_size

    def set_error_threshold(self, error_threshold_str):
        error_threshold_vec = error_threshold_str.strip().split(",")
        for index in range(0, 6):
            self.error_threshold[index] = float(error_threshold_vec[index])

    def get_B_k_prior(self):
        return self.B_k_prior

    def get_P_k_prior(self):
        return self.P_k_prior
    
    def get_avg_error_dist(self):
        return self.avg_error_dist
    
    def get_active_flag(self):
        return self.active_flag

    def get_opt_AS(self):
        return self.opt_AS
    
    def transferToString(self, B_k_prior, P_k_prior, avg_error_dist, alarm, active_flag, opt_AS):
        B_k_prior_str = ""
        for index in range(0, 6):
            B_k_prior_str = B_k_prior_str + str(B_k_prior[index][index]) + ","
        B_k_prior_str = B_k_prior_str + str(B_k_prior[5][5])   
        
        P_k_prior_str = ""
        for index in range(0, 6):
            P_k_prior_str = P_k_prior_str + str(P_k_prior[index][index]) + ","
        P_k_prior_str = P_k_prior_str + str(P_k_prior[5][5])    
        
        avg_error_dist_str = ""
        for index in range(0, 6):
            avg_error_dist_str = avg_error_dist_str + str(avg_error_dist[index]) + ","
        avg_error_dist_str = avg_error_dist_str + str(avg_error_dist[5])     
        
        alarm_str = ""
        for index in range(0, 6):
            alarm_str = alarm_str + str(int(alarm[index])) + ","
        alarm_str = alarm_str + str(int(alarm[5]))        
 
        active_flag_str = ""
        for index in range(0, 6):
            active_flag_str = active_flag_str + str(int(active_flag[index])) + ","
        active_flag_str = active_flag_str + str(int(active_flag[5]))            
      
        opt_AS_str = ""
        for index in range(0, 6):
            opt_AS_str = opt_AS_str + str(int(opt_AS[index])) + ","
        opt_AS_str = opt_AS_str + str(int(opt_AS[5]))                              
        
        return B_k_prior_str, P_k_prior_str, avg_error_dist_str, alarm_str, active_flag_str, opt_AS_str
    

if __name__ == "__main__":
    print("SWDetector_plus...")

    detector = SWDetector_Plus(True)
    detector.set_error_threshold("0.1,0.1,0.1,0.1,0.1,0.1")

    n = 400
    freq = 5
    for k in range(0, n):
        U_str = str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq)
        Y_str = "0.991508,0.996441,0.992127,0.978251,0.996470,0.921172"
        print("k={}, U_str={}, Y_str={}".format(k, U_str, Y_str))

        B_k_prior_str, P_k_prior_str, avg_error_dist_str, \
        alarm_str, active_flag_str, opt_AS_str = detector.deviation_detector(U_str, Y_str)
        
        print("B_k_prior_str={}".format(B_k_prior_str))
        print("P_k_prior_str={}".format(P_k_prior_str))
        print("avg_error_dist_str={}".format(avg_error_dist_str))
        print("alarm_str={}".format(alarm_str))
        print("active_flag_str={}".format(active_flag_str))
        print("opt_AS_str={}\n".format(opt_AS_str))