#ifndef ENACTOR_HPP
#define ENACTOR_HPP

#include <map>
#include <deque>

#include <iostream>
#include <fstream>

#include <stdlib.h>
#include <sys/stat.h>
#include <cstdio>

#include "ros/ros.h"
#include "ros/package.h"

#include "libbsn/utils/utils.hpp"

#include "archlib/Status.h"
#include "archlib/Event.h"
#include "archlib/Strategy.h"
#include "archlib/Exception.h"
#include "archlib/AdaptationCommand.h"

#include "Observation.hpp"      
#include <python3.8/Python.h>

#include "archlib/DataAccessRequest.h"
#include "archlib/EngineRequest.h"

#include "archlib/ROSComponent.hpp"

class Enactor : public arch::ROSComponent {
    public:
    	Enactor(int &argc, char **argv, std::string name);
    	virtual ~Enactor();	

    private:
      	Enactor(const Enactor &);	
    	Enactor &operator=(const Enactor &);

  	public:
        virtual void setUp() = 0;
    	virtual void tearDown();
		virtual void body();

	  	void receiveStatus();
	  	void receiveStrategy(const archlib::Strategy::ConstPtr& msg);
		void receiveAdaptationParameter();

	  	virtual void receiveEvent(const archlib::Event::ConstPtr& msg) = 0;
		virtual void apply_cost_strategy(const std::string &component) = 0;

		// General settings
		int warm_time;     // wait all six sensor requst arrivals each loop
		std::string mode;  

        // Identification 
        int sampling_num;
        int sampling_cnt = 0;
		std::vector<int> temp_ident_freqs;
        std::vector<int> ident_g3t1_1_freqs, ident_g3t1_2_freqs, ident_g3t1_3_freqs, ident_g3t1_4_freqs, ident_g3t1_5_freqs, ident_g3t1_6_freqs;

        void loadSamplingFreqs();

		// Control
		int time_window; 

		double setpoint;
		std::map<std::string, double> nominal_B;
		double pole;

		int min_freq;
		int max_freq;
		int max_delta_freq;

		// Model deviation
		int deviation_trigger;
		int deviation_time;
		std::map<std::string, int> injection_flag;
		std::map<std::string, int> deviation_freq;

		// Supervision 
        int logging = 0;
		std::string supervision_type; // SWDetectorPlus,ARMAPlus,MoD2Plus

       	PyObject *pInstance;
		std::string sup_components[6];
		int sup_freqs[6];
		double sup_costs[6];

		void deviationDetector(std::string sup_components[], int sup_freqs[], double sup_cost[]);
		
		// SWDetectorPlus and ARMA
		int sliding_window_size;
        std::string error_threshold_str;

        // MoD2Plus
        std::string AS_trigger_mode; 
        std::string AS_design_mode; 
        int timing_interval; 
        int rnd_seed; 
		int alarm[6] = {0};

		// Auxiliary signal
		std::map<std::string, int> activeFlag;
		std::map<std::string, int> optAS;

		// Recovery auxiliary signal
		std::map<std::string, int> recoveryAS;
		std::map<std::string, int> timer;
		int stable_loop;

		// Tracing
		int data_tracing;
		
		int time_ref;
        int nowInMilliSecond() const;

		std::vector<Observation> g3t1_vec;

        std::fstream fp;
		std::string g3t1_plant_filepath;
		std::string g3t1_detector_filepath;
		std::string g3t1_1_plant_filepath, g3t1_2_plant_filepath, g3t1_3_plant_filepath, g3t1_4_plant_filepath, g3t1_5_plant_filepath, g3t1_6_plant_filepath;
		std::string g3t1_1_detector_filepath, g3t1_2_detector_filepath, g3t1_3_detector_filepath, g3t1_4_detector_filepath, g3t1_5_detector_filepath, g3t1_6_detector_filepath;

		void flush();

	protected:
		ros::Publisher adapt;
		ros::Publisher except;

		std::map<std::string, std::deque<int>> invocations; //a map of deques where 1s represent successes and 0s represents failures
		std::map<std::string, int> exception_buffer;
		std::map<std::string, double> freq_double;
		std::map<std::string, int> freq;
		std::map<std::string, double> curr_value;
		std::map<std::string, double> ref_value;
		std::map<std::string, int> replicate_task;

		int64_t cycles;
		double stability_margin;
		std::string adaptation_parameter;
};

#endif 