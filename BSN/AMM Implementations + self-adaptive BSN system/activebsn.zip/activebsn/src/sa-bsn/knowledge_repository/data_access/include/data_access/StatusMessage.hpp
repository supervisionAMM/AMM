#ifndef STATUS_MESSAGE_HPP
#define STATUS_MESSAGE_HPP

#include <string>

class StatusMessage {

    public:
	StatusMessage(const std::string &name, const int &timestamp, const std::string &source, const std::string &target, const int &freq, const std::string &state) : name(name), timestamp(timestamp), source(source), target(target), freq(freq), state(state){};
        
        std::string getName() const { return this->name;};
        int getTimestamp() const {return this->timestamp;};
        std::string getSource() const {return this->source;};
        std::string getTarget() const {return this->target;};
        int getFreq() const {return this->freq;};
        std::string getState() const {return this->state;};

    private:
        std::string name;
        int timestamp;
        std::string source;
        std::string target;
        int freq;
        std::string state;
};

#endif 