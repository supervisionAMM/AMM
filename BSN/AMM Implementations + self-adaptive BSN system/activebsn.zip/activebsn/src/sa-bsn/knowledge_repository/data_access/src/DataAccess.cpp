#include "data_access/DataAccess.hpp"

#define W(x) std::cerr << #x << " = " << x << std::endl;

DataAccess::DataAccess(int  &argc, char **argv, const std::string &name) : ROSComponent(argc, argv, name), buffer_size(), reliability_formula(), cost_formula() {}

DataAccess::~DataAccess() {}

std::string fetch_formula(std::string name){
    std::string formula;
    std::string path = ros::package::getPath("repository");
    
    std::string filename = "/../resource/models/" + name + ".formula";
    try{
        std::ifstream file;
        file.open(path + filename);
        std::getline(file, formula);
        file.close();
    } catch (std::ifstream::failure e) { 
        std::cerr << "Error: Could not load " + name +  " formula into memory\n"; 
    }

    return formula;
}

void DataAccess::setUp() {
    // Observation noise
    handle.getParam("uncertainty_trigger", uncertainty_trigger);
    handle.getParam("random_seed", random_seed);
    handle.getParam("sensor_noise_sigma", sensor_noise_sigma);
    
    ONGenerator = std::normal_distribution<double> (0.0, sensor_noise_sigma);
    if (random_seed == -1) {
        std::random_device rd;
        rng.seed(rd());

    } else if (random_seed >= 0) {
        rng.seed(random_seed);
    }

    // Tracing 
    handle.getParam("data_tracing", data_tracing);

    int warm_second_time;
    handle.getParam("warm_time", warm_second_time); 
    warm_time = warm_second_time * 1000;

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("repository") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing == 1) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        event_filepath = trace_dir + "/dataAccess_event_trace.txt";
        status_filepath = trace_dir + "/dataAccess_status_trace.txt";

        g3t1_1_energy_status_filepath = trace_dir + "/dataAccess_g3t1_1_energy_status_trace.txt";
        g3t1_2_energy_status_filepath = trace_dir + "/dataAccess_g3t1_2_energy_status_trace.txt";
        g3t1_3_energy_status_filepath = trace_dir + "/dataAccess_g3t1_3_energy_status_trace.txt";
        g3t1_4_energy_status_filepath = trace_dir + "/dataAccess_g3t1_4_energy_status_trace.txt";
        g3t1_5_energy_status_filepath = trace_dir + "/dataAccess_g3t1_5_energy_status_trace.txt";
        g3t1_6_energy_status_filepath = trace_dir + "/dataAccess_g3t1_6_energy_status_trace.txt";

        g3t1_1_adaptation_filepath = trace_dir + "/dataAccess_g3t1_1_adaptation_trace.txt";
        g3t1_2_adaptation_filepath = trace_dir + "/dataAccess_g3t1_2_adaptation_trace.txt";
        g3t1_3_adaptation_filepath = trace_dir + "/dataAccess_g3t1_3_adaptation_trace.txt";
        g3t1_4_adaptation_filepath = trace_dir + "/dataAccess_g3t1_4_adaptation_trace.txt";
        g3t1_5_adaptation_filepath = trace_dir + "/dataAccess_g3t1_5_adaptation_trace.txt";
        g3t1_6_adaptation_filepath = trace_dir + "/dataAccess_g3t1_6_adaptation_trace.txt"; 

        engine_cost_filepath = trace_dir + "/dataAccess_engine_cost_trace.txt";
        enactor_cost_filepath = trace_dir + "/dataAccess_enactor_cost_trace.txt";

        enactor_g3t1_1_window_filepath = trace_dir + "/enactor_g3t1_1_window_trace.txt";
        enactor_g3t1_2_window_filepath = trace_dir + "/enactor_g3t1_2_window_trace.txt";
        enactor_g3t1_3_window_filepath = trace_dir + "/enactor_g3t1_3_window_trace.txt";
        enactor_g3t1_4_window_filepath = trace_dir + "/enactor_g3t1_4_window_trace.txt";
        enactor_g3t1_5_window_filepath = trace_dir + "/enactor_g3t1_5_window_trace.txt";
        enactor_g3t1_6_window_filepath = trace_dir + "/enactor_g3t1_6_window_trace.txt";
        
        // Event
        fp.open(event_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),name,source,target,freq,event\n";
        fp.close();

        // Status
        fp.open(status_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),name,source,target,freq,state\n";
        fp.close();

        // Energy status filepath
        for (int index=0; index<6; index++) {
            if (index == 0) {fp.open(g3t1_1_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 1) {fp.open(g3t1_2_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 2) {fp.open(g3t1_3_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 3) {fp.open(g3t1_4_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 4) {fp.open(g3t1_5_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 5) {fp.open(g3t1_6_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

            fp << "time_second,timestamp(ms),name,source,target,freq,content\n";
            fp.close();
        }

        // Adaptation filepath
        for (int index=0; index<6; index++) {
            if (index == 0) {fp.open(g3t1_1_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 1) {fp.open(g3t1_2_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 2) {fp.open(g3t1_3_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 3) {fp.open(g3t1_4_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 4) {fp.open(g3t1_5_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 5) {fp.open(g3t1_6_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

            fp << "time_second,timestamp(ms),name,source,target,action\n";
            fp.close();
        }  

        // Cost filepath     
        fp.open(engine_cost_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),name,query,content\n";
        fp.close();     

        fp.open(enactor_cost_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),name,query,content\n";
        fp.close();   

        // Enactor cost time window filepath   
        for (int index=0; index<6; index++) {
            if (index == 0) {fp.open(enactor_g3t1_1_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 1) {fp.open(enactor_g3t1_2_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 2) {fp.open(enactor_g3t1_3_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 3) {fp.open(enactor_g3t1_4_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 4) {fp.open(enactor_g3t1_5_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 5) {fp.open(enactor_g3t1_6_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

            fp << "time_second,timestamp(ms),content\n";
            fp.close();        
        }              
    }

	handle.getParam("frequency", frequency);
    rosComponentDescriptor.setFreq(frequency);

    buffer_size = 1000;

    reliability_formula = fetch_formula("reliability");
    cost_formula = fetch_formula("cost");
    
    count_to_calc_and_reset = 0;

    components_batteries["g3t1_1"] = 100;
    components_batteries["g3t1_2"] = 100;
    components_batteries["g3t1_3"] = 100;
    components_batteries["g3t1_4"] = 100;
    components_batteries["g3t1_5"] = 100;
    components_batteries["g3t1_6"] = 100;
    components_reliabilities["g3t1_1"] = 1;
    components_reliabilities["g3t1_2"] = 1;
    components_reliabilities["g3t1_3"] = 1;
    components_reliabilities["g3t1_4"] = 1;
    components_reliabilities["g3t1_5"] = 1;
    components_reliabilities["g3t1_6"] = 1;
    
    targetSystemSub = handle.subscribe("TargetSystemData", 1000, &DataAccess::processTargetSystemData, this);
    handle_persist = handle.subscribe("persist", 1000, &DataAccess::receivePersistMessage, this);
    server = handle.advertiseService("DataAccessRequest", &DataAccess::processQuery, this);
}

void DataAccess::tearDown(){}

void DataAccess::body() {
    count_to_fetch++;
    count_to_calc_and_reset++;
    frequency = rosComponentDescriptor.getFreq();

    if (count_to_calc_and_reset >= frequency) {
        // applyTimeWindowCost();
        count_to_calc_and_reset = 0;
    }

    if (count_to_fetch >= frequency*10){
        reliability_formula = fetch_formula("reliability");
        cost_formula = fetch_formula("cost");

        count_to_fetch = 0;
    }

    ros::spinOnce();
}

void DataAccess::processTargetSystemData(const messages::TargetSystemData::ConstPtr& msg) {
    components_batteries["g3t1_1"] = msg->trm_batt;
    components_batteries["g3t1_2"] = msg->ecg_batt;
    components_batteries["g3t1_3"] = msg->oxi_batt;
    components_batteries["g3t1_4"] = msg->abps_batt;
    components_batteries["g3t1_5"] = msg->abpd_batt;
    components_batteries["g3t1_6"] = msg->glc_batt;
}

void DataAccess::receivePersistMessage(const archlib::Persist::ConstPtr& msg) {
    // ROS_INFO("I heard: [%s]", msg->type.c_str());

    if (msg->type=="Event") {
        // std::cout << "timestamp=" << msg->timestamp << " source=" << msg->source << " content=" << msg->content << std::endl;
    
        // "/g3t1_X:activate/deactivate"
        if (msg->source != "/g4t1") {
            if (data_tracing == 1) {
                persistEvent(msg->timestamp, msg->source, msg->target, msg->freq, msg->content);
            }

            if (events[msg->source].size()<=buffer_size) {
                events[msg->source].push_back(msg->content);
            } else {
                events[msg->source].pop_front();
                events[msg->source].push_back(msg->content);
            }

            std::string key = msg->source;
            key = key.substr(1, key.size());
            contexts[key] = msg->content == "activate" ? 1 : 0;
        }

    } else if (msg->type == "Status") { 
        // std::cout << "timestamp=" << msg->timestamp << " source=" << msg->source << " content=" << msg->content << std::endl;
    
        // "/g3t1_X:init/running/success/fail"
        if (msg->source != "/g4t1") {
            if (data_tracing == 1) {
                persistStatus(msg->timestamp, msg->source, msg->target, msg->freq, msg->content);
            }

            status[msg->source].push_back({msg->timestamp, msg->freq, msg->content});
        }

    } else if (msg->type == "EnergyStatus") {
        // std::cout << "timestamp=" << msg->timestamp << " source=" << msg->source << " content=" << msg->content << std::endl;

        // "/g3t1_X:0.15"
        if (msg->source != "/g4t1" && msg->source != "/engine") {
            if (data_tracing == 1) {
                persistEnergyStatus(msg->timestamp, msg->source, msg->target, msg->freq, msg->content);
            }

            energystatus[msg->source].push_back({msg->timestamp, msg->freq, msg->content});
        }

    } else if (msg->type=="AdaptationCommand") {
        // std::cout << "timestamp=" << msg->timestamp << " source=" << msg->source << " content=" << msg->content << std::endl;
        
        // "/g3t1_X:freq=1"
        if (msg->source != "/g4t1") {
            if (data_tracing == 1) {
                persistAdaptation(msg->timestamp, msg->source, msg->target, msg->content);
            }
        }

    } else {
        ROS_INFO("(Could not identify message type!!)");
    }
}

bool DataAccess::processQuery(archlib::DataAccessRequest::Request &req, archlib::DataAccessRequest::Response &res){
    res.content = "";

    timestamp = req.timestamp;   
    try {
        if (req.name == "/engine" || req.name == "/enactor") {
            std::vector<std::string> query = bsn::utils::split(req.query,':');

            // wait smth like "reliability_formula"/"cost_formula" from "/engine"
            // response smth with formula
            if (query.size() == 1){
                if (query[0] == "reliability_formula") {
                    res.content = reliability_formula;
                } else if (query[0] == "cost_formula") {
                    res.content = cost_formula;
                } 

                // std::cout << "req.name=" << req.name  << " query=" << req.query << std::endl;
                // std::cout << "res.content=" << res.content << std::endl;
            }

            if (query.size() > 1){
                if (query[1] == "event") {
                    // wait smth like "all:event:XXX" from "/engine" -> return first XXX events
                    // response smth like "/g3t1_1:activate,...,activate;/g3t1_2:deactivate,...,deactivate;..."
                    int num = stoi(query[2]);
                    for (std::map<std::string, std::deque<std::string>>::iterator it = events.begin(); it != events.end(); it++){
                        std::string aux = it->first;
                        aux += ":";
                        bool flag = false;
                        std::string content = "";
                        for(int i = it->second.size()-num; i < it->second.size(); ++i){
                            flag = true;
                            aux += it->second[i];
                            content += it->second[i];
                            
                            if (i + 1 < it->second.size()){aux += ",";}
                        }
                        aux += ";";

                        if (flag) {
                            std::string key = it->first;
                            key = key.substr(1, key.size());
                            contexts[key] = content == "activate" ? 1 : 0;
                            res.content += aux;
                        }
                    }

                    // std::cout << "req.name=" << req.name  << " query=" << req.query << std::endl;
                    // std::cout << "res.content=" << res.content << std::endl;

                } else if (query[1] == "reliability") {
                    // wait smth like "all:reliability:XXX" from "/enactor" -> return component reliability within the lastest XXX seconds
                    // response smth like "/g3t1_1:0.85;/g3t1_2:0.90;..."
                    time_window = stoi(query[2]);    
                    applyTimeWindowReliability();
                    for (auto it : status) {
                        res.content += calculateComponentReliability(it.first);
                    }

                    // std::cout << "req.name=" << req.name  << " query=" << req.query << std::endl;
                    // std::cout << "res.content=" << res.content << std::endl;
                   
                } else if (query[1] == "cost") {   
                    // wait smth like "all:cost:XXX" from "/enactor" -> return return component cost within the lastest XXX seconds
                    // response smth like "/g3t1_1:0.9;/g3t1_2:0.9;..."
                    time_window = stoi(query[2]);        
                    applyTimeWindowCost(timestamp, req.name);
                    for (auto it : energystatus) {
                        res.content += calculateComponentCost(it.first);
                    }

                    if (data_tracing == 1 && timestamp >= warm_time) {
                        if (req.name == "/engine") {
                            fp.open(engine_cost_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
                        } else if (req.name == "/enactor") {
                            fp.open(enactor_cost_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
                        }
                        fp << floor(timestamp/1000.0) << ",";  
                        fp << timestamp << ",";  
                        fp << req.name << ",";  
                        fp << req.query << ",";  
                        fp << res.content << "\n";  
                        fp.close();    
                    }                
                }
            }
                                    
        } 
    } catch(...) {}
	
    return true;
}

void DataAccess::persistEvent(const int &timestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content){
    EventMessage obj("Event", timestamp, source, target, freq, content);
    eventVec.push_back(obj);
    flush();
}

void DataAccess::persistStatus(const int &timestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content){
    StatusMessage obj("Status", timestamp, source, target, freq, content);
    statusVec.push_back(obj);   
    flush();
}

void DataAccess::persistEnergyStatus(const int &timestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content){
    EnergyStatusMessage obj("EnergyStatus", timestamp, source, target, freq, content);
    energystatusVec.push_back(obj);
    flush();
}

void DataAccess::persistAdaptation(const int &timestamp, const std::string &source, const std::string &target, const std::string &content){
    AdaptationMessage obj("Adaptation", timestamp, source, target, content);
    adaptVec.push_back(obj);
    flush();
}

void DataAccess::flush(){
    fp.open(event_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
    for(std::vector<EventMessage>::iterator it = eventVec.begin(); it != eventVec.end(); ++it) {
        fp << floor((*it).getTimestamp()/1000.0) << ",";   
        fp << (*it).getTimestamp() << ",";        
        fp << (*it).getName() << ",";
        fp << (*it).getSource() << ",";
        fp << (*it).getTarget() << ",";
        fp << (*it).getFreq() << ",";
        fp << (*it).getEvent() << "\n";
    }
    fp.close();
    eventVec.clear();

    fp.open(status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
    for(std::vector<StatusMessage>::iterator it = statusVec.begin(); it != statusVec.end(); ++it) {
        fp << floor((*it).getTimestamp()/1000.0) << ",";   
        fp << (*it).getTimestamp() << ",";     
        fp << (*it).getName() << ",";
        fp << (*it).getSource() << ",";
        fp << (*it).getTarget() << ",";
        fp << (*it).getFreq() << ",";
        fp << (*it).getState() << "\n";
    }
    fp.close();
    statusVec.clear();

    for(std::vector<EnergyStatusMessage>::iterator it = energystatusVec.begin(); it != energystatusVec.end(); ++it) {
        if ((*it).getSource() == "/g3t1_1") {fp.open(g3t1_1_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_2") {fp.open(g3t1_2_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_3") {fp.open(g3t1_3_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_4") {fp.open(g3t1_4_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_5") {fp.open(g3t1_5_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_6") {fp.open(g3t1_6_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

        fp << floor((*it).getTimestamp()/1000.0) << ",";   
        fp << (*it).getTimestamp() << ",";       
        fp << (*it).getName() << ",";
        fp << (*it).getSource() << ",";
        fp << (*it).getTarget() << ",";
        fp << (*it).getFreq() << ",";
        fp << (*it).getCost() << "\n";
        fp.close();
    }
    energystatusVec.clear();

    for(std::vector<AdaptationMessage>::iterator it = adaptVec.begin(); it != adaptVec.end(); ++it) {
        if ((*it).getTarget() == "/g3t1_1") {fp.open(g3t1_1_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_2") {fp.open(g3t1_2_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_3") {fp.open(g3t1_3_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_4") {fp.open(g3t1_4_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_5") {fp.open(g3t1_5_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_6") {fp.open(g3t1_6_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
   
        fp << floor((*it).getTimestamp()/1000.0) << ",";   
        fp << (*it).getTimestamp() << ",";              
        fp << (*it).getName() << ",";
        fp << (*it).getSource() << ",";
        fp << (*it).getTarget() << ",";
        fp << (*it).getContent() << "\n";
        fp.close();
    }
    adaptVec.clear();
}

/**
 * Builds the response string and calculate the reliability
 * of the component specified as parameter
*/
std::string DataAccess::calculateComponentReliability(const std::string& component) {
    std::string aux = component, content = "";
    aux += ":";
    bool flag = false;
    double sum = 0;
    int len = 0;
    
    for (auto value : status[component]) {
        // reliability = success/(success + fails)
        std::string thirdValue = std::get<2>(value);
        if (thirdValue == "success") { // calculate reliability
            sum += 1;
            len++;
        } else if (thirdValue == "fail") {
            len++;
        } 

        flag = true;
    }
    aux += std::to_string((len > 0) ? sum / len : 0) + ';';

    std::string key = component;
    key = key.substr(1, key.size());

    if(flag) content += aux;

    components_reliabilities[key] = (len > 0) ? sum / len : 0;

    return content;
}

/**
 * Builds the response string and calculate the cost
 * of the component specified as parameter
*/
std::string DataAccess::calculateComponentCost(const std::string& component) {
    std::string aux = component, content = "";
    aux += ":";
    bool flag = false;
    double sum = 0;

    for (auto value : energystatus[component]) {
        std::string thirdValue = std::get<2>(value);
        sum += stod(thirdValue);
        
        flag = true;
    }

    // sensor noise
    if (uncertainty_trigger == 1) {
        sensor_noise_offset = ONGenerator(rng);
        sum = sum + sensor_noise_offset;
    }
    aux += std::to_string(sum) + ';';

    std::string key = component;
    key = key.substr(1, key.size());

    if(flag) content += aux;

    components_costs[key] = sum;

    return content;
}

void DataAccess::applyTimeWindowReliability() {
    for (auto& component : status) {
        auto& deq = component.second;  

        // Window size
        int freq = std::get<1>(deq.back());
        int windowSize = time_window * freq;

        while (!deq.empty()) {
            if (deq.size() > windowSize) {
                deq.pop_front();
            } else {
                component.second = deq;
                break;
            }
        }
    }
}

void DataAccess::applyTimeWindowCost(const int& timestamp, const std::string& requestName) {
    for (auto& component : energystatus) {
        auto& deq = component.second;  

        // Window size
        int freq = std::get<1>(deq.back());
        int windowSize = time_window * freq;

        while (!deq.empty()) {
            if (deq.size() > windowSize) {
                deq.pop_front();
            } else {
                component.second = deq;
                break;
            }
        }

        // Tracing
        if (data_tracing == 1 && requestName == "/enactor" && timestamp >= warm_time) {
            if (component.first == "/g3t1_1") {fp.open(enactor_g3t1_1_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
            else if (component.first == "/g3t1_2") {fp.open(enactor_g3t1_2_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (component.first == "/g3t1_3") {fp.open(enactor_g3t1_3_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (component.first == "/g3t1_4") {fp.open(enactor_g3t1_4_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (component.first == "/g3t1_5") {fp.open(enactor_g3t1_5_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (component.first == "/g3t1_6") {fp.open(enactor_g3t1_6_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
          
            fp << floor(timestamp/1000.0) << ",";  
            fp << timestamp << ",";  
            fp << component.first << ",";  
            fp << component.second.size();    
            for (auto& value : component.second) {
                fp << ",{"<< std::get<0>(value) << "," << std::get<1>(value) << "," << std::get<2>(value) << "}";     
            }
            fp << "\n"; 
            fp.close();    
        }
    }
}