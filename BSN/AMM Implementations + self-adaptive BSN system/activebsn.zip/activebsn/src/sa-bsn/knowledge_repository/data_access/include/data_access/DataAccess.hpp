#ifndef DATA_ACCESS_HPP
#define DATA_ACCESS_HPP

#include <fstream>
#include <chrono>
#include <deque>

#include <random>
#include <stdint.h>

#include <sys/stat.h>
#include <cstdio>

#include "ros/ros.h"
#include "ros/package.h"

#include "libbsn/goalmodel/Node.hpp"
#include "libbsn/goalmodel/Goal.hpp"
#include "libbsn/goalmodel/Task.hpp"
#include "libbsn/goalmodel/Property.hpp"
#include "libbsn/goalmodel/LeafTask.hpp"
#include "libbsn/goalmodel/Context.hpp"
#include "libbsn/goalmodel/GoalTree.hpp"
#include "libbsn/model/Formula.hpp"
#include "libbsn/utils/utils.hpp"

#include "archlib/Persist.h"
#include "archlib/DataAccessRequest.h"
#include "archlib/ROSComponent.hpp"

#include "EventMessage.hpp"
#include "StatusMessage.hpp"
#include "EnergyStatusMessage.hpp"
#include "AdaptationMessage.hpp"

#include "lepton/Lepton.h"

#include "messages/TargetSystemData.h"

class DataAccess : public arch::ROSComponent {

	public:
		DataAccess(int &argc, char **argv, const std::string &name);
		virtual ~DataAccess();

	private:
		DataAccess(const DataAccess &);
		DataAccess &operator=(const DataAccess &);

		void persistEvent(const int &timestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content);
		void persistStatus(const int &timestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content);
		void persistEnergyStatus(const int &timestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content);
		void persistAdaptation(const int &timestamp, const std::string &source, const std::string &target, const std::string &content);

		void flush();

		std::string calculateComponentReliability(const std::string& component);
		std::string calculateComponentCost(const std::string& component);
		void applyTimeWindowReliability();
		void applyTimeWindowCost(const int& timestamp, const std::string& requestName);

	public:
		virtual void setUp();
		virtual void tearDown();
		virtual void body();

		void processTargetSystemData(const messages::TargetSystemData::ConstPtr& msg);
		void receivePersistMessage(const archlib::Persist::ConstPtr& msg);
		bool processQuery(archlib::DataAccessRequest::Request &req, archlib::DataAccessRequest::Response &res);

	protected:
		ros::NodeHandle handle;
	
	private:
		ros::Subscriber targetSystemSub;
		ros::Subscriber handle_persist;
		ros::ServiceServer server;

		// Evaluation	
		int time_window;

		// Observation noise
		int uncertainty_trigger;
		
		int random_seed;
		std::normal_distribution<double> ONGenerator;
		std::mt19937 rng;

		double sensor_noise_sigma;
		double sensor_noise_offset;

		// Tracing 
		int data_tracing;
		int warm_time;     // wait all six sensor requst arrivals each loop

		std::fstream fp;
		std::string event_filepath;
		std::string status_filepath;

		std::string g3t1_1_energy_status_filepath, g3t1_2_energy_status_filepath, g3t1_3_energy_status_filepath;
		std::string g3t1_4_energy_status_filepath, g3t1_5_energy_status_filepath, g3t1_6_energy_status_filepath;
		std::string g3t1_1_adaptation_filepath, g3t1_2_adaptation_filepath, g3t1_3_adaptation_filepath;
		std::string g3t1_4_adaptation_filepath, g3t1_5_adaptation_filepath, g3t1_6_adaptation_filepath;

		std::string engine_cost_filepath;
		std::string enactor_cost_filepath;
		std::string enactor_g3t1_1_window_filepath, enactor_g3t1_2_window_filepath, enactor_g3t1_3_window_filepath;
		std::string enactor_g3t1_4_window_filepath, enactor_g3t1_5_window_filepath, enactor_g3t1_6_window_filepath;

		std::vector<EventMessage> eventVec;
		std::vector<StatusMessage> statusVec;
		std::vector<EnergyStatusMessage> energystatusVec;
		std::vector<AdaptationMessage> adaptVec;

		std::map<std::string, std::deque<std::string>> events;
		std::map<std::string, std::deque<std::tuple<int, int, std::string>>> status;
		std::map<std::string, std::deque<std::tuple<int, int, std::string>>> energystatus;

		int buffer_size;
		std::map<std::string, uint32_t> contexts;
		std::map<std::string, double> components_batteries;
		std::map<std::string, double> components_reliabilities;
		std::map<std::string, double> components_costs;
		
		std::string reliability_formula;
		std::string cost_formula;

		double frequency;
		int32_t count_to_calc_and_reset;
		int32_t count_to_fetch;
};

#endif 