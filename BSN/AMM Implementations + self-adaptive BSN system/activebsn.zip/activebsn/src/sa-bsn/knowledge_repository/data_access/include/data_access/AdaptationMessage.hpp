#ifndef ADAPTATION_MESSAGE_HPP
#define ADAPTATION_MESSAGE_HPP

#include <string>

class AdaptationMessage {

    public:
        AdaptationMessage(const std::string &name, const int &timestamp, const std::string &source, const std::string &target, const std::string &content) : name(name), timestamp(timestamp), source(source), target(target), content(content){};

        std::string getName() const { return this->name;};
        int getTimestamp() const {return this->timestamp;};
        std::string getSource() const {return this->source;};
        std::string getTarget() const {return this->target;};
        std::string getContent() const {return this->content;};

    private:
        std::string name;
        int timestamp;
        std::string source;
        std::string target;
        std::string content;
};

#endif 