#ifndef EVENT_MESSAGE_HPP
#define EVENT_MESSAGE_HPP

#include <string>

class EventMessage {

    public:
        EventMessage(const std::string &name, const int &timestamp, const std::string &source, const std::string &target, const int &freq, const std::string &event) : name(name), timestamp(timestamp), source(source), target(target), freq(freq), event(event){};

        std::string getName() const { return this->name;};
        int getTimestamp() const {return this->timestamp;};
        std::string getSource() const {return this->source;};
        std::string getTarget() const {return this->target;};
        int getFreq() const {return this->freq;};
        std::string getEvent() const {return this->event;};

    private:
        std::string name;
        int timestamp;
        std::string source;
        std::string target;
        int freq;
        std::string event;
};

#endif 