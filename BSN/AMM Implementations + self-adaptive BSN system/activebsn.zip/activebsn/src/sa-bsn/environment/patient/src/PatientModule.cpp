#include <PatientModule.hpp>

PatientModule::PatientModule(int  &argc, char **argv, std::string name) : ROSComponent(argc, argv, name) {}

PatientModule::~PatientModule() {}

int PatientModule::nowInMilliSecond() const{
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
}

void PatientModule::setUp() {
    // Get start time from timer.txt writen in script
    std::string timer_path = ros::package::getPath("patient") + "/../../timer.txt";

    std::ifstream fin(timer_path);
    if (!fin) {
        ROS_ERROR("Could not read timer.txt.");
    } else {
        std::string timer_str;
        fin >> timer_str;
        time_ref = atoi(timer_str.c_str());
    }
    std::cout << "[setUp] time_ref=" << time_ref << std::endl;

    // Service
    service = nh.advertiseService("getPatientData", &PatientModule::getPatientData, this);

    // Random 
    nh.getParam("random_seed", random_seed);
    seed_count = 0;
    
    // Get and set frequency
    nh.getParam("frequency", frequency);
    rosComponentDescriptor.setFreq(frequency);

    // Get what vital signs this module will simulate
    std::string vitalSigns;
    nh.getParam("vitalSigns", vitalSigns);

    // Removes white spaces from vitalSigns
    vitalSigns.erase(std::remove(vitalSigns.begin(), vitalSigns.end(),' '), vitalSigns.end());

    std::vector<std::string> splittedVitalSigns = bsn::utils::split(vitalSigns, ',');
    double aux;
    for (std::string s : splittedVitalSigns) {
        vitalSignsFrequencies[s] = 0; 
        nh.getParam(s + "_Change", aux);
        vitalSignsChanges[s] = 1/aux;
        nh.getParam(s + "_Offset", vitalSignsOffsets[s]);

        // Tracing 
        sensorFreqs[s] = 0; 
    }

    for (const std::string& s : splittedVitalSigns) {
        patientData[s] = configureDataGenerator(s);
    }

    // Tracing 
    nh.getParam("data_tracing", data_tracing);

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("patient") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing == 1) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        patient_g3t1_1_filepath = trace_dir + "/patient_g3t1_1_oxigenation_trace.txt";
        fp.open(patient_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),vitalSign,sensor_freq,sensor_data\n";
        fp.close();

        patient_g3t1_2_filepath = trace_dir + "/patient_g3t1_2_heart_rate_trace.txt";
        fp.open(patient_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),vitalSign,sensor_freq,sensor_data\n";
        fp.close();

        patient_g3t1_3_filepath = trace_dir + "/patient_g3t1_3_temperature_trace.txt";
        fp.open(patient_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),vitalSign,sensor_freq,sensor_data\n";
        fp.close();

        patient_g3t1_4_filepath = trace_dir + "/patient_g3t1_4_abps_trace.txt";
        fp.open(patient_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),vitalSign,sensor_freq,sensor_data\n";
        fp.close();

        patient_g3t1_5_filepath = trace_dir + "/patient_g3t1_5_abpd_trace.txt";
        fp.open(patient_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),vitalSign,sensor_freq,sensor_data\n";
        fp.close();

        patient_g3t1_6_filepath = trace_dir + "/patient_g3t1_6_glucose_trace.txt";
        fp.open(patient_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),vitalSign,sensor_freq,sensor_data\n";
        fp.close();
    }    
}

bsn::generator::DataGenerator PatientModule::configureDataGenerator(const std::string& vitalSign) {
    std::vector<std::string> t_probs;
    std::array<float, 25> transitions;
    std::array<bsn::range::Range,5> ranges;
    std::array<std::uniform_real_distribution<double>,5> valueGenerators;
    std::string s;
    ros::NodeHandle handle;

    // std::cout << vitalSign << std::endl;
    for(uint32_t i = 0; i < transitions.size(); i++){
        for(uint32_t j = 0; j < 5; j++){
            handle.getParam(vitalSign + "_State" + std::to_string(j), s);
            t_probs = bsn::utils::split(s, ',');
            for(uint32_t k = 0; k < 5; k++){
                transitions[i++] = std::stod(t_probs[k]);
            }
        }
    }
    
    std::vector<std::string> lrs,mrs0,hrs0,mrs1,hrs1;

    handle.getParam(vitalSign + "_LowRisk", s);
    lrs = bsn::utils::split(s, ',');
    handle.getParam(vitalSign + "_MidRisk0", s);
    mrs0 = bsn::utils::split(s, ',');
    handle.getParam(vitalSign + "_HighRisk0", s);
    hrs0 = bsn::utils::split(s, ',');
    handle.getParam(vitalSign + "_MidRisk1", s);
    mrs1 = bsn::utils::split(s, ',');
    handle.getParam(vitalSign + "_HighRisk1", s);
    hrs1 = bsn::utils::split(s, ',');

    ranges[0] = bsn::range::Range(std::stod(hrs0[0]), std::stod(hrs0[1]));
    ranges[1] = bsn::range::Range(std::stod(mrs0[0]), std::stod(mrs0[1]));
    ranges[2] = bsn::range::Range(std::stod(lrs[0]), std::stod(lrs[1]));
    ranges[3] = bsn::range::Range(std::stod(mrs1[0]), std::stod(mrs1[1]));
    ranges[4] = bsn::range::Range(std::stod(hrs1[0]), std::stod(hrs1[1]));
  
     // State transition probability generator
    std::uniform_int_distribution<int> probabilityGenerator(1,100);

    // Value generators
    valueGenerators[0] = std::uniform_real_distribution<double> (ranges[0].getLowerBound(), ranges[0].getUpperBound());
    valueGenerators[1] = std::uniform_real_distribution<double> (ranges[1].getLowerBound(), ranges[1].getUpperBound());
    valueGenerators[2] = std::uniform_real_distribution<double> (ranges[2].getLowerBound(), ranges[2].getUpperBound());
    valueGenerators[3] = std::uniform_real_distribution<double> (ranges[3].getLowerBound(), ranges[3].getUpperBound());
    valueGenerators[4] = std::uniform_real_distribution<double> (ranges[4].getLowerBound(), ranges[4].getUpperBound());

    // Random  
    std::mt19937 rng;
    if (random_seed == -1) {
        std::random_device rd;
        rng.seed(rd());

    } else if (random_seed >= 0) {
        int dataSeed = 10000 + 1000*seed_count + random_seed;
        rng.seed(dataSeed);
    }
    seed_count += 1;

    bsn::generator::Markov markov(transitions, ranges, 2);
    bsn::generator::DataGenerator dataGenerator(markov, probabilityGenerator, valueGenerators, rng);

    return dataGenerator;
}

void PatientModule::tearDown() {}

bool PatientModule::getPatientData(services::PatientData::Request &request, 
                                   services::PatientData::Response &response) {

    int timestamp = this->nowInMilliSecond() - time_ref; 

    // Request
    sensorFreqs[request.vitalSign] = request.sensorFreq; 

    // Response
    response.timestamp = timestamp;
    response.data = patientData[request.vitalSign].getValue();

    std::cout << "Send " + request.vitalSign + " data." << std::endl;

    // Tracing   
    if (data_tracing == 1) {
        if (request.vitalSign == "oxigenation") {fp.open(patient_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
        else if (request.vitalSign == "heart_rate") {fp.open(patient_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
        else if (request.vitalSign == "temperature") {fp.open(patient_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
        else if (request.vitalSign == "abps") {fp.open(patient_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (request.vitalSign == "abpd") {fp.open(patient_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (request.vitalSign == "glucose") {fp.open(patient_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

        fp << floor(response.timestamp/1000.0) << ",";
        fp << response.timestamp << ",";
        fp << request.vitalSign << ",";
        fp << request.sensorFreq << ",";     
        fp << response.data << "\n";            
        fp.close();         
    }

    return true;
}

void PatientModule::body() {
    for (auto &p : vitalSignsFrequencies) {
        int randomNumber = -1;

        if (p.second >= (vitalSignsChanges[p.first] + vitalSignsOffsets[p.first])) {
            randomNumber = patientData[p.first].nextState();
            p.second = vitalSignsOffsets[p.first];

            std::cout << "Changed " + p.first + " state." << std::endl;

            // Tracing        
            int timestamp = this->nowInMilliSecond() - time_ref;
            if (data_tracing == 1) {
                if (p.first == "oxigenation") {fp.open(patient_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
                else if (p.first == "heart_rate") {fp.open(patient_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
                else if (p.first == "temperature") {fp.open(patient_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
                else if (p.first == "abps") {fp.open(patient_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                else if (p.first == "abpd") {fp.open(patient_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                else if (p.first == "glucose") {fp.open(patient_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

                fp << floor(timestamp/1000.0) << ",";
                fp << timestamp << ",";
                fp << randomNumber << ",";   
                fp << "Changed " + p.first + " state.\n";         
                fp.close();    
            }

        } else {
            if (sensorFreqs[p.first] > 0) {
                p.second += (1.0/sensorFreqs[p.first]);
                sensorFreqs[p.first] = 0;
            }
        }
    }
}