#include "Injector.hpp"

Injector::Injector(int  &argc, char **argv, const std::string &name) : ROSComponent(argc, argv, name) {}

Injector::~Injector() {}

void Injector::setUp() {
    
    // Service
    service = handle.advertiseService("getInjectorData", &Injector::getInjectorData, this);

    // Get and set configs
    ros::NodeHandle config;

    config.getParam("random_seed", random_seed);
    seed_count = 0;
    
    double freq;
    config.getParam("frequency", freq);
    rosComponentDescriptor.setFreq(freq);

    std::string comps;
    config.getParam("components", comps);
    components = bsn::utils::split(comps, ',');

    int seedCount = 1;
    for (std::vector<std::string>::iterator component = components.begin(); component != components.end(); ++component){
        std::string step_str;
        config.getParam((*component) + "/step", step_str);
        // std::cout << "[setUp] step_str=" << step_str << std::endl;
        
        // Steps
        stepState[*component] = 0;
        std::vector<std::string> stepPairs = bsn::utils::split(step_str, ';');
        for (auto s : stepPairs) {
            std::vector<std::string> pair = bsn::utils::split(s, ',');
            int start = stoi(pair[0]);
            int end = stoi(pair[1]);

            std::uniform_int_distribution<int> stepGenerator(start, end);

            std::mt19937 stepRNG;
            if (random_seed == -1) {
                std::random_device rd;
                stepRNG.seed(rd());
                
            } else if (random_seed >= 0) {
                stepRNG.seed(seedCount*1000 + random_seed);
            }

            int stepTime = stepGenerator(stepRNG)*1000;
            std::cout << "[setUp] stepTime=" << stepTime << std::endl;

            Step[*component].push_back(stepTime);
        }

        // Normal distribution: mean
        std::string mu_str;
        config.getParam((*component) + "/mu", mu_str); 
        // std::cout << "[setUp] mu_str=" << mu_str << std::endl;

        std::vector<std::string> muPairs = bsn::utils::split(mu_str, ';');
        for (auto s : muPairs) {
            std::vector<std::string> pair = bsn::utils::split(s, ',');
            double lowerBound = stod(pair[0]);
            double upperBound = stod(pair[1]);

            std::uniform_real_distribution<double> muGenerator(lowerBound, upperBound);

            std::mt19937 muRNG;
            if (random_seed == -1) {
                std::random_device rd;
                muRNG.seed(rd());
                
            } else if (random_seed >= 0) {
                muRNG.seed(seedCount*1000 + random_seed);
            }

            double muValue = muGenerator(muRNG);
            std::cout << "[setUp] mu=" << muValue << std::endl;

            Mu[*component].push_back(muValue);
        }
       
        seedCount += 1;

        // Normal distribution: variance
        std::string sigma_str;
        config.getParam((*component) + "/sigma", sigma_str); 
        // std::cout << "[setUp] sigma_str=" << sigma_str << std::endl;

        std::vector<std::string> sigmaPairs = bsn::utils::split(sigma_str, ';');
        for (auto s : sigmaPairs) {
            double sigmaValue = stod(s);
            std::cout << "[setUp] sigma=" << sigmaValue << std::endl;

            Sigma[*component].push_back(sigmaValue);
        }
        
        // Evaluation
        injectorData[*component] = configureNoiseGenerator(*component);
        noiseCount[*component] = 0;
    }

    // Tracing 
    config.getParam("data_tracing", data_tracing);

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("injector") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing == 1) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        injector_g3t1_1_filepath = trace_dir + "/injector_g3t1_1_factor_trace.txt";
        fp.open(injector_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),component,stepState,sensor_freq,injector_factor\n";
        fp.close();

        injector_g3t1_2_filepath = trace_dir + "/injector_g3t1_2_factor_trace.txt";
        fp.open(injector_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),component,stepState,sensor_freq,injector_factor\n";
        fp.close();

        injector_g3t1_3_filepath = trace_dir + "/injector_g3t1_3_factor_trace.txt";
        fp.open(injector_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),component,stepState,sensor_freq,injector_factor\n";
        fp.close();

        injector_g3t1_4_filepath = trace_dir + "/injector_g3t1_4_factor_trace.txt";
        fp.open(injector_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),component,stepState,sensor_freq,injector_factor\n";
        fp.close();

        injector_g3t1_5_filepath = trace_dir + "/injector_g3t1_5_factor_trace.txt";
        fp.open(injector_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),component,stepState,sensor_freq,injector_factor\n";
        fp.close();

        injector_g3t1_6_filepath = trace_dir + "/injector_g3t1_6_factor_trace.txt";
        fp.open(injector_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "time_second,timestamp(ms),component,stepState,sensor_freq,injector_factor\n";
        fp.close();
    }
}

bsn::generator::NoiseGenerator Injector::configureNoiseGenerator(const std::string &component) {
    std::array<std::normal_distribution<double>,3> valueGenerators;

    // Value generators
    for(int i=0; i<3; i++) {
        valueGenerators[i] = std::normal_distribution<double> (Mu[component].at(i), Sigma[component].at(i));
    }

    // Random  
    std::mt19937 rng;
    if (random_seed == -1) {
        std::random_device rd;
        rng.seed(rd());

    } else if (random_seed >= 0) {
        int data_seed = 10000 + 1000*seed_count + random_seed;
        rng.seed(data_seed);
    }
    seed_count += 1;

    bsn::generator::NoiseGenerator noiseGenerator(component, valueGenerators, rng);

    return noiseGenerator;
}

void Injector::tearDown() {}

bool Injector::getInjectorData(services::InjectorData::Request &request, services::InjectorData::Response &response) {

    std::string component = request.component;

    // Request
    timestamp[component] = request.timestamp; 
    sensorFreq[component] = request.sensorFreq; 

    // Response
    response.data = injectorFactor[component];

    std::cout << "Send injector_factor=" << injectorFactor[request.component] << " to " + request.component + "." << std::endl;

    // Update step state based on timestamp
    if (timestamp[component] < Step[component].at(0)) {stepState[component] = 0;} 
    else if (timestamp[component] < Step[component].at(1)) {stepState[component] = 1;} 
    else if (timestamp[component] >= Step[component].at(1)) {stepState[component] = 2;}

    // Counting
    noiseCount[component] += 1; 
    
    // Tracing
    if (data_tracing == 1) {
        if (component == "g3t1_1") {fp.open(injector_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        if (component == "g3t1_2") {fp.open(injector_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        if (component == "g3t1_3") {fp.open(injector_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        if (component == "g3t1_4") {fp.open(injector_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        if (component == "g3t1_5") {fp.open(injector_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        if (component == "g3t1_6") {fp.open(injector_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

        fp << floor(timestamp[component]/1000.0) << ","; 
        fp << timestamp[component] << ",";
        fp << component << ",";     
        fp << stepState[component] << ",";   
        fp << sensorFreq[component] << ",";     
        fp << injectorFactor[component] << "\n";            
        fp.close();    
    }

    return true;
}

void Injector::body() {

    for (std::vector<std::string>::iterator component = components.begin(); component != components.end(); ++component){
       
        if (noiseCount[*component] > 0) {
            int freq = rosComponentDescriptor.getFreq();
            injectorFactor[*component] = injectorData[*component].gen_noise(timestamp[*component], stepState[*component]);

            noiseCount[*component] -= 1;
        }
    }

}