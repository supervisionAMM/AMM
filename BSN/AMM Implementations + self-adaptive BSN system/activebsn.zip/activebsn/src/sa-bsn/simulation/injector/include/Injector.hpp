#ifndef INJECTOR_HPP
#define INJECTOR_HPP

#include <fstream>
#include <iostream>

#include <sys/stat.h>
#include <cstdio>

#include "ros/ros.h"
#include "ros/package.h"

#include "archlib/ROSComponent.hpp"

#include "libbsn/utils/utils.hpp"
#include "libbsn/generator/NoiseGenerator.hpp"

#include "services/InjectorData.h"

class Injector : public arch::ROSComponent {

	public:
    	Injector(int &argc, char **argv, const std::string &name);
    	virtual ~Injector();

    private:
      	Injector(const Injector &);
    	Injector &operator=(const Injector &);

		int64_t seconds_in_cycles(const double &seconds);

	public:
		virtual void setUp();
		virtual void tearDown();
		virtual void body();

		// Evaluation
        int random_seed;     
        int seed_count;      
		std::map<std::string, int> timestamp;
		std::map<std::string, int> sensorFreq;
		std::map<std::string, int> noiseCount;

		// Tracing
        int data_tracing;

        std::fstream fp;
        std::string injector_g3t1_1_filepath, injector_g3t1_2_filepath, injector_g3t1_3_filepath;
        std::string injector_g3t1_4_filepath, injector_g3t1_5_filepath, injector_g3t1_6_filepath;

	private:
	    bool getInjectorData(services::InjectorData::Request &request, services::InjectorData::Response &response);
		bsn::generator::NoiseGenerator configureNoiseGenerator(const std::string& component);

        std::map<std::string, bsn::generator::NoiseGenerator> injectorData;

		ros::NodeHandle handle;
		ros::ServiceServer service;
		
		std::vector<std::string> components;
		std::map<std::string, double> injectorFactor;

		std::map<std::string, int> stepState;
		std::map<std::string, std::vector<int>> Step;
		std::map<std::string, std::vector<double>> Mu;
		std::map<std::string, std::vector<double>> Sigma;
};

#endif 