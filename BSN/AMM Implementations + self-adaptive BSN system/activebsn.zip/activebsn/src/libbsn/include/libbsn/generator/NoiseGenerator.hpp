#ifndef NOISEGENERATOR_HPP
#define NOISEGENERATOR_HPP

#include <iostream>
#include <array> 
#include <random>
#include <stdint.h>

namespace bsn {
    namespace generator {
        class NoiseGenerator {
            public:
                NoiseGenerator();
                NoiseGenerator(const std::string &component, const std::array<std::normal_distribution<double>,3>& valGens, const std::mt19937& rng);
                ~NoiseGenerator();

                double gen_noise(int &timestamp, int &stepState);

            private:
                std::string component;

                double value;    
                std::array<std::normal_distribution<double>,3> valueGenerators;
                std::mt19937 rng;
        };
    }
}

#endif