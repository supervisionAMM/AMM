#include "libbsn/generator/NoiseGenerator.hpp"

namespace bsn {
    namespace generator {
        NoiseGenerator::NoiseGenerator() : component(), valueGenerators(), rng() {}
        
        NoiseGenerator::NoiseGenerator(const std::string &component, const std::array<std::normal_distribution<double>,3>& valGens, const std::mt19937& rng) : 
            component(component), 
            valueGenerators(valGens),
            rng(rng) {}

        NoiseGenerator::~NoiseGenerator() {}

        double NoiseGenerator::gen_noise(int &timestamp, int &stepState) {
            
            return valueGenerators[stepState](rng);
        }
        
    } // namespace generator
} // namespace bsn